#Install the SDK
#pip install fastapi uvicorn google-genai python-dotenv
#Create a .env file in your backend project:
#env
#GEMINI_API_KEY=your_api_key_here
#GEMINI_MODEL=your_verified_model_id
#Ensure .env is excluded from version control.
#main.py the AI tutor endpoint

import os
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from google import genai
from google.genai import types

load_dotenv()

api_key = os.getenv("GEMINI_API_KEY")
model = os.getenv("GEMINI_MODEL")

if not api_key or not model:
    raise RuntimeError("Configure GEMINI_API_KEY and GEMINI_MODEL")

client = genai.Client(api_key=api_key)
app = FastAPI(title="AI Tutor API")


class TutorRequest(BaseModel):
    question: str = Field(min_length=1, max_length=5000)
    subject: str = Field(min_length=1, max_length=100)
    level: str = Field(min_length=1, max_length=100)
    lesson_context: str = Field(default="", max_length=15000)


class TutorResponse(BaseModel):
    answer: str


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/api/tutor", response_model=TutorResponse)
def tutor(request: TutorRequest):
    prompt = f"""
    You are a patient and supportive AI tutor.

    Subject: {request.subject}
    Learner level: {request.level}

    Lesson material:
    {request.lesson_context}

    Student question:
    {request.question}

    Explain step by step at the student's level.
    Give examples and check understanding.
    If the lesson material is insufficient, say so.
    """

    try:
        response = client.models.generate_content(
            model=model,
            contents=prompt,
            config=types.GenerateContentConfig(
                temperature=0.4,
                max_output_tokens=1000,
            ),
        )

        answer = response.text
        if not answer:
            raise HTTPException(
                status_code=502,
                detail="Gemini returned no text",
            )

        return TutorResponse(answer=answer)

    except HTTPException:
        raise
    except Exception:
        # Log diagnostic details securely on the server.
        raise HTTPException(
            status_code=502,
            detail="The AI tutor is temporarily unavailable",
        )


#Create a tutor service

#javascript

async function askTutor(question) {
  const response = await fetch(
    "http://127.0.0.1:8000/api/tutor",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        question,
        subject: "Mathematics",
        level: "Grade 9",
        lesson_context: "Solving linear equations",
      }),
    }
  );

  if (!response.ok) {
    throw new Error("Unable to get a tutor response");
  }

  const data = await response.json();
  return data.answer;
}

// Example:
askTutor("Why do we divide both sides by 2?")
  .then(console.log)
  .catch(console.error);



this is an example


import os
from google.colab import userdata
from google import genai

os.environ["GEMINI_API_KEY"] = userdata.get('GEMINI_API_KEY')
client = genai.Client()
interaction = client.interactions.create(
    model="gemini-3.8-flash",
    input="Write a three.js script that renders a realistic 3D black hole."
)

print(interaction.output_text)


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Realistic 3D Black Hole - Three.js</title>
    <style>
        body {
            margin: 0;
            overflow: hidden;
            background-color: #000;
            font-family: sans-serif;
        }
        #info {
            position: absolute;
            bottom: 20px;
            left: 20px;
            color: rgba(255, 255, 255, 0.7);
            pointer-events: none;
            font-size: 14px;
            letter-spacing: 1px;
        }
    </style>
</head>
<body>
    <div id="info">Drag to rotate | Scroll to zoom</div>

    <script type="importmap">
    {
        "imports": {
            "three": "https://unpkg.com/three@0.160.0/build/three.module.js",
            "three/addons/": "https://unpkg.com/three@0.160.0/examples/jsm/"
        }
    }
    </script>

    <script type="module">
        import * as THREE from 'three';
        import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

        // --- Scene & Renderer Setup ---
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
        camera.position.set(0, 2.5, 9.0);

        const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        document.body.appendChild(renderer.domElement);

        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.dampingFactor = 0.05;
        controls.maxDistance = 20.0;
        controls.minDistance = 2.0;

        // --- Black Hole Raymarching Shader ---
        const blackHoleShader = {
            uniforms: {
                iTime: { value: 0 },
                iResolution: { value: new THREE.Vector2(window.innerWidth, window.innerHeight) },
                cameraWorldMatrix: { value: camera.matrixWorld },
                cameraProjectionMatrixInverse: { value: camera.projectionMatrixInverse }
            },
            vertexShader: `
                varying vec2 vUv;
                void main() {
                    vUv = uv;
                    gl_Position = vec4(position.xy, 0.0, 1.0);
                }
            `,
            fragmentShader: `
                uniform float iTime;
                uniform vec2 iResolution;
                uniform mat4 cameraWorldMatrix;
                uniform mat4 cameraProjectionMatrixInverse;
                varying vec2 vUv;

                #define PI 3.14159265359
                #define MAX_STEPS 160
                #define STEP_SIZE 0.075
                #define RS 1.0               // Schwarzschild radius
                #define DISK_IN 1.6          // ISCO inner edge
                #define DISK_OUT 5.5         // Accretion disk outer radius
                #define DISK_HEIGHT 0.12     // Disk thickness scale

                // Procedural pseudo-random hash
                float hash(vec2 p) {
                    p = fract(p * vec2(123.34, 456.21));
                    p += dot(p, p + 45.32);
                    return fract(p.x * p.y);
                }

                // 2D Value Noise
                float noise(vec2 p) {
                    vec2 i = floor(p);
                    vec2 f = fract(p);
                    f = f * f * (3.0 - 2.0 * f);
                    float a = hash(i);
                    float b = hash(i + vec2(1.0, 0.0));
                    float c = hash(i + vec2(0.0, 1.0));
                    float d = hash(i + vec2(1.0, 1.0));
                    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
                }

                // Fractional Brownian Motion for gas dynamics
                float fbm(vec2 p) {
                    float v = 0.0;
                    float a = 0.5;
                    for (int i = 0; i < 4; i++) {
                        v += a * noise(p);
                        p *= 2.1;
                        a *= 0.45;
                    }
                    return v;
                }

                // Background starfield
                vec3 getBackground(vec3 dir) {
                    vec3 col = vec3(0.0);
                    vec2 uv = vec2(atan(dir.z, dir.x), asin(clamp(dir.y, -1.0, 1.0)));
                    
                    // Star layer
                    float n = hash(floor(uv * 300.0));
                    if (n > 0.996) {
                        float starIntensity = pow((n - 0.996) / 0.004, 6.0) * 2.0;
                        col += vec3(starIntensity);
                    }
                    
                    // Subtle deep-space nebula glow
                    float neb = fbm(uv * 3.0);
                    col += vec3(0.02, 0.04, 0.08) * neb;
                    return col;
                }

                // Blackbody emission color gradient based on temperature
                vec3 blackbody(float temp) {
                    vec3 col = vec3(255.0, 255.0, 255.0);
                    col.x = 56100000.0 * pow(temp, -0.66) + 148.0;
                    col.y = 100.04 * log(temp) - 623.6;
                    if (temp < 6500.0) {
                        col.z = 288.0 * log(temp - 10.0) - 2081.0;
                    } else {
                        col.z = 255.0;
                    }
                    return clamp(col / 255.0, 0.0, 1.0);
                }

                void main() {
                    // Reconstruct ray direction from camera matrices
                    vec2 ndc = vUv * 2.0 - 1.0;
                    vec4 viewCoords = cameraProjectionMatrixInverse * vec4(ndc, 1.0, 1.0);
                    viewCoords /= viewCoords.w;
                    vec3 rayDir = normalize((cameraWorldMatrix * vec4(viewCoords.xyz, 0.0)).xyz);
                    vec3 rayPos = (cameraWorldMatrix * vec4(0.0, 0.0, 0.0, 1.0)).xyz;

                    vec3 col = vec3(0.0);
                    float diskAlpha = 0.0;

                    // Raymarch through curved spacetime
                    for (int i = 0; i < MAX_STEPS; i++) {
                        float r = length(rayPos);

                        // Ray captured by the Event Horizon
                        if (r < RS) {
                            break;
                        }

                        // Escape to space
                        if (r > 20.0) {
                            col += getBackground(rayDir) * (1.0 - diskAlpha);
                            break;
                        }

                        // Relativistic light deflection approximation
                        // d^2 x / ds^2 approx - 1.5 * rs * x / r^5
                        vec3 gravity = -1.5 * RS * rayPos / pow(r, 4.0);
                        rayDir = normalize(rayDir + gravity * STEP_SIZE);
                        rayPos += rayDir * STEP_SIZE;

                        // Accretion disk volumetric density check
                        float h = abs(rayPos.y);
                        float distToCenter = length(rayPos.xz);

                        if (distToCenter > DISK_IN && distToCenter < DISK_OUT && h < DISK_HEIGHT * 2.5) {
                            // Cylindrical coordinates for orbital motion
                            float phi = atan(rayPos.z, rayPos.x);
                            
                            // Keplerian orbital speed (faster near the center)
                            float speed = 1.8 / sqrt(distToCenter);
                            float rotation = phi + speed * iTime * 0.8;

                            // Gas density pattern
                            vec2 gasUv = vec2(rotation * 2.0, (distToCenter - DISK_IN) * 3.0);
                            float gasDensity = fbm(gasUv);

                            // Smooth vertical falloff
                            float vertFalloff = exp(-pow(h / (DISK_HEIGHT * (distToCenter * 0.2)), 2.0));
                            
                            // Radial boundaries falloff
                            float radFalloff = smoothstep(DISK_IN, DISK_IN + 0.4, distToCenter) * 
                                               smoothstep(DISK_OUT, DISK_OUT - 1.5, distToCenter);
                            
                            float density = gasDensity * vertFalloff * radFalloff * 0.4;

                            if (density > 0.001) {
                                // Temperature: Hotter near center, cooler on perimeter
                                float temp = mix(12000.0, 2200.0, (distToCenter - DISK_IN) / (DISK_OUT - DISK_IN));
                                vec3 emission = blackbody(temp) * 2.2;

                                // Relativistic Doppler Beaming
                                // Gas orbits counter-clockwise: compute velocity vector
                                vec3 orbitVel = normalize(vec3(-rayPos.z, 0.0, rayPos.x));
                                float doppler = dot(orbitVel, -rayDir) * (speed * 0.65);
                                float beaming = pow(1.0 + doppler, 3.0);
                                emission *= beaming;

                                // Volumetric color accumulation
                                float stepAlpha = density * (1.0 - diskAlpha);
                                col += emission * stepAlpha;
                                diskAlpha += stepAlpha;

                                if (diskAlpha >= 0.99) break;
                            }
                        }
                    }

                    gl_FragColor = vec4(col, 1.0);
                }
            `
        };

        // --- Screen-filling Plane ---
        const material = new THREE.ShaderMaterial(blackHoleShader);
        const quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), material);
        scene.add(quad);

        // --- Window Resize Handling ---
        window.addEventListener('resize', onWindowResize);
        function onWindowResize() {
            renderer.setSize(window.innerWidth, window.innerHeight);
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();

            material.uniforms.iResolution.value.set(window.innerWidth, window.innerHeight);
        }

        // --- Animation Loop ---
        const clock = new THREE.Clock();
        function animate() {
            requestAnimationFrame(animate);

            controls.update();

            // Feed camera data to shader
            material.uniforms.iTime.value = clock.getElapsedTime();
            material.uniforms.cameraWorldMatrix.value = camera.matrixWorld;
            material.uniforms.cameraProjectionMatrixInverse.value = camera.projectionMatrixInverse;

            renderer.render(scene, camera);
        }

        animate();
    </script>
</body>
</html>