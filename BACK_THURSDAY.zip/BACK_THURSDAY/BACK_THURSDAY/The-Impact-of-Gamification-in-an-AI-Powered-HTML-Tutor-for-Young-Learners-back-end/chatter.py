import os
import logging
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from google import genai
from google.genai import types

load_dotenv()
logger = logging.getLogger("tutor")
logging.basicConfig(level=logging.INFO)

api_key = os.getenv("AQ.Ab8RN6K6tHjzmLou_w44WXGtEGy1Epf1ynlWDjzw0eS5k0fUfw")
model = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")

if not api_key:
    raise RuntimeError("Missing GEMINI_API_KEY in .env")

client = genai.Client(api_key=api_key)
app = FastAPI(title="AI Tutor API")

# --- CORS: without this the browser will refuse the fetch ---
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000", "http://127.0.0.1:3000",
        "http://localhost:5173", "http://127.0.0.1:5173",  # vite
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class TutorRequest(BaseModel):
    question: str = Field(min_length=1, max_length=5000)
    subject: str = Field(default="HTML", max_length=100)
    level: str = Field(default="Beginner", max_length=100)
    lesson_context: str = Field(default="", max_length=15000)

class TutorResponse(BaseModel):
    answer: str

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/api/tutor", response_model=TutorResponse)
def tutor(request: TutorRequest):
    context_block = (
        f"Lesson material:\n{request.lesson_context}\n"
        if request.lesson_context.strip()
        else "No lesson material provided — answer from general knowledge.\n"
    )

    prompt = f"""You are a patient, encouraging AI tutor for {request.subject}.
The learner is at {request.level} level.

{context_block}
Student question:
{request.question}

Rules:
- Explain step by step at the learner's level.
- Give a short code example when relevant.
- End with one quick check-for-understanding question.
"""

    try:
        response = client.models.generate_content(
            model=model,
            contents=prompt,
            config=types.GenerateContentConfig(
                temperature=0.4,
                max_output_tokens=1000,
            ),
        )
    except Exception:
        logger.exception("Gemini call failed")   # <-- real error goes to your terminal
        raise HTTPException(status_code=502, detail="AI tutor is temporarily unavailable")

    answer = (response.text or "").strip()
    if not answer:
        raise HTTPException(status_code=502, detail="Gemini returned no text")

    return TutorResponse(answer=answer)