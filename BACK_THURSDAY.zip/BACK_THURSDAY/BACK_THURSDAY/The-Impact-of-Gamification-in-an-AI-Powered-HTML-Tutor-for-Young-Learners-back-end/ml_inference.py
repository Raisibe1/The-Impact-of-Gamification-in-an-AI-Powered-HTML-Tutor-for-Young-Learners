"""Inference service for the tuned Logistic Regression development candidate.

This module loads the fitted preprocessing + classification pipeline and returns
next-interaction correctness probabilities. It does not make tutoring decisions.
"""
from __future__ import annotations

import math
import os
from pathlib import Path
from typing import Any, Mapping

import joblib
import pandas as pd
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

logger = logging.getLogger(__name__)

FEATURES = [
    "prior_interactions",
    "prior_accuracy",
    "recent_accuracy_5",
    "prior_mean_attempt_count",
    "prior_skill_attempts",
    "prior_skill_accuracy",
]

DEFAULT_MODEL_PATH = (
    Path(__file__).resolve().parent
    / "models"
    / "logistic_regression_next_interaction.joblib"
)
ACCURACY_FEATURES = {
    "prior_accuracy",
    "recent_accuracy_5",
    "prior_skill_accuracy",
}
COUNT_FEATURES = {
    "prior_interactions",
    "prior_mean_attempt_count",
    "prior_skill_attempts",
}
INTEGER_FEATURES = {"prior_interactions", "prior_skill_attempts"}


class ModelInputError(ValueError):
    """Raised when input values do not follow the model feature contract."""


class ModelService:
    """Load the trained model bundle once and generate predictions."""

    def __init__(self, model_path: str | Path | None = None) -> None:
        path = Path(
            model_path
            or os.getenv("HTML_TUTOR_ML_MODEL_PATH", str(DEFAULT_MODEL_PATH))
        )
        if not path.is_file():
            raise FileNotFoundError(f"Model artifact not found: {path}")

        bundle: Any = joblib.load(path)
        if not isinstance(bundle, dict) or "pipeline" not in bundle or "features" not in bundle:
            raise ValueError(
                "Unexpected model artifact format; expected a bundle with 'pipeline' and 'features'."
            )
        if list(bundle["features"]) != FEATURES:
            raise ValueError(
                f"Feature list mismatch. Expected {FEATURES}; found {list(bundle['features'])}."
            )

        self.pipeline = bundle["pipeline"]
        self.model_name = str(bundle.get("model_name", "Logistic Regression"))
        self.model_version = str(bundle.get("model_version", "logreg-assistments-dev-0.1"))
        self.model_status = str(
            bundle.get(
                "model_status",
                "development_candidate_not_yet_validated_on_HTML_tutor_data",
            )
        )
        self.model_path = path

        if list(getattr(self.pipeline, "classes_", [])) != [0, 1]:
            raise ValueError("Expected a binary classifier with classes [0, 1].")

    @staticmethod
    def _validate_features(features: Mapping[str, Any]) -> dict[str, float | None]:
        if not isinstance(features, Mapping):
            raise ModelInputError("features must be an object of feature names to numbers or null.")

        unknown = set(features) - set(FEATURES)
        if unknown:
            raise ModelInputError(f"Unexpected feature(s): {', '.join(sorted(unknown))}")

        cleaned: dict[str, float | None] = {}
        for name in FEATURES:
            value = features.get(name)
            if value is None:
                cleaned[name] = None
                continue
            if isinstance(value, bool):
                raise ModelInputError(f"{name} must be numeric, not boolean.")
            try:
                numeric = float(value)
            except (TypeError, ValueError) as exc:
                raise ModelInputError(f"{name} must be numeric or null.") from exc
            if not math.isfinite(numeric):
                raise ModelInputError(f"{name} must be finite or null.")
            if name in ACCURACY_FEATURES and not 0.0 <= numeric <= 1.0:
                raise ModelInputError(f"{name} must be a fraction between 0 and 1.")
            if name in COUNT_FEATURES and numeric < 0:
                raise ModelInputError(f"{name} cannot be negative.")
            if name in INTEGER_FEATURES and not numeric.is_integer():
                raise ModelInputError(f"{name} must be an integer when supplied.")
            cleaned[name] = numeric

        return cleaned

    def predict(self, features: Mapping[str, Any]) -> dict[str, Any]:
        cleaned = self._validate_features(features)
        frame = pd.DataFrame([[cleaned[name] for name in FEATURES]], columns=FEATURES)
        p_correct = float(self.pipeline.predict_proba(frame)[0, 1])
        if not math.isfinite(p_correct) or not 0.0 <= p_correct <= 1.0:
            raise RuntimeError("Model returned an invalid probability score.")

        prior_interactions = cleaned["prior_interactions"]
        prior_skill_attempts = cleaned["prior_skill_attempts"]
        cold_start = prior_interactions is None or prior_interactions <= 0
        no_skill_history = prior_skill_attempts is None or prior_skill_attempts <= 0

        return {
            "p_next_interaction_correct": round(p_correct, 6),
            "p_next_interaction_incorrect": round(1.0 - p_correct, 6),
            "model_name": self.model_name,
            "model_version": self.model_version,
            "model_status": self.model_status,
            "cold_start": bool(cold_start),
            "no_history_for_current_skill": bool(no_skill_history),
            "personalized_estimate": bool(not cold_start),
            "imputed_features": [name for name in FEATURES if cleaned[name] is None],
            "decision_policy": None,
            "calibration_status": "not_yet_evaluated",
            "notice": (
                "Development score for next recorded interaction correctness, trained on ASSISTments-derived data. "
                "It does not predict next-lesson pass probability or directly measure concept mastery. "
                "Probability calibration and any hint/progression policy have not been validated."
            ),
        }
