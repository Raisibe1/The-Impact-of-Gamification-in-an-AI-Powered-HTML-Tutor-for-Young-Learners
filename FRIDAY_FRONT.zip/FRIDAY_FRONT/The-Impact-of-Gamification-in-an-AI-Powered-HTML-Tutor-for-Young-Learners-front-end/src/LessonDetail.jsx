import { useState, useEffect } from "react";

function LessonDetail({ lessonSlug, onBack }) {
  const [lesson, setLesson] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [completed, setCompleted] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState("");

  useEffect(() => {
    let cancelled = false;

    const load = async () => {
      setLoading(true);
      setError("");
      try {
        const res = await fetch(
          `http://localhost:8000/api/lessons/${lessonSlug}`,
          { credentials: "include" }
        );
        if (!res.ok) throw new Error(`Server responded ${res.status}`);
        const data = await res.json();
        if (!cancelled) {
          setLesson(data);
          setCompleted(Boolean(data?.progress?.completed));
        }
      } catch (err) {
        console.error(err);
        if (!cancelled) setError("Could not load this lesson.");
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    load();
    return () => {
      cancelled = true;
    };
  }, [lessonSlug]);

  const handleComplete = async () => {
    setSaving(true);
    setSaveError("");
    try {
      const res = await fetch("http://localhost:8000/api/progress", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        // Matches the existing ProgressRequest model in API.py
        body: JSON.stringify({ lesson_slug: lessonSlug, completed: true }),
      });

      if (!res.ok) {
        throw new Error(`Server responded ${res.status}`);
      }
      setCompleted(true);
    } catch (err) {
      console.error(err);
      setSaveError("Could not save progress. Are you still logged in?");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="page-section">
        <p className="small-text">Loading lesson…</p>
      </section>
    );
  }

  if (error || !lesson) {
    return (
      <section className="empty-page">
        <div className="empty-illustration"></div>
        <p className="label">LESSON UNAVAILABLE</p>
        <h2>{error || "That lesson doesn't exist."}</h2>
        <button className="primary" onClick={onBack}>
          Back to lessons
        </button>
      </section>
    );
  }

  return (
    <section className="page-section lesson-detail">
      <button className="back-link" onClick={onBack}>
        ← Back to lessons
      </button>

      <div className="section-heading">
        <p className="label">{(lesson.module || "LESSON").toUpperCase()}</p>
        <h2>{lesson.title}</h2>
        <p>{lesson.description}</p>
        <div className="lesson-meta lesson-meta-large">
          <span>TIME {lesson.duration}</span>
          <span>STUDY {lesson.level}</span>
        </div>
      </div>

      <div className="lesson-body">
        {lesson.sections?.map((section, i) => {
          if (section.type === "code") {
            return (
              <div className="lesson-code" key={i}>
                <div className="lesson-code-top">
                  <span></span>
                  <span></span>
                  <span></span>
                  <em>{section.language || "code"}</em>
                </div>
                <pre>
                  <code>{section.content}</code>
                </pre>
              </div>
            );
          }

          if (section.type === "tip") {
            return (
              <div className="lesson-tip" key={i}>
                <strong>Tip</strong>
                <p>{section.content}</p>
              </div>
            );
          }

          return (
            <p className="lesson-text" key={i}>
              {section.content}
            </p>
          );
        })}
      </div>

      <div className="lesson-footer">
        <button
          className="primary"
          disabled={completed || saving}
          onClick={handleComplete}
        >
          {saving
            ? "Saving…"
            : completed
            ? "✓ Lesson completed"
            : "Mark as complete"}
        </button>
        {saveError && (
          <p className="small-text" style={{ color: "#b23", marginTop: 10 }}>
            {saveError}
          </p>
        )}
      </div>
    </section>
  );
}

export default LessonDetail;