import { useState, useEffect } from "react";

function Lessons({ onOpenLesson }) {
  const [lessons, setLessons] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchLessons = async () => {
      setLoading(true);
      setError("");
      try {
        const res = await fetch("http://localhost:8000/api/lessons", {
          credentials: "include",
        });
        if (!res.ok) throw new Error(`Server responded ${res.status}`);
        const data = await res.json();
        setLessons(Array.isArray(data) ? data : []);
      } catch (err) {
        console.error(err);
        setError("Could not load lessons. Please try again.");
      } finally {
        setLoading(false);
      }
    };
    fetchLessons();
  }, []);

  return (
    <section className="page-section lessons-page">
      <div className="section-heading">
        <p className="label">LESSONS</p>
        <h2>Your HTML learning path.</h2>
        <p>
          Work through each lesson to build a solid foundation in HTML. Complete
          a lesson to unlock the next one.
        </p>
      </div>

      {loading && <p className="small-text">Loading lessons…</p>}
      {error && <p className="small-text" style={{ color: "#b23" }}>{error}</p>}

      {!loading && !error && lessons.length === 0 && (
        <p className="small-text">No lessons available yet.</p>
      )}

      <div className="lessons-grid">
        {lessons.map((lesson, index) => (
          <LessonCard
            key={lesson.slug}
            lesson={lesson}
            index={index}
            onOpen={onOpenLesson}
          />
        ))}
      </div>
    </section>
  );
}

function LessonCard({ lesson, index, onOpen }) {
  const locked = Boolean(lesson.locked);

  const handleClick = () => {
    if (locked) return; // belt-and-braces — the button is also disabled
    onOpen(lesson.slug);
  };

  return (
    <article
      className={`lesson-card ${locked ? "lesson-card-locked" : ""}`}
      aria-disabled={locked || undefined}
    >
      <div className="lesson-card-top">
        <span className="lesson-index">
          {String(index + 1).padStart(2, "0")}
        </span>
        <span className="lesson-level">{lesson.level}</span>
      </div>

      <h3>{lesson.title}</h3>
      {lesson.subtitle && (
        <p className="lesson-subtitle">{lesson.subtitle}</p>
      )}
      <p>{lesson.description}</p>

      <div className="lesson-meta">
        <span>TIME {lesson.duration}</span>
        <span>STUDY {lesson.module}</span>
        {lesson.xp_reward ? <span> {lesson.xp_reward} XP</span> : null}
      </div>

      <button
        className="primary full"
        onClick={handleClick}
        disabled={locked}
        aria-label={
          locked
            ? `Lesson locked: ${lesson.title}`
            : `Open lesson: ${lesson.title}`
        }
      >
        {locked ? "Locked" : "Open lesson"}
      </button>

      {/* Padlock overlay — sits on top of the whole card when locked */}
      {locked && (
        <div className="lesson-lock-overlay" aria-hidden="true">
          <div className="lesson-lock-badge">
            <LockIcon />
            <span>Complete the previous lesson to unlock</span>
          </div>
        </div>
      )}
    </article>
  );
}

function LockIcon() {
  return (
    <svg
      width="26"
      height="26"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect x="4" y="11" width="16" height="10" rx="2" />
      <path d="M8 11V7a4 4 0 0 1 8 0v4" />
    </svg>
  );
}

export default Lessons;