import { useState } from "react";

const lessons = [
  { id: 1, title: "Introduction to HTML and Web Basics", type: "Notes", group: "Foundations" },
  { id: 2, title: "HTML Tags and Documents", type: "Notes", group: "Foundations" },
  { id: 3, title: "Headings and Paragraphs", type: "Notes", group: "Foundations" },
  { id: 4, title: "Hyperlinks", type: "Game", group: "HTML Elements" },
  { id: 5, title: "Images and Paragraphs", type: "Game", group: "HTML Elements" },
  { id: 6, title: "Hyperlinks (Intermediate)", type: "Game", group: "HTML Elements" },
  { id: 7, title: "Images and Tags", type: "Game", group: "HTML Elements" },
  { id: 8, title: "Lists and Tables", type: "Notes", group: "HTML Elements" },
  { id: 9, title: "Forms and User Input", type: "Notes", group: "Advanced" },
  { id: 10, title: "Semantic HTML and Accessibility", type: "Notes", group: "Advanced" },
];

const lessonContent = {
  1: {
    objective: "Understand how the internet, websites and HTML work.",
    sections: [
      { heading: "1.1 What is the internet?", content: "The internet is a global network connecting computers, phones, servers and other devices.", example: "Think of a massive digital city. The internet provides the roads connecting buildings, while the World Wide Web contains many of the destinations we visit." },
      { heading: "1.2 What is a website?", content: "A website is a collection of related webpages that people can access through a web browser. A webpage is one document within a website.", example: "Examples include Google, YouTube, Wikipedia and an online school portal." },
      { heading: "1.3 How does a website work?", content: "A browser requests a page, a server sends the required files, and the browser displays the page.", example: "Browser requests page → Server sends files → Browser displays page" },
      { heading: "1.4 What is HTML?", content: "HTML means HyperText Markup Language. It is the standard markup language used to describe the structure and content of webpages. HTML helps browsers understand which content is a heading, paragraph, picture, link or form." },
      { heading: "1.5 The three web technologies", content: "Most websites use three important technologies.", example: "HTML = Structure\nCSS = Design\nJavaScript = Behaviour" },
      { heading: "1.6 Your first HTML code", content: "The h1 element creates a main heading. The p element creates a paragraph.", code: `<h1>Hello, World!</h1>
<p>My name is Alex.</p>
<p>I am learning HTML!</p>` },
    ],
    challenge: "Create a webpage introduction containing your name, your school and why you want to learn programming.",
    checkpoint: "Why do we use HTML, CSS and JavaScript for different purposes?",
  },
  2: {
    objective: "Learn how HTML tags, attributes and document structure work.",
    sections: [
      { heading: "2.1 What is an HTML tag?", content: "HTML tags are instructions written inside angle brackets. Many HTML elements have an opening tag and a closing tag. Some elements, such as img, are void elements and do not have closing tags.", code: `<p>This is a paragraph.</p>
<img src="school.jpg" alt="School building">` },
      { heading: "2.2 Structure of an HTML document", content: "A complete HTML page has a document declaration, an html root element, a head section containing page information, and a body section containing visible content.", code: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My First Website</title>
</head>
<body>
  <h1>Welcome to My Website</h1>
  <p>I am learning web development.</p>
</body>
</html>` },
      { heading: "2.3 Understanding document tags", content: "DOCTYPE declares the HTML document type. html is the root of the document. head contains metadata. title defines the browser-tab title. meta provides metadata. body contains the visible webpage content." },
      { heading: "2.4 What are attributes?", content: "Attributes provide additional information about HTML elements. They are written inside the opening tag.", code: `<html lang="en">
<p title="Welcome message">Hello, student!</p>` },
      { heading: "2.5 Nesting HTML elements", content: "Nesting means placing one HTML element inside another. Elements should be closed in the correct order.", code: `<!-- Incorrect -->
<p>I love <strong>HTML</p></strong>

<!-- Correct -->
<p>I love <strong>HTML</strong></p>` },
    ],
    challenge: "Create a complete HTML document with a title, main heading, two paragraphs and one strongly emphasised word.",
  },
  3: {
    objective: "Use headings and paragraphs to organise webpage content.",
    sections: [
      { heading: "3.1 What are headings?", content: "Headings organise webpage content into meaningful sections. HTML provides six heading levels, from h1 to h6. Heading levels express document hierarchy, not just font size." },
      { heading: "3.2 Writing headings in HTML", content: "The h1 element is the top-level heading. Lower levels create subsections. Do not choose heading levels purely because of how large they look. Use CSS to change their appearance.", code: `<h1>My Learning Journey</h1>
<h2>About Me</h2>
<h3>My Favourite Subjects</h3>
<h4>Mathematics</h4>` },
      { heading: "3.3 What are paragraphs?", content: "Paragraphs contain written information and are created with the p element.", code: `<p>My favourite subject is Mathematics because I enjoy solving problems.</p>` },
      { heading: "3.4 Text formatting elements", content: "strong gives text strong importance. em adds emphasis. br creates a line break. hr creates a thematic break. mark highlights content. small is used for side comments or fine print.", code: `<h1>My Coding Journey</h1>
<p>I am <strong>determined</strong> to become a developer.</p>
<p>Learning HTML is <em>exciting!</em></p>
<hr>
<p>Practice every day.<br>Never stop learning.</p>` },
    ],
    challenge: "Build a personal profile page with one main heading, two sections, three paragraphs and at least two text-formatting elements.",
    checkpoint: "Why should a developer use proper heading levels instead of making every heading an h1?",
  },
  8: {
    objective: "Use lists and tables to organise information.",
    sections: [
      { heading: "8.1 Why do we use lists?", content: "Lists organise related information in a clear, readable format. HTML supports unordered, ordered and description lists." },
      { heading: "8.2 Unordered lists", content: "Unordered lists use ul for the list and li for each list item.", code: `<h2>My Favourite Subjects</h2>
<ul>
  <li>Mathematics</li>
  <li>Physical Sciences</li>
  <li>Computer Science</li>
</ul>` },
      { heading: "8.3 Ordered lists", content: "Ordered lists use ol for the list and li for each list item.", code: `<h2>How to Create a Webpage</h2>
<ol>
  <li>Open your code editor.</li>
  <li>Create an HTML file.</li>
  <li>Write your HTML code.</li>
  <li>Open it in a browser.</li>
</ol>` },
      { heading: "8.4 Description lists", content: "Description lists use dl, dt and dd. The dt element identifies a term and dd provides its description.", code: `<dl>
  <dt>HTML</dt>
  <dd>Structures webpage content.</dd>
  <dt>CSS</dt>
  <dd>Styles webpage content.</dd>
</dl>` },
      { heading: "8.5 What is an HTML table?", content: "Tables organise data into rows and columns. Important table elements include table, tr, th, td and caption." },
      { heading: "8.6 Creating a table", content: "Use caption to describe the table. Use thead for the heading rows and tbody for the main data. th identifies a header cell and td identifies a data cell.", code: `<table>
  <caption>Student Study Schedule</caption>
  <thead>
    <tr><th scope="col">Day</th><th scope="col">Subject</th><th scope="col">Duration</th></tr>
  </thead>
  <tbody>
    <tr><td>Monday</td><td>HTML</td><td>45 minutes</td></tr>
    <tr><td>Tuesday</td><td>CSS</td><td>60 minutes</td></tr>
  </tbody>
</table>` },
    ],
    challenge: "Create a weekly timetable, a list of five subjects and an ordered list of study goals.",
  },
  9: {
    objective: "Learn how forms collect information from users.",
    sections: [
      { heading: "9.1 What is an HTML form?", content: "Forms allow users to enter information into a webpage. Examples include registration forms, login pages, contact forms, surveys and quiz-answer submissions." },
      { heading: "9.2 Important form elements", content: "form groups form controls. label names an input. input accepts input. textarea accepts multi-line text. select creates a dropdown. option defines a dropdown choice. button performs an action. fieldset groups related controls and legend labels a control group." },
      { heading: "9.3 Common input types", content: "Each input type is designed for a particular kind of user entry.", code: `<input type="text">
<input type="email">
<input type="password">
<input type="number">
<input type="date">
<input type="checkbox">
<input type="radio">` },
      { heading: "9.4 Build a student registration form", content: "A registration form can use labels and input elements to collect a learner's name, email address and school grade. The required attribute marks information that must be entered.", code: `<form action="/register" method="post">
  <h2>Student Registration</h2>
  <label for="name">Full Name</label>
  <input type="text" id="name" name="name" required>

  <label for="email">Email Address</label>
  <input type="email" id="email" name="email" required>

  <label for="grade">School Grade</label>
  <input type="number" id="grade" name="grade">

  <button type="submit">Register</button>
</form>` },
    ],
    challenge: "Create a student registration form using labels and suitable input types.",
  },
  10: {
    objective: "Explore semantic HTML and accessibility as the final topic in the learning pathway.",
    sections: [
      { heading: "10.1 Semantic HTML and accessibility", content: "This module introduces semantic HTML and accessibility. The curriculum identifies these as the focus of the final lesson in the learning pathway." },
      { heading: "10.2 Your final learning outcome", content: "The overall curriculum outcome is to build a functional, accessible, multi-section personal website using HTML." },
    ],
    challenge: "Plan a multi-section personal website that brings together the HTML skills covered in the course.",
  },
};

function App() {
  const [activePage, setActivePage] = useState("Dashboard");
  const [selectedLesson, setSelectedLesson] = useState(null);
  const [completedLessons, setCompletedLessons] = useState([]);
  const [showQuizPlaceholder, setShowQuizPlaceholder] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);
  const [showTutor, setShowTutor] = useState(false);

  const progress = Math.round((completedLessons.length / lessons.length) * 100);

  const openLesson = (lesson) => {
    setSelectedLesson(lesson);
    setShowQuizPlaceholder(false);
    setShowFeedback(false);
    setShowTutor(false);
    setActivePage("Learning Path");
  };

  const completeLesson = () => {
    if (selectedLesson && !completedLessons.includes(selectedLesson.id)) {
      setCompletedLessons((previous) => [...previous, selectedLesson.id]);
    }
    setSelectedLesson(null);
  };

  const openQuizPlaceholder = () => {
    setSelectedLesson(null);
    setShowQuizPlaceholder(true);
    setShowFeedback(false);
  };

  const openFeedback = () => {
    setShowQuizPlaceholder(false);
    setShowFeedback(true);
  };

  const closeLearningModal = () => {
    setSelectedLesson(null);
    setShowQuizPlaceholder(false);
    setShowFeedback(false);
    setShowTutor(false);
  };

  const navItems = [
    { name: "Dashboard", label: "Overview" },
    { name: "Learning Path", label: "My learning path" },
    { name: "Progress", label: "My progress" },
  ];

  const renderLessonCards = (items) => (
    <div className="lesson-grid">
      {items.map((lesson) => (
        <LessonCard
          key={lesson.id}
          lesson={lesson}
          completed={completedLessons.includes(lesson.id)}
          onClick={() => openLesson(lesson)}
        />
      ))}
    </div>
  );

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">C</div>
          <div><h1>CodeVerse</h1><span>LEARN. BUILD. GROW.</span></div>
        </div>

        <div className="sidebar-label">MENU</div>
        <nav className="navigation">
          {navItems.map((item) => (
            <button
              key={item.name}
              className={`nav-item ${activePage === item.name ? "active" : ""}`}
              onClick={() => {
                setActivePage(item.name);
                closeLearningModal();
              }}
            >
              <span className="nav-indicator" />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <div className="sidebar-progress">
            <span className="small-label">YOUR PROGRESS</span>
            <strong>{progress}%</strong>
            <div className="progress-track">
              <div style={{ width: `${progress}%` }} />
            </div>
            <p>{completedLessons.length} of {lessons.length} lessons completed</p>
          </div>
          <div className="profile-mini">
            <div className="avatar">L</div>
            <div><strong>Learner</strong><span>Student account</span></div>
          </div>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <div>
            <span className="breadcrumb">CODEVERSE / {activePage.toUpperCase()}</span>
            <h2>{activePage}</h2>
          </div>
          <div className="topbar-right">
            <span className="status-dot" />
            <span>Learning workspace</span>
          </div>
        </header>

        {activePage === "Dashboard" && (
          <section className="page-content">
            <div className="welcome-section">
              <div>
                <span className="eyebrow">YOUR LEARNING SPACE</span>
                <h1>Welcome back, Learner.</h1>
                <p>Every step forward builds your confidence. Continue learning HTML at your own pace.</p>
              </div>
              <button className="primary-button" onClick={() => setActivePage("Learning Path")}>
                Continue learning <span>→</span>
              </button>
            </div>

            <div className="stats-grid">
              <div className="stat-card">
                <span className="stat-label">COURSE PROGRESS</span>
                <strong>{progress}%</strong>
                <p>Overall completion</p>
              </div>
              <div className="stat-card">
                <span className="stat-label">LESSONS COMPLETED</span>
                <strong>{completedLessons.length}/{lessons.length}</strong>
                <p>Keep building your skills</p>
              </div>
              <div className="stat-card">
                <span className="stat-label">CURRENT COURSE</span>
                <strong className="stat-course">HTML Basics</strong>
                <p>Web development foundations</p>
              </div>
            </div>

            <div className="dashboard-grid">
              <section className="content-card learning-card">
                <div className="section-heading">
                  <div>
                    <span className="eyebrow">YOUR COURSE</span>
                    <h3>HTML Learning Journey</h3>
                  </div>
                  <span className="tag">BEGINNER</span>
                </div>
                <p className="muted-text">Learn the building blocks of websites through lessons, activities and assessments.</p>
                <div className="course-progress-row">
                  <span>Course completion</span>
                  <strong>{progress}%</strong>
                </div>
                <div className="progress-track large">
                  <div style={{ width: `${progress}%` }} />
                </div>
                <button className="text-button" onClick={() => setActivePage("Learning Path")}>
                  View learning path →
                </button>
              </section>
            </div>

            <section className="content-card next-card">
              <div>
                <span className="eyebrow">PICK UP WHERE YOU LEFT OFF</span>
                <h3>Your next lesson</h3>
                <p>{lessons.find((lesson) => !completedLessons.includes(lesson.id))?.title || "You have completed all lessons."}</p>
              </div>
              <button className="primary-button" onClick={() => {
                const nextLesson = lessons.find((lesson) => !completedLessons.includes(lesson.id));
                if (nextLesson) openLesson(nextLesson);
              }}>
                Start lesson →
              </button>
            </section>
          </section>
        )}

        {activePage === "Learning Path" && (
          <section className="page-content">
            <div className="page-intro">
              <span className="eyebrow">YOUR HTML COURSE</span>
              <h1>Learning pathway</h1>
              <p>Follow each stage in order. Complete the lessons and work towards your final project.</p>
            </div>

            <div className="path-summary">
              <div><strong>{completedLessons.length}/{lessons.length}</strong><span>Lessons completed</span></div>
              <div><strong>{progress}%</strong><span>Overall progress</span></div>
              <div><strong>HTML</strong><span>Learning subject</span></div>
            </div>

            <div className="pipeline">
              <div className="pipeline-start">
                <span className="pipeline-number">01</span>
                <div><strong>Start learning</strong><span>Introduction and initial benchmark</span></div>
              </div>
              <div className="pipeline-connector" />

              <div className="pipeline-stage">
                <div className="stage-heading">
                  <span className="stage-number">02</span>
                  <div><span className="eyebrow">STAGE ONE</span><h3>HTML Foundations</h3><p>Build your understanding of the basics.</p></div>
                </div>
                {renderLessonCards(lessons.slice(0, 3))}
              </div>

              <div className="pipeline-connector" />

              <div className="pipeline-stage">
                <div className="stage-heading">
                  <span className="stage-number">03</span>
                  <div><span className="eyebrow">STAGE TWO</span><h3>HTML Elements</h3><p>Practise working with common HTML elements.</p></div>
                </div>
                {renderLessonCards(lessons.slice(3, 8))}
              </div>

              <div className="pipeline-connector" />

              <div className="pipeline-stage">
                <div className="stage-heading">
                  <span className="stage-number">04</span>
                  <div><span className="eyebrow">STAGE THREE</span><h3>Advanced HTML</h3><p>Bring the concepts together.</p></div>
                </div>
                {renderLessonCards(lessons.slice(8, 10))}
              </div>

              <div className="pipeline-connector" />

              <div className="assessment-stage">
                <span className="eyebrow">ASSESSMENT</span>
                <h3>Final test</h3>
                <p>Test your understanding of the HTML lessons.</p>
                <button className="secondary-button" onClick={openQuizPlaceholder}>
                  Start final test →
                </button>
              </div>

              <div className="pipeline-connector" />

              <div className="project-stage">
                <span className="eyebrow">FINAL CHALLENGE</span>
                <h3>HTML Final Project</h3>
                <p>Build a functional, accessible, multi-section personal website using HTML.</p>
                <button className="primary-button" onClick={() => setActivePage("Final Project")}>
                  View project →
                </button>
              </div>
            </div>
          </section>
        )}

        {activePage === "Progress" && (
          <section className="page-content">
            <div className="page-intro">
              <span className="eyebrow">YOUR DEVELOPMENT</span>
              <h1>Learning progress</h1>
              <p>Track your completed lessons and learning milestones.</p>
            </div>

            <div className="content-card progress-overview">
              <div className="progress-circle">
                <strong>{progress}%</strong>
                <span>Completed</span>
              </div>
              <div>
                <h3>Your HTML learning progress</h3>
                <p>You have completed {completedLessons.length} out of {lessons.length} lessons. Keep practising to strengthen your understanding.</p>
              </div>
            </div>

            <section className="content-card">
              <div className="section-heading">
                <div><span className="eyebrow">COURSE BREAKDOWN</span><h3>Lesson activity</h3></div>
              </div>
              <div className="progress-lesson-list">
                {lessons.map((lesson) => (
                  <div className="progress-lesson" key={lesson.id}>
                    <div>
                      <span className="lesson-index">{String(lesson.id).padStart(2, "0")}</span>
                      <div><strong>{lesson.title}</strong><span>{lesson.type} lesson</span></div>
                    </div>
                    <span className={`completion-label ${completedLessons.includes(lesson.id) ? "done" : ""}`}>
                      {completedLessons.includes(lesson.id) ? "Completed" : "Not completed"}
                    </span>
                  </div>
                ))}
              </div>
            </section>
          </section>
        )}

        {activePage === "Final Project" && (
          <section className="page-content">
            <div className="page-intro">
              <span className="eyebrow">PUT YOUR SKILLS INTO PRACTICE</span>
              <h1>HTML final project</h1>
              <p>Demonstrate what you have learned by planning and building a webpage.</p>
            </div>
            <div className="content-card project-instructions">
              <h3>Your challenge</h3>
              <p>Build a functional, accessible, multi-section personal website using HTML.</p>
              <h4>Your website should bring together the skills from your lessons:</h4>
              <ul>
                <li>A clear HTML document structure</li>
                <li>Headings and paragraphs</li>
                <li>Working hyperlinks and navigation</li>
                <li>Images with suitable alternative text</li>
                <li>Lists and tables where appropriate</li>
                <li>A form for user input</li>
                <li>Meaningful sections and accessible content</li>
              </ul>
              <p className="muted-text">Plan your website, write your HTML, test it in a browser and review your work.</p>
            </div>
          </section>
        )}
      </main>

      {selectedLesson && (
        <div className="modal-backdrop" onClick={closeLearningModal}>
          <div className="lesson-modal" onClick={(event) => event.stopPropagation()}>
            <button className="modal-close" onClick={closeLearningModal}>×</button>

            <span className="eyebrow">LESSON {String(selectedLesson.id).padStart(2, "0")}</span>
            <h2>{selectedLesson.title}</h2>
            <span className="tag">{selectedLesson.type.toUpperCase()}</span>

            <div className="lesson-modal-body">
              {selectedLesson.type === "Notes" ? (
                <>
                  <h3>Learning objective</h3>
                  <p>{lessonContent[selectedLesson.id].objective}</p>

                  {lessonContent[selectedLesson.id].sections.map((section, index) => (
                    <section className="lesson-note-section" key={`${selectedLesson.id}-${index}`}>
                      <h3>{section.heading}</h3>
                      <p>{section.content}</p>
                      {section.example && (
                        <div className="lesson-example">
                          <span>EXAMPLE</span>
                          <pre>{section.example}</pre>
                        </div>
                      )}
                      {section.code && (
                        <div className="lesson-example">
                          <span>HTML CODE</span>
                          <pre><code>{section.code}</code></pre>
                        </div>
                      )}
                    </section>
                  ))}

                  {lessonContent[selectedLesson.id].checkpoint && (
                    <div className="lesson-example">
                      <span>THINK ABOUT IT</span>
                      <p>{lessonContent[selectedLesson.id].checkpoint}</p>
                    </div>
                  )}

                  <div className="lesson-example">
                    <span>PRACTICE CHALLENGE</span>
                    <p>{lessonContent[selectedLesson.id].challenge}</p>
                  </div>
                </>
              ) : (
                <div className="game-placeholder">
                  <span className="eyebrow">INTERACTIVE LEARNING ACTIVITY</span>
                  <h3>Game coming soon</h3>
                  <p>This lesson will contain an interactive HTML game.</p>
                  <p>The game activity and instructions will be integrated by the development team.</p>
                  <div className="placeholder-panel">
                    <strong>Game area</strong>
                    <span>Interactive activity will appear here.</span>
                  </div>
                </div>
              )}
            </div>

            <div className="lesson-actions">
              {selectedLesson.type === "Notes" && (
                <button className="secondary-button" onClick={() => setShowTutor(true)}>
                  Ask AI Tutor
                </button>
              )}
              <button className="secondary-button" onClick={openQuizPlaceholder}>
                Take Lesson Quiz
              </button>
              <button className="primary-button full-button" onClick={completeLesson}>
                Mark lesson as complete
              </button>
            </div>
          </div>
        </div>
      )}

      {showTutor && (
        <div className="modal-backdrop" onClick={() => setShowTutor(false)}>
          <div className="lesson-modal placeholder-modal" onClick={(event) => event.stopPropagation()}>
            <button className="modal-close" onClick={() => setShowTutor(false)}>×</button>
            <span className="eyebrow">CODEVERSE AI TUTOR</span>
            <h2>Ask AI Tutor</h2>
            <p>The AI Tutor will help learners understand lesson content and ask questions.</p>
            <div className="placeholder-panel">
              <strong>AI Tutor integration coming soon</strong>
              <span>The question and response interface will be connected later.</span>
            </div>
            <button className="primary-button full-button" onClick={() => setShowTutor(false)}>
              Return to lesson
            </button>
          </div>
        </div>
      )}

      {showQuizPlaceholder && (
        <div className="modal-backdrop" onClick={closeLearningModal}>
          <div className="lesson-modal placeholder-modal" onClick={(event) => event.stopPropagation()}>
            <button className="modal-close" onClick={closeLearningModal}>×</button>
            <span className="eyebrow">CODEVERSE ASSESSMENT</span>
            <h2>{selectedLesson ? selectedLesson.title : "HTML Final Test"}</h2>
            <div className="placeholder-panel">
              <strong>Quiz integration coming soon</strong>
              <span>The quiz questions, answer selection and scoring will be added by the development team.</span>
            </div>
            <button className="primary-button full-button" onClick={openFeedback}>
              Continue to feedback preview
            </button>
          </div>
        </div>
      )}

      {showFeedback && (
        <div className="modal-backdrop" onClick={closeLearningModal}>
          <div className="lesson-modal placeholder-modal" onClick={(event) => event.stopPropagation()}>
            <button className="modal-close" onClick={closeLearningModal}>×</button>
            <span className="eyebrow">LEARNING REVIEW</span>
            <h2>AI Tutor Feedback</h2>
            <p>This is a preview of the feedback layout. No actual assessment or AI feedback has been generated.</p>

            <div className="feedback-score">
              <strong>--%</strong>
              <span>Quiz score</span>
            </div>

            <div className="feedback-section">
              <h3>Strengths</h3>
              <p>Feedback will appear here after the quiz integration.</p>
            </div>
            <div className="feedback-section">
              <h3>Areas to improve</h3>
              <p>Personalised learning suggestions will appear here.</p>
            </div>
            <div className="feedback-section">
              <h3>AI Tutor message</h3>
              <p>Your personalised message will appear here.</p>
            </div>

            <button className="primary-button full-button" onClick={closeLearningModal}>
              Return to learning path
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function LessonCard({ lesson, completed, onClick }) {
  return (
    <button className={`lesson-card ${completed ? "is-completed" : ""}`} onClick={onClick}>
      <div className="lesson-card-top">
        <span className="lesson-number">{String(lesson.id).padStart(2, "0")}</span>
        <span className={`lesson-type ${lesson.type.toLowerCase()}`}>{lesson.type}</span>
      </div>
      <strong>{lesson.title}</strong>
      <span className="lesson-card-bottom">
        {completed ? "Completed" : "Open lesson"} <span>→</span>
      </span>
    </button>
  );
}

export default App
