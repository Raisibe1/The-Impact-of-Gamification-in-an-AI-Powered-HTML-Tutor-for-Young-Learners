HTML Tutor ML Dataset Package

ASSISTments:
- Contains correctness labels and attempt information.
- Use primarily for supervised performance/mastery prediction.
- Main file: ASSISTments_mastery_prediction_training.csv

EdNet-KT3 uploaded archive:
- The archive contains 100,229 learner CSV files and about 1.26 GB when uncompressed.
- To keep processing practical, a deterministic sample of 1,000 complete learner histories was processed.
- The KT3 files in this upload contain: timestamp, action_type, item_id, source, user_answer, platform.
- They do NOT contain a correctness/grade column or correct-answer key.
- Therefore, this EdNet sample is suitable for behavioural and sequential modelling, but cannot by itself train a correct-vs-incorrect mastery predictor.

Recommended modelling strategy:
1. Train/evaluate performance prediction on ASSISTments using correctness labels.
2. Use EdNet-KT3 for learner-behaviour and next-action/next-item sequence modelling.
3. Keep source_dataset visible if datasets are combined for shared descriptive analysis.
4. Do not claim that EdNet-KT3 response events are labelled correct/incorrect unless an external answer-key metadata file is added.

Important:
- recommended_action_rule columns are transparent rule-based policies, not ground-truth recommendation labels.
- mastery_proxy is an engineered proxy, not an official mastery annotation.
