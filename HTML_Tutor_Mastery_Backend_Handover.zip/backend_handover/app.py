"""FastAPI adapter for the HTML topic-mastery development model.

The endpoint returns a probability estimate only. It never awards mastery or
permits progression. Load only trusted model artifacts because joblib uses pickle.
"""
from __future__ import annotations

import math
import os
from pathlib import Path
from typing import Any

import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, ConfigDict, Field

ROOT = Path(__file__).resolve().parent
MODEL_PATH = Path(os.getenv("HTML_TUTOR_ML_MODEL_PATH", ROOT / "model" / "synthetic_topic_mastery_predictor.joblib"))
EXPECTED_FEATURES = [
    "practice_interaction_count", "unique_question_count", "first_attempt_accuracy",
    "final_accuracy", "recent5_first_attempt_accuracy", "recent3_first_attempt_accuracy",
    "unassisted_first_attempt_accuracy", "accuracy_without_hint", "accuracy_after_review",
    "accuracy_when_hinted", "mean_attempt_count", "hint_rate", "review_rate",
    "mean_review_visits", "mean_response_time_seconds", "median_response_time_seconds",
    "correct_streak_end", "mean_question_difficulty", "support_gap", "recent5_hint_rate",
    "recent5_review_rate", "last_interaction_first_correct", "first_vs_recent_accuracy_gain",
    "initial_wrong_recovery_rate", "unassisted_interaction_rate", "prior_topics_completed",
    "previous_topic_checkpoint_score", "prior_topic_checkpoint_score_mean",
    "previous_topic_mastery_label", "prior_topic_mastery_rate",
    "prior_topic_first_attempt_accuracy_mean", "prior_topic_unassisted_accuracy_mean",
    "prior_topic_hint_rate_mean", "prior_topic_review_rate_mean", "topic_id"
]
FRACTION_FEATURES = {
    "first_attempt_accuracy", "final_accuracy", "recent5_first_attempt_accuracy",
    "recent3_first_attempt_accuracy", "unassisted_first_attempt_accuracy", "accuracy_without_hint",
    "accuracy_after_review", "accuracy_when_hinted", "hint_rate", "review_rate",
    "recent5_hint_rate", "recent5_review_rate", "last_interaction_first_correct",
    "initial_wrong_recovery_rate", "unassisted_interaction_rate", "previous_topic_checkpoint_score",
    "prior_topic_checkpoint_score_mean", "previous_topic_mastery_label", "prior_topic_mastery_rate",
    "prior_topic_first_attempt_accuracy_mean", "prior_topic_unassisted_accuracy_mean",
    "prior_topic_hint_rate_mean", "prior_topic_review_rate_mean"
}
COUNT_FEATURES = {
    "practice_interaction_count", "unique_question_count", "mean_attempt_count", "mean_review_visits",
    "correct_streak_end", "prior_topics_completed"
}
ALLOWED_TOPICS = {f"T{i:03d}" for i in range(1, 10)}

app = FastAPI(title="HTML Topic Mastery Inference API", version="1.0.0",
              description="Development-only checkpoint-pass probability; not a progression decision.")

class PredictionRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    learner_id: str | None = Field(default=None, description="Optional pseudonymous ID for correlation/logging; do not send direct identifiers.")
    features: dict[str, Any]


def load_model():
    if not MODEL_PATH.is_file():
        raise FileNotFoundError(f"Model artifact not found at {MODEL_PATH}")
    model = joblib.load(MODEL_PATH)
    found = list(getattr(model, "feature_names_in_", []))
    if found != EXPECTED_FEATURES:
        raise ValueError(f"Model feature contract mismatch. Expected {EXPECTED_FEATURES}; got {found}")
    if list(getattr(model, "classes_", [])) != [0, 1]:
        raise ValueError("Expected binary classes [0, 1].")
    return model

MODEL = load_model()

@app.get("/health")
def health():
    return {"status": "ok", "model_loaded": True, "model_version": "synthetic-logistic-regression-dev-1.0",
            "evidence_status": "synthetic_data_only_not_validated_on_real_learners"}

@app.get("/schema")
def schema():
    return {"features": EXPECTED_FEATURES, "feature_count": len(EXPECTED_FEATURES),
            "allowed_topic_ids": sorted(ALLOWED_TOPICS), "null_allowed": True,
            "note": "Features must be computed from events before the current independent checkpoint."}

@app.post("/predict")
def predict(request: PredictionRequest):
    features = request.features
    missing = set(EXPECTED_FEATURES) - set(features)
    unknown = set(features) - set(EXPECTED_FEATURES)
    if missing:
        raise HTTPException(status_code=422, detail={"error": "missing_features", "features": sorted(missing)})
    if unknown:
        raise HTTPException(status_code=422, detail={"error": "unknown_features", "features": sorted(unknown)})
    if not isinstance(features.get("topic_id"), str) or features["topic_id"] not in ALLOWED_TOPICS:
        raise HTTPException(status_code=422, detail={"error": "invalid_topic_id", "allowed": sorted(ALLOWED_TOPICS)})

    row: dict[str, Any] = {}
    for name in EXPECTED_FEATURES[:-1]:
        value = features[name]
        if value is None:
            row[name] = None
            continue
        if isinstance(value, bool):
            raise HTTPException(status_code=422, detail={"error": "invalid_numeric_feature", "feature": name})
        try:
            numeric = float(value)
        except (TypeError, ValueError):
            raise HTTPException(status_code=422, detail={"error": "invalid_numeric_feature", "feature": name})
        if not math.isfinite(numeric):
            raise HTTPException(status_code=422, detail={"error": "non_finite_value", "feature": name})
        if name in FRACTION_FEATURES and not 0 <= numeric <= 1:
            raise HTTPException(status_code=422, detail={"error": "fraction_out_of_range", "feature": name, "expected": "0..1"})
        if name in COUNT_FEATURES and numeric < 0:
            raise HTTPException(status_code=422, detail={"error": "negative_count", "feature": name})
        if name in {"mean_response_time_seconds", "median_response_time_seconds", "mean_question_difficulty"} and numeric < 0:
            raise HTTPException(status_code=422, detail={"error": "negative_value", "feature": name})
        row[name] = numeric
    row["topic_id"] = features["topic_id"]
    try:
        probability = float(MODEL.predict_proba(pd.DataFrame([row], columns=EXPECTED_FEATURES))[0, 1])
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Model inference failed; check server logs.") from exc

    practice_count = row["practice_interaction_count"]
    cold_start = practice_count is None or practice_count == 0
    return {
        "prediction": {"probability_checkpoint_pass": round(probability, 6),
                       "predicted_class_at_0_50": int(probability >= 0.50)},
        "model": {"name": "HTML Topic Mastery Predictor", "version": "synthetic-logistic-regression-dev-1.0",
                  "status": "development_candidate_synthetic_data_only"},
        "data_quality": {"imputed_features": sorted([k for k, v in row.items() if v is None]),
                         "cold_start": cold_start,
                         "personalized_estimate": not cold_start},
        "safety": {"progression_authorized": False,
                   "required_next_step": "Use an independent checkpoint and approved prerequisite policy; do not progress based on this probability alone."}
    }
