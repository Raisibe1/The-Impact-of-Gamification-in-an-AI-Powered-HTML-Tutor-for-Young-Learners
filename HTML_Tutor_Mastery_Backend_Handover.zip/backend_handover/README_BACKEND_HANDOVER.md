# HTML Tutor — Backend Handover: Topic-Mastery Prediction API

**Package purpose:** expose the newly developed topic-mastery model to the HTML Tutor backend. This is the revised topic-mastery model, not the earlier ASSISTments next-interaction-correctness model.

## Important status and safety boundary

- The serialized model was trained and evaluated on **synthetic** learner interaction and checkpoint data. It has not been validated on real Grade 7–9 learners or live tutor events.
- It estimates the probability of passing a future independent topic checkpoint (development label: at least 4/5 correct). It does not directly observe mastery.
- Integrate in **shadow/advisory mode** first. Do not use the probability alone to award mastery, block a learner, or advance a learner. Progression must depend on the independent checkpoint and the separately approved prerequisite policy.
- The API expects all 35 features. `null` is allowed for numeric features that cannot yet be calculated; the saved pipeline imputes missing values and the API reports which were imputed. Do not fabricate values merely to avoid nulls.
- Feature values must be calculated only from events available **before** the current independent checkpoint. Prior-topic fields must contain prior topics only. Do not include current checkpoint scores or outcomes in the request.
- Only use trusted `.joblib` files: joblib artifacts use Python pickle serialization.

## Files included (minimal runtime handover)

- `app.py` — FastAPI inference adapter with health, schema and prediction endpoints.
- `model/synthetic_topic_mastery_predictor.joblib` — fitted preprocessing + Logistic Regression pipeline.
- `feature_contract.json` — canonical 35-feature names/order, target and evidence caveats.
- `requirements.txt` — runtime and test dependencies.
- `tests/test_api.py` — API smoke/validation tests.
- `README_BACKEND_HANDOVER.md` — this guide.

Training notebooks, synthetic training datasets, plots, research reports and question-bank editorial files are intentionally excluded from this runtime package.

## Step-by-step setup (Windows PowerShell)

1. Extract this package into a folder, e.g. `html-tutor-mastery-api`.
2. Install Python 3.11 (recommended) and ensure `python --version` works in PowerShell.
3. Open PowerShell in the extracted folder.
4. Create a virtual environment:

   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

5. Install dependencies:

   ```powershell
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```

6. Start the API:

   ```powershell
   uvicorn app:app --host 127.0.0.1 --port 8000
   ```

7. In a second PowerShell window, confirm the service is alive:

   ```powershell
   Invoke-RestMethod http://127.0.0.1:8000/health
   ```

8. Inspect the live feature schema:

   ```powershell
   Invoke-RestMethod http://127.0.0.1:8000/schema
   ```

9. Open interactive API documentation at `http://127.0.0.1:8000/docs`. Use `POST /predict` to test a request.
10. Run the included tests from the project folder:

   ```powershell
   pytest -q
   ```

## Step-by-step connection to the existing backend

1. **Agree the event schema first.** The tutor must persist practice events with stable learner pseudonym, topic ID, question ID, timestamp/order, first-attempt correctness, final correctness, attempt count, hint use, content-review visits, response time and question difficulty. Store checkpoint outcomes separately.
2. **Build the feature computation service.** Aggregate only current-topic practice history before the checkpoint and lagged history from completed prior topics. Match each feature definition in `feature_contract.json` and the research project's `data/processed/feature_dictionary.csv` (the latter remains in the full ML project, not this minimal package). The API does not calculate features from raw events; the backend must do that.
3. **Send all 35 feature keys.** Numeric values should be numbers, rates/accuracies fractions from 0 to 1 (not 0–100), and unavailable numeric values may be JSON `null`. `topic_id` must be one of `T001`–`T009`. Keep topic IDs stable between the curriculum database and the API.
4. **Call `POST /predict` from the backend server.** Do not call the ML service directly from browser JavaScript; keep it behind the backend and its authentication/network controls.
5. **Log the result in shadow mode.** Store the model version, probability, request timestamp, feature-computation version and the eventual independent checkpoint result. Use pseudonymous IDs and the project's approved privacy/consent controls. Avoid logging names, email addresses or other direct identifiers.
6. **Do not trigger progression from the response.** Initially display/use the result only for internal comparison or a non-binding support suggestion. An independent checkpoint and approved prerequisite policy remain authoritative.
7. **Test before deployment.** Verify health check, schema, valid request, missing-feature rejection, out-of-range values, null imputation, cold-start handling and backend timeouts. The API returns HTTP 422 for invalid input; treat network/5xx errors as unavailable prediction and fall back to the tutor's normal non-model flow.
8. **Deploy privately.** Configure `HTML_TUTOR_ML_MODEL_PATH` only if the artifact is mounted elsewhere. Restrict network access, add authentication/service-to-service authorization at the deployment layer, use HTTPS outside localhost, and pin tested dependency versions in the deployment lock file.
9. **Review before live learner use.** Get content-owner approval for independent checkpoint questions and required research/ethics approvals. Validate on real, appropriately consented learner data with a locked evaluation cohort before describing the model as validated or enabling consequential decisions.

## API contract

### `GET /health`

Returns service status, whether the model loaded, model version, and the synthetic-data evidence status.

### `GET /schema`

Returns the canonical feature names, feature count (35), accepted topic IDs and missing-value note.

### `POST /predict`

Request body shape:

```json
{
  "learner_id": "pseudonymous-learner-001",
  "features": {
    "practice_interaction_count": 8,
    "unique_question_count": 5,
    "first_attempt_accuracy": 0.6,
    "final_accuracy": 0.8,
    "recent5_first_attempt_accuracy": 0.6,
    "recent3_first_attempt_accuracy": 0.667,
    "unassisted_first_attempt_accuracy": 0.5,
    "accuracy_without_hint": 0.6,
    "accuracy_after_review": 0.8,
    "accuracy_when_hinted": 0.5,
    "mean_attempt_count": 1.5,
    "hint_rate": 0.25,
    "review_rate": 0.25,
    "mean_review_visits": 0.5,
    "mean_response_time_seconds": 24,
    "median_response_time_seconds": 20,
    "correct_streak_end": 2,
    "mean_question_difficulty": 2,
    "support_gap": 0.3,
    "recent5_hint_rate": 0.2,
    "recent5_review_rate": 0.2,
    "last_interaction_first_correct": 1,
    "first_vs_recent_accuracy_gain": 0.1,
    "initial_wrong_recovery_rate": 0.5,
    "unassisted_interaction_rate": 0.5,
    "prior_topics_completed": 1,
    "previous_topic_checkpoint_score": 0.8,
    "prior_topic_checkpoint_score_mean": 0.8,
    "previous_topic_mastery_label": 1,
    "prior_topic_mastery_rate": 1,
    "prior_topic_first_attempt_accuracy_mean": 0.7,
    "prior_topic_unassisted_accuracy_mean": 0.6,
    "prior_topic_hint_rate_mean": 0.2,
    "prior_topic_review_rate_mean": 0.2,
    "topic_id": "T002"
  }
}
```

These values are **illustrative only**, not a known learner record or a recommended default profile. The backend must compute values from its real event schema; unavailable values should be `null` rather than invented.

Successful response shape:

```json
{
  "prediction": {
    "probability_checkpoint_pass": 0.72,
    "predicted_class_at_0_50": 1
  },
  "model": {
    "name": "HTML Topic Mastery Predictor",
    "version": "synthetic-logistic-regression-dev-1.0",
    "status": "development_candidate_synthetic_data_only"
  },
  "data_quality": {
    "imputed_features": [],
    "cold_start": false,
    "personalized_estimate": true
  },
  "safety": {
    "progression_authorized": false,
    "required_next_step": "Use an independent checkpoint and approved prerequisite policy; do not progress based on this probability alone."
  }
}
```

The probability above is an example of the response format, not an actual prediction from the included model. `predicted_class_at_0_50` is a generic display field only; it is not a mastery decision or progression rule.

## Feature semantics

The feature list is the exact order expected by the saved pipeline. The backend should use the same definitions as the training pipeline. Accuracy and rate values are fractions in `[0, 1]`, not percentages. `support_gap` is final practice accuracy minus unassisted first-attempt accuracy and may be negative. Response-time and difficulty values must use the same units/scales used in training. For prior-topic features, include only evidence from topics completed before the current topic.

## Operational notes

- Model artifact path defaults to `model/synthetic_topic_mastery_predictor.joblib`; override with `HTML_TUTOR_ML_MODEL_PATH` if required.
- Do not retrain in production as part of starting the API. Deploy a reviewed, versioned artifact.
- Pin exact tested dependencies (e.g. via `pip freeze` or a lockfile) before deployment. The broad ranges in `requirements.txt` are for initial setup, not a substitute for a tested production lock.
- This package is a minimal inference service, not a complete production deployment: authentication, TLS, observability, rate limiting and deployment configuration belong to the backend/platform team.
