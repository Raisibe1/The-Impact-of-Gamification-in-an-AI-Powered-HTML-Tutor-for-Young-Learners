from fastapi.testclient import TestClient
from app import app, EXPECTED_FEATURES

client = TestClient(app)

def sample_features():
    row = {name: 0.5 for name in EXPECTED_FEATURES[:-1]}
    for name in ("practice_interaction_count", "unique_question_count", "mean_attempt_count", "mean_review_visits", "correct_streak_end", "prior_topics_completed"):
        row[name] = 5
    row["mean_response_time_seconds"] = 20
    row["median_response_time_seconds"] = 18
    row["mean_question_difficulty"] = 2
    row["topic_id"] = "T001"
    return row

def test_health():
    r = client.get('/health')
    assert r.status_code == 200 and r.json()['model_loaded'] is True

def test_schema_has_35_features():
    r = client.get('/schema')
    assert r.status_code == 200 and r.json()['feature_count'] == 35

def test_prediction_probability_and_safety_flag():
    r = client.post('/predict', json={'features': sample_features()})
    assert r.status_code == 200
    body = r.json()
    assert 0 <= body['prediction']['probability_checkpoint_pass'] <= 1
    assert body['safety']['progression_authorized'] is False

def test_missing_feature_rejected():
    row = sample_features(); row.pop('hint_rate')
    r = client.post('/predict', json={'features': row})
    assert r.status_code == 422

def test_fraction_out_of_range_rejected():
    row = sample_features(); row['hint_rate'] = 12
    r = client.post('/predict', json={'features': row})
    assert r.status_code == 422
