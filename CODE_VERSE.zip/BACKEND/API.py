import os
import time
import logging
from dotenv import load_dotenv
from google import genai
import math
from pydantic import BaseModel, EmailStr, Field
from  ml_inference import predict_checkpoint_pass, FEATURES


load_dotenv()
logger = logging.getLogger("tutor")
logging.basicConfig(level=logging.INFO)

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
GEMINI_MODEL   = os.getenv("GEMINI_MODEL", "gemini-flash-latest")

if not GEMINI_API_KEY:
    raise RuntimeError("Missing GEMINI_API_KEY in .env — see chatbot setup")

gemini = genai.Client(api_key=GEMINI_API_KEY)

import secrets
from datetime import datetime, timezone, timedelta
from fastapi import FastAPI, Request, Response, HTTPException, Form
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from connection import Database
from pwdlib import PasswordHash
from lessons import LESSON_CONTENT, get_lesson_by_slug

app = FastAPI(title = "Your Tutor API")


@app.on_event("startup")
def seed_lessons():
    db = Database()
    conn = db.get_connection()
    try:
        for lesson in LESSON_CONTENT:
            existing = conn.execute(
                "SELECT id FROM lessons WHERE slug = ?",
                (lesson["slug"],),
            ).fetchone()

            if existing is None:
                conn.execute(
                    """
                    INSERT INTO lessons (
                        slug, title, subtitle, description, icon,
                        order_index, xp_reward, is_locked
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        lesson["slug"],
                        lesson["title"],
                        lesson["subtitle"],
                        lesson["description"],
                        lesson["icon"],
                        lesson["order"],          # maps to order_index
                        lesson["xp_reward"],
                        0 if lesson["order"] == 1 else 1,
                    ),
                )
                print(f"[seed] inserted lesson: {lesson['slug']}")
            else:
                conn.execute(
                    """
                    UPDATE lessons
                       SET title       = ?,
                           subtitle    = ?,
                           description = ?,
                           icon        = ?,
                           order_index = ?,
                           xp_reward   = ?
                     WHERE slug        = ?
                    """,
                    (
                        lesson["title"],
                        lesson["subtitle"],
                        lesson["description"],
                        lesson["icon"],
                        lesson["order"],
                        lesson["xp_reward"],
                        lesson["slug"],
                    ),
                )

        conn.commit()
    finally:
        conn.close()
# Define the origins that are allowed to make requests
#frontend (port 5173) and backend (port 8000)
#browser will block requests from the frontend unless the backend explicitly allows it
#cross origin error

origins = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins, # In development, you can use ["*"] to allow all, but be specific in production
    allow_credentials=True,
    allow_methods=["*"], # Allows all methods (GET, POST, PUT, DELETE)
    allow_headers=["*"], # Allows all headers
)

app.mount("/static",StaticFiles(directory="static"),name="static")
templates = Jinja2Templates(directory="templates")

password_hash = PasswordHash.recommended()
session_len = 1


#Based on student's history, what probability they get the next question right?"
class PredictRequest(BaseModel):
    # We only need the student's history, but for testing 
    # we can allow passing features directly.
    features: dict

def sample_features():
    values = {name: 0.5 for name in FEATURES if name != "topic_id"}
    values.update({
        "practice_interaction_count": 8,
        "unique_question_count": 5,
        "mean_attempt_count": 1.5,
        "mean_review_visits": 0.5,
        "mean_response_time_seconds": 24,
        "median_response_time_seconds": 20,
        "correct_streak_end": 2,
        "mean_question_difficulty": 2,
        "prior_topics_completed": 1,
        "previous_topic_mastery_label": 1,
        "last_interaction_first_correct": 1,
        "topic_id": "T002",
    })
    return values

@app.post("/api/predict-next-correct")
def predict_next_correct(request: Request, payload: PredictRequest):
    # 1. Require auth (optional, but good if this is for a specific user)
    student = get_current_student(request)
    if student is None:
        raise HTTPException(status_code=401, detail="Not authenticated")

    if is_quiz_active(CODEVERSE_DB_PATH, student["student_id"]):
        raise HTTPException(status_code=423, detail="AI support is disabled during an active quiz.")

    #testing ML_Model
    try:
        features = sample_features()
        result = predict_checkpoint_pass(features)
        probability = float(result["probability_checkpoint_pass"])
        print("ML Prediction:",probability)

        return {
            "probability_checkpoint_pass": probability,
            "percentage": round(probability * 100, 2),
            "student_id": student["student_id"]
        }
    

    except ModelInputError as e:
        # This catches the errors you wrote in ml_inference.py (e.g. bad bounds)
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"ML Prediction failed: {e}")
        raise HTTPException(status_code=500, detail="Prediction failed")
        

def create_session(student_id: int):
    db = Database()
    conn = db.get_connection()

    session_id = secrets.token_urlsafe(32)
    expires_at = (
        datetime.now(timezone.utc)
        + timedelta(hours=session_len)
    )

    try:
        # Remove expired sessions
        conn.execute(
            """
            DELETE FROM sessions
            WHERE expires_at < ?
            """,
            (
                datetime.now(timezone.utc).isoformat(),
            )
        )

        # Create new session
        conn.execute(
            """
            INSERT INTO sessions (
                session_id,
                student_id,
                expires_at
            )
            VALUES (?, ?, ?)
            """,
            (
                session_id,
                student_id,
                expires_at.isoformat()
            )
        )

        conn.commit()

    finally:
        conn.close()

    return session_id

def set_session_cookie(response: Response,session_id: str):
    """
    Sends the session ID to the browser using
    a secure HttpOnly cookie.
    """
    response.set_cookie(
        key="session_id",
        value=session_id,

        # JavaScript cannot read this cookie
        httponly=True,

        # change this to True when using HTTPS
        secure=False,

        # Helps protect against CSRF
        samesite="lax",
        max_age=session_len * 60 * 60,
        path="/"
    )

class RegisterRequest(BaseModel):
    name: str
    surname: str
    school: str
    email: EmailStr
    password: str
    age_group: str | None = None
    learning_style: str | None = None
    goal: str | None = None

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

@app.post("/login")
def login(user: LoginRequest,response: Response):
    db = Database()
    conn = db.get_connection()

    try:
        student = conn.execute(
            """
            SELECT
                student_id,
                name,
                email,
                password_hash
            FROM students
            WHERE email = ?
            """,
            (user.email,)
        ).fetchone()

    finally:
        conn.close()

    if not student:
        raise HTTPException(
            status_code=401,
            detail="Invalid email or password!")

    #verify p/w
    isValid = password_hash.verify(user.password,student["password_hash"])

    if not isValid:
        raise HTTPException(
            status_code=401,
            detail="Invalid email or password")
    
    #create session
    session_id = create_session(student["student_id"])
    set_session_cookie(response,session_id)

    return {
        "message": "Login successful.",
        "student": {
            "student_id": student["student_id"],
            "name": student["name"],
            "email": student["email"]
        }
    }

#Create the chat endpoint
class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=5000)
    lesson_slug: str | None = None   # optional, for lesson-aware answers

class ChatResponse(BaseModel):
    reply: str

def _build_tutor_prompt(student, message: str, lesson_context: str) -> str:
    level          = (student["age_group"]      if student else None) or "Beginner"
    learning_style = (student["learning_style"] if student else None) or "general"
    goal           = (student["goal"]           if student else None) or "learn HTML fundamentals"

    context_block = (
        f"Lesson material the student is currently studying:\n{lesson_context}\n\n"
        if lesson_context else ""
    )

    return f"""You are a patient, encouraging HTML tutor.
        Student level: {level}
        Preferred learning style: {learning_style}
        Student's stated goal: {goal}

        {context_block}Student question:
        {message}

        Rules:
        - Explain step by step at the student's level.
        - Give a short code example when relevant.
        - Keep answers under ~200 words unless the student asks for depth.
        - End with one short check-for-understanding question.
        """


@app.post("/chat", response_model=ChatResponse)
def chat_with_tutor(request: Request, payload: ChatRequest):
    # 1. Require login (matches your session-cookie system)
    student = get_current_student(request)
    if student is None:
        raise HTTPException(status_code=401, detail="Please log in to chat with your tutor.")

    # No AI support while any CodeVerse unlock quiz is active.
    if is_quiz_active(CODEVERSE_DB_PATH, student["student_id"]):
        raise HTTPException(status_code=423, detail="AI tutoring is disabled during an active quiz.")

    # 2. Optionally pull lesson context
    lesson_context = ""
    if payload.lesson_slug:
        try:
            lesson = get_lesson_by_slug(payload.lesson_slug)
            if lesson:
                # adjust these keys to match your LESSON_CONTENT structure
                lesson_context = (
                    lesson.get("title")
                    or lesson.get("description")
                    or lesson.get("subtitle")
                    or ""
                )
        except Exception:
            logger.warning("Could not load lesson %s", payload.lesson_slug)

    prompt = _build_tutor_prompt(student, payload.message, lesson_context)

    # Generate the lesson-aware response using the Gemini Developer API.
    started = time.time()
    try:
        response = gemini.models.generate_content(
            model=GEMINI_MODEL,
            contents=prompt,
        )
        reply = (response.text or "").strip()
        if not reply:
            raise HTTPException(status_code=502, detail="AI tutor returned an empty response")
    except HTTPException:
        raise
    except Exception:
        logger.exception("Gemini call failed")
        raise HTTPException(status_code=502, detail="AI tutor is temporarily unavailable")

    elapsed = time.time() - started

    # 4. Persist to ai_interactions (already exists in your schema)
    try:
        db = Database()
        conn = db.get_connection()
        try:
            conn.execute(
                """
                INSERT INTO ai_interactions
                    (student_id, question_asked, response_generated,
                     response_time, timestamp, resolved)
                VALUES (?, ?, ?, ?, ?, 0)
                """,
                (
                    student["student_id"],
                    payload.message,
                    reply,
                    elapsed,
                    datetime.now(timezone.utc).isoformat(),
                ),
            )
            conn.commit()
        finally:
            conn.close()
    except Exception:
        # Never let logging kill the user's reply
        logger.exception("Failed to log ai_interaction")

    return ChatResponse(reply=reply)

@app.get("/")
def root(request: Request):
     # Check if the user has a valid session
    student = get_current_student(request)
    if student is None:
        # Not logged in -> redirect to the React login page
        return RedirectResponse("http://localhost:5173/", status_code=303)
    
    return templates.TemplateResponse(
        request=request,
        name="tutor.html",
        context={"student": dict(student)} # Optionally pass student data to the game

       )

@app.get("/javascript")
def javascript(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="javascript.html")

@app.get("/test")
def test(request: Request):
    student = get_current_student(request)
    if student is None:
        return RedirectResponse("http://localhost:5173/", status_code=303)
        
    return templates.TemplateResponse(
        request=request,
        name="test.html"
       )

@app.get("/login")
def login_page(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="login.html")

@app.get("/program")
def program(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="program.html"
    )

@app.get("/tutor")
def tutor(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="tutor.html"
    )


@app.get("/registration")
def registration(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="registration.html")

def get_current_student(request: Request):
    """
    Reads the 'session_id' cookie, validates it against the sessions table,
    and returns the matching student row (sqlite3.Row) or None.
    """
    session_id = request.cookies.get("session_id")
    if not session_id:
        return None

    db = Database()
    conn = db.get_connection()
    try:
        row = conn.execute(
            """
            SELECT s.student_id
            FROM sessions s
            WHERE s.session_id = ?
              AND s.expires_at > ?
            """,
            (session_id, datetime.now(timezone.utc).isoformat()),
        ).fetchone()

        if row is None:
            return None

        student = conn.execute(
            "SELECT * FROM students WHERE student_id = ?",
            (row["student_id"],),
        ).fetchone()

        return student  # sqlite3.Row or None
    finally:
        conn.close()

@app.get("/api/benchmark/status")
def benchmark_status(request: Request):

    student = get_current_student(request)
    if student is None:
        raise HTTPException(
            status_code=401,
            detail="Please log in to access the benchmark."
        )

    student_id = student["student_id"]
    db = Database()
    conn = db.get_connection()

    try:
        #get the learner's pre-test record
        pre_test = conn.execute(
            """
            SELECT
                attempt_id,
                status,
                mcq_score,
                practical_score,
                total_score,
                submitted_at
            FROM benchmark_attempts
            WHERE student_id = ?
              AND assessment_type = 'pre'
            """,
            (student_id,)
        ).fetchone()

        #Check assessment completion
        completed = (
            pre_test is not None
            and pre_test["status"] == "submitted"
        )

        return {
            "student_id": student_id,
            "pre_test_completed": completed,
            "lessons_unlocked": completed,
            "pre_test": {
                "attempt_id": pre_test["attempt_id"],
                "status": pre_test["status"],
                "mcq_score": pre_test["mcq_score"],
                "practical_score": pre_test["practical_score"],
                "total_score": pre_test["total_score"],
                "submitted_at": pre_test["submitted_at"]
            } if pre_test else None
        }

    finally:
        conn.close()

#start bench mark test
@app.post("/api/benchmark/start")
def start_benchmark(request: Request):
    student = get_current_student(request)

    if student is None:
        raise HTTPException(
            status_code=401,
            detail="Please log in to start the benchmark."
        )

    student_id = student["student_id"]
    db = Database()
    conn = db.get_connection()

    try:
        # Create only one official pre-test per learner.
        conn.execute(
            """
            INSERT OR IGNORE INTO benchmark_attempts
                (student_id, assessment_type, status, started_at)
            VALUES (?, 'pre', 'in_progress', ?)
            """,
            (
                student_id,
                datetime.now(timezone.utc).isoformat()
            )
        )

        conn.commit()
        attempt = conn.execute(
            """
            SELECT attempt_id, status, started_at
            FROM benchmark_attempts
            WHERE student_id = ?
              AND assessment_type = 'pre'
            """,
            (student_id,)
        ).fetchone()

        if attempt is None:
            raise HTTPException(
                status_code=500,
                detail="Unable to create benchmark."
            )

        if attempt["status"] == "submitted":
            raise HTTPException(
                status_code=409,
                detail="You have already submitted your pre-test."
            )

        started_at = datetime.fromisoformat(
            attempt["started_at"]
        )

        if started_at.tzinfo is None:
            started_at = started_at.replace(
                tzinfo=timezone.utc
            )

        deadline = started_at + timedelta(minutes=30)
        now = datetime.now(timezone.utc)

        if attempt["status"] == "expired" or now >= deadline:

            if attempt["status"] == "in_progress":
                conn.execute(
                    """
                    UPDATE benchmark_attempts
                    SET status = 'expired'
                    WHERE attempt_id = ?
                      AND status = 'in_progress'
                    """,
                    (attempt["attempt_id"],)
                )
                conn.commit()

            raise HTTPException(
                status_code=410,
                detail="Your benchmark session has expired."
            )

        return {
            "message": "Benchmark session ready.",
            "attempt_id": attempt["attempt_id"],
            "student_id": student_id,
            "assessment_type": "pre",
            "status": "in_progress",
            "started_at": started_at.isoformat(),
            "expires_at": deadline.isoformat(),
            "time_remaining_seconds": max(
                0, int((deadline - now).total_seconds())
            )
        }

    finally:
        conn.close()


# SUBMIT BENCHMARK
# ============================================
import json
from typing import Literal

# Temporary backend-only marking key.
BENCHMARK_MCQ_KEY = dict(enumerate(
    (
        "BACBA"
        "BCABC"
        "ABCBA"
        "CBACB"
        "ACBAC"
        "BACAB"
        "ACBAC"
        "ABACB"
    ),
    start=1
))

class BenchmarkSubmitRequest(BaseModel):
    attempt_id: int
    answers: dict[str, Literal["A", "B", "C"]]
    text_answers: dict[str, str]

@app.post("/api/benchmark/submit")
def submit_benchmark(
    request: Request,
    payload: BenchmarkSubmitRequest
):
    student = get_current_student(request)
    if student is None:
        raise HTTPException(
            status_code=401,
            detail="Please log in."
        )

    student_id = student["student_id"]
    now = datetime.now(timezone.utc)

    # Validate the question IDs.
    valid_mcq = {str(i) for i in range(1, 41)}
    valid_text = {str(i) for i in range(41, 51)}

    if not set(payload.answers).issubset(valid_mcq):
        raise HTTPException(
            status_code=422,
            detail="Invalid multiple-choice question ID."
        )

    if not set(payload.text_answers).issubset(valid_text):
        raise HTTPException(
            status_code=422,
            detail="Invalid practical question ID."
        )

    if any(
        len(answer) > 10000
        for answer in payload.text_answers.values()
    ):
        raise HTTPException(
            status_code=422,
            detail="A practical answer is too long."
        )

    db = Database()
    conn = db.get_connection()

    try:
        # Acquire a write lock to prevent concurrent
        # submissions from both being accepted.
        conn.execute("BEGIN IMMEDIATE")

        attempt = conn.execute(
            """
            SELECT attempt_id, status, started_at
            FROM benchmark_attempts
            WHERE attempt_id = ?
              AND student_id = ?
              AND assessment_type = 'pre'
            """,
            (payload.attempt_id, student_id)
        ).fetchone()

        if attempt is None:
            raise HTTPException(
                status_code=404,
                detail="Benchmark attempt not found."
            )

        if attempt["status"] != "in_progress":
            raise HTTPException(
                status_code=409,
                detail="Benchmark is no longer active."
            )

        started = datetime.fromisoformat(
            attempt["started_at"]
        )

        if started.tzinfo is None:
            started = started.replace(
                tzinfo=timezone.utc
            )

        deadline = started + timedelta(minutes=30)

        if now >= deadline:
            conn.execute(
                """
                UPDATE benchmark_attempts
                SET status = 'expired'
                WHERE attempt_id = ?
                """,
                (payload.attempt_id,)
            )
            conn.commit()

            raise HTTPException(
                status_code=410,
                detail="Benchmark time has expired."
            )

        # Missing MCQ answers score zero.
        mcq_score = sum(
            payload.answers.get(str(number))
            == correct
            for number, correct
            in BENCHMARK_MCQ_KEY.items()
        )

        saved_answers = json.dumps({
            "mcq": payload.answers,
            "practical": payload.text_answers
        })

        conn.execute(
            """
            UPDATE benchmark_attempts
            SET
                answers_json = ?,
                mcq_score = ?,
                practical_score = NULL,
                total_score = NULL,
                status = 'submitted',
                submitted_at = ?,
                time_spent_seconds = ?
            WHERE attempt_id = ?
            """,
            (
                saved_answers,
                mcq_score,
                now.isoformat(),
                max(0, int(
                    (now - started).total_seconds()
                )),
                payload.attempt_id
            )
        )

        conn.commit()

        return {
            "message": "Benchmark submitted successfully.",
            "attempt_id": payload.attempt_id,
            "status": "submitted",
            "mcq_score": mcq_score,
            "mcq_total": 40,
            "practical_score": None,
            "total_score": None,
            "grading_status": "pending_review",
            "pre_test_completed": True,
            "lessons_unlocked": True
        }

    except Exception:
        conn.rollback()
        raise

    finally:
        conn.close()



# ==========================================
# BENCHMARK ACCESS CONTROL
# ==========================================

def require_completed_benchmark(student_id: int):
    db = Database()
    conn = db.get_connection()

    try:
        completed = conn.execute(
            """
            SELECT 1
            FROM benchmark_attempts
            WHERE student_id = ?
              AND assessment_type = 'pre'
              AND status = 'submitted'
            LIMIT 1
            """,
            (student_id,)
        ).fetchone()

        if completed is None:
            raise HTTPException(
                status_code=403,
                detail=(
                    "Complete your HTML benchmark "
                    "before accessing lessons."
                )
            )

        return True

    finally:
        conn.close()

# Add this new endpoint anywhere in your API.py
@app.get("/api/me")
def get_me(request: Request):
    # This uses your existing helper function!
    student = get_current_student(request)
    
    if student is None:
        # If no valid session, return a 401 Unauthorized
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    # Return JSON data to React (excluding the password hash for security)
    return {
        "student_id": student["student_id"],
        "name": student["name"],
        "surname": student["surname"],
        "email": student["email"],
        "school": student["school"],
        "age_group": student["age_group"],
        "learning_style": student["learning_style"],
        "goal": student["goal"]
    }

@app.get("/profile")
def me(request: Request):
    # ---- identify current student via session cookie ----
    student = get_current_student(request)
    if student is None:
        return RedirectResponse("/login", status_code=303)

    student_id = student["student_id"]

    db = Database()
    conn = db.get_connection()
    try:
        # ---- module progress (joined with module titles) ----
        modules = conn.execute(
            """
            SELECT
                m.module_id,
                m.title,
                m.difficulty_level,
                m.category,
                p.status,
                p.attempts,
                p.score,
                p.time_spent
            FROM webdev_modules m
            LEFT JOIN student_progress p
                   ON p.module_id = m.module_id
                  AND p.student_id = ?
            ORDER BY m.module_id
            """,
            (student_id,),
        ).fetchall()

        total_modules       = len(modules)
        completed_modules   = sum(1 for m in modules if m["status"] == "completed")
        in_progress_modules = sum(1 for m in modules if m["status"] == "in_progress")
        completion_pct      = round(completed_modules / total_modules * 100) if total_modules else 0

        scored    = [m["score"] for m in modules if m["score"] is not None]
        avg_score = round(sum(scored) / len(scored)) if scored else 0
        total_time = sum(m["time_spent"] or 0 for m in modules)

        stats = {
            "total_modules":       total_modules,
            "completed_modules":   completed_modules,
            "in_progress_modules": in_progress_modules,
            "completion_pct":      completion_pct,
            "avg_score":           avg_score,
            "total_time":          total_time,
        }

        # ---- engagement (latest row) ----
        eng_row = conn.execute(
            """
            SELECT * FROM engagement_data
            WHERE student_id = ?
            ORDER BY engagement_id DESC LIMIT 1
            """,
            (student_id,),
        ).fetchone()
        engagement = dict(eng_row) if eng_row else {
            "login_frequency": 0, "streak_days": 0, "last_active": None,
            "forum_questions": 0, "help_requests": 0,
        }

        # ---- behavioural data (latest row) ----
        beh_row = conn.execute(
            """
            SELECT * FROM behavioral_data
            WHERE student_id = ?
            ORDER BY behavior_id DESC LIMIT 1
            """,
            (student_id,),
        ).fetchone()
        behavior = dict(beh_row) if beh_row else {
            "time_on_lesson": 0, "pauses": 0, "replays_video": False,
            "code_runs": 0, "errors_per_run": 0, "time_to_fix_error": 0,
            "hints_used": 0, "skips": 0, "abandon_rate": 0.0,
        }

        # ---- recent submissions ----
        # NOTE: your schema has no 'total_tests' column, so we compute a rough
        # total from passed_tests (adjust if you later add a real column).
        submissions_rows = conn.execute(
            """
            SELECT s.submission_id, s.language, s.passed_tests, s.timestamp,
                   m.title AS module_title
            FROM code_submissions s
            LEFT JOIN webdev_modules m ON m.module_id = s.module_id
            WHERE s.student_id = ?
            ORDER BY s.timestamp DESC
            LIMIT 5
            """,
            (student_id,),
        ).fetchall()

        submissions = []
        for s in submissions_rows:
            d = dict(s)
            d["total_tests"] = max(d["passed_tests"] or 0, 1)
            submissions.append(d)

        # ---- mistake patterns ----
        mistakes = conn.execute(
            """
            SELECT error_type, frequency, pattern_description
            FROM mistake_patterns
            WHERE student_id = ?
            ORDER BY frequency DESC
            LIMIT 5
            """,
            (student_id,),
        ).fetchall()

        # ---- AI interactions ----
        ai_interactions = conn.execute(
            """
            SELECT question_asked, hint_given, response_generated,
                   resolved, response_time, timestamp
            FROM ai_interactions
            WHERE student_id = ?
            ORDER BY interaction_id DESC
            LIMIT 5
            """,
            (student_id,),
        ).fetchall()

        # ---- quiz score mini-chart (map module scores to bars) ----
        quiz_scores = [
            {"label": f"M{m['module_id']}", "score": int(m["score"])}
            for m in modules
            if m["score"] is not None
        ][-6:]

        performance = {
            "quizzes_passed":   completed_modules,
            "projects_pending": max(0, total_modules - completed_modules),
        }

        return templates.TemplateResponse(
            request=request,
            name="profile.html",
            context={
                "student":         dict(student),
                "stats":           stats,
                "engagement":      engagement,
                "behavior":        behavior,
                "modules":         [dict(m) for m in modules],
                "submissions":     submissions,
                "mistakes":        [dict(m) for m in mistakes],
                "ai_interactions": [dict(i) for i in ai_interactions],
                "quiz_scores":     quiz_scores,
                "performance":     performance,
            },
        )
    finally:
        conn.close()
        
@app.post("/logout")
def logout(response: Response):
    response.delete_cookie(
        key="session_id",
        path="/",
        httponly=True,
        samesite="lax"
    )
    return {"message": "Logged out successfully"}
    
@app.post("/register")
def register(user: RegisterRequest,response: Response):
    db = Database()
    conn = db.get_connection()

    if len(user.password) < 8:
        raise HTTPException(
            status_code=400,
            detail="Password must be at least 8 characters."
        )

    try:
        # Check whether email already exists
        existing_student = conn.execute(
            """
            SELECT student_id
            FROM students
            WHERE email = ?
            """,
            (user.email,)
        ).fetchone()

        if existing_student:
            raise HTTPException(
                status_code=400,
                detail="Email is already registered."
            )

        hashed_password = password_hash.hash(user.password)

        # Create student
        cursor = conn.execute(
            """
            INSERT INTO students (
                name,
                surname,
                school,
                email,
                age_group,
                learning_style,
                password_hash,
                goal
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                user.name,
                user.surname,
                user.school,
                user.email,
                user.age_group,
                user.learning_style,
                hashed_password,
                user.goal
            )
        )

        conn.commit()
        student_id = cursor.lastrowid

    finally:
        conn.close()

    session_id = create_session(student_id)
    set_session_cookie(response,session_id)

    return {
        "message": "Registration successful.",
        "student_id": student_id
    }


@app.get("/me/edit")
def edit_profile_page(request: Request):
    student = get_current_student(request)
    if student is None:
        return RedirectResponse("/login", status_code=303)

    return templates.TemplateResponse(
        request=request,
        name="edit_profile.html",
        context={"student": dict(student)},
    )


@app.post("/me/edit")
def update_profile(
    request: Request,
    name: str = Form(...),
    surname: str = Form(...),
    school: str = Form(...),
    email: str = Form(...),
    age_group: str = Form(""),
    learning_style: str = Form(""),
    goal: str = Form(...),
):
    student = get_current_student(request)
    if student is None:
        return RedirectResponse("/login", status_code=303)

    student_id = student["student_id"]

    db = Database()
    conn = db.get_connection()
    try:
        # guard against email collisions (email is UNIQUE)
        existing = conn.execute(
            "SELECT student_id FROM students WHERE email = ? AND student_id != ?",
            (email.strip(), student_id),
        ).fetchone()

        if existing:
            return templates.TemplateResponse(
                request=request,
                name="edit_profile.html",
                context={
                    "student": dict(student),
                    "error": "That email is already in use by another account.",
                },
                status_code=400,
            )

        conn.execute(
            """
            UPDATE students
               SET name = ?,
                   surname = ?,
                   school = ?,
                   email = ?,
                   age_group = ?,
                   learning_style = ?,
                   goal = ?
             WHERE student_id = ?
            """,
            (
                name.strip(),
                surname.strip(),
                school.strip(),
                email.strip(),
                age_group.strip() or None,
                learning_style.strip() or None,
                goal.strip(),
                student_id,
            ),
        )
        conn.commit()
    finally:
        conn.close()

    return RedirectResponse("/profile", status_code=303)


# =====================================================================
# GAME STATE API
# =====================================================================
# All routes require a valid session cookie (student_id resolved via
# get_current_student). All write the corresponding tables:
#   user_xp, xp_events, user_progress, user_badges.
# =====================================================================

XP_PER_LEVEL = 100

class XPRequest(BaseModel):
    amount: int
    reason: str
    lesson_slug: str | None = None
    challenge_slug: str | None = None

class ProgressRequest(BaseModel):
    lesson_slug: str
    challenge_slug: str | None = None
    completed: bool = True
    score: float | None = None
    response_data: str | None = None

class BadgeRequest(BaseModel):
    slug: str

def _ensure_user_xp(conn, student_id: int) -> None:
    """Create a user_xp row if the student doesn't have one yet."""
    conn.execute(
        """
        INSERT OR IGNORE INTO user_xp
            (student_id, total_xp, level, current_streak, longest_streak, updated_at)
        VALUES (?, 0, 1, 0, 0, ?)
        """,
        (student_id, datetime.now(timezone.utc).isoformat()),
    )

def _resolve_challenge_id(conn, lesson_slug: str, challenge_slug: str | None):
    """Map (lesson_slug, challenge_slug) -> challenges.id, or None."""
    if not challenge_slug:
        return None

    row = conn.execute(
        """
        SELECT c.id
          FROM challenges c
          JOIN lessons l ON l.id = c.lesson_id
         WHERE l.slug = ? AND c.slug = ?
        """,
        (lesson_slug, challenge_slug),
    ).fetchone()

    if row is None:
        print(f"[warn] unknown challenge: lesson='{lesson_slug}' challenge='{challenge_slug}'")
        return None

    return row["id"] if row else None

@app.get("/api/state")
def api_state(request: Request):
    """Return the full game state for the logged-in student."""
    student = get_current_student(request)
    if student is None:
        raise HTTPException(status_code=401, detail="Not authenticated")

    sid = student["student_id"]
    db = Database()
    conn = db.get_connection()
    try:
        _ensure_user_xp(conn, sid)
        conn.commit()

        xp_row = conn.execute(
            """
            SELECT total_xp, level, current_streak, longest_streak, last_active
              FROM user_xp
             WHERE student_id = ?
            """,
            (sid,),
        ).fetchone()

        badges = conn.execute(
            """
            SELECT b.slug, b.name, b.description, b.icon, ub.earned_at
              FROM user_badges ub
              JOIN badges b ON b.id = ub.badge_id
             WHERE ub.student_id = ?
            """,
            (sid,),
        ).fetchall()

        progress = conn.execute(
            """
            SELECT l.slug AS lesson_slug,
                   c.slug AS challenge_slug,
                   up.completed,
                   up.score,
                   up.response_data,
                   up.attempts
              FROM user_progress up
              LEFT JOIN lessons    l ON l.id = up.lesson_id
              LEFT JOIN challenges c ON c.id = up.challenge_id
             WHERE up.student_id = ?
            """,
            (sid,),
        ).fetchall()

        return {
            "xp": dict(xp_row),
            "badges": [dict(b) for b in badges],
            "progress": [dict(p) for p in progress],
        }
    finally:
        conn.close()


@app.post("/api/xp")
def api_award_xp(request: Request, payload: XPRequest):
    """Insert an xp_event, add to user_xp.total_xp, recompute level."""
    student = get_current_student(request)
    if student is None:
        raise HTTPException(status_code=401, detail="Not authenticated")

    sid = student["student_id"]
    db = Database()
    conn = db.get_connection()

    print("Trying to reward a student")
    print("---------------------------")
    print(payload.lesson_slug)
    print(payload.challenge_slug)
    print("-----------------------")
    try:
        challenge_id = _resolve_challenge_id(
            conn, payload.lesson_slug, payload.challenge_slug
        )

        if payload.challenge_slug and challenge_id is None:
            raise HTTPException(
                status_code=404,
                detail=f"Unknown challenge '{payload.challenge_slug}' for lesson '{payload.lesson_slug}'"
            )
            
        now = datetime.now(timezone.utc).isoformat()

        _ensure_user_xp(conn, sid)

        conn.execute(
            """
            INSERT INTO xp_events (student_id, amount, reason, challenge_id, created_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            (sid, payload.amount, payload.reason, challenge_id, now),
        )

        conn.execute(
            """
            UPDATE user_xp
               SET total_xp = total_xp + ?,
                   updated_at = ?
             WHERE student_id = ?
            """,
            (payload.amount, now, sid),
        )

        row = conn.execute(
            "SELECT total_xp FROM user_xp WHERE student_id = ?", (sid,)
        ).fetchone()
        new_total = row["total_xp"]
        new_level = (new_total // XP_PER_LEVEL) + 1

        conn.execute(
            "UPDATE user_xp SET level = ? WHERE student_id = ?",
            (new_level, sid),
        )
        conn.commit()

        return {"total_xp": new_total, "level": new_level, "awarded": payload.amount}
    finally:
        conn.close()


@app.post("/api/progress")
def api_save_progress(request: Request, payload: ProgressRequest):
    """Upsert a row in user_progress for (student, lesson[, challenge])."""
    student = get_current_student(request)
    if student is None:
        raise HTTPException(status_code=401, detail="Not authenticated")

    sid = student["student_id"]
    db = Database()
    conn = db.get_connection()
    print("Server looking for this slug!")
    print("----------------------------------")
    print(payload.lesson_slug)
    print(payload.challenge_slug)
    print("---------------------------------")
    
    try:
        lesson = conn.execute(
            "SELECT id FROM lessons WHERE slug = ?", (payload.lesson_slug,)
        ).fetchone()

        if not lesson:
            print("This lesson DO NOT EXIST, challenge?")
            print(payload.lesson_slug)
            raise HTTPException(status_code=404, detail="Lesson not found")
        
        else:
            print("HERES WHATS |REAL")
            print(lesson)
            print(lesson["id"])


        lesson_id = lesson["id"]
        challenge = conn.execute(
            """
            SELECT id
            FROM challenges
            WHERE slug = ?
            """,
            (payload.challenge_slug,),
        ).fetchone()

        if challenge is None:
            print(payload.challenge_slug)
            print("AGAIN its not even a real challenge")
            raise HTTPException(
                status_code=404,
                detail=f"Challenge '{payload.challenge_slug}' not found for lesson '{payload.lesson_slug}'."
            )

        challenge_id = challenge["id"]
        now = datetime.now(timezone.utc).isoformat()

        existing = conn.execute(
            """
            SELECT id FROM user_progress
             WHERE student_id = ?
               AND lesson_id = ?
               AND (challenge_id IS ? OR challenge_id = ?)
            """,
            (sid, lesson_id, challenge_id, challenge_id),
        ).fetchone()

        if existing:
            conn.execute(
                """
                UPDATE user_progress
                   SET completed     = ?,
                       score         = COALESCE(?, score),
                       response_data = COALESCE(?, response_data),
                       attempts      = attempts + 1,
                       completed_at  = CASE WHEN ? = 1 THEN ? ELSE completed_at END,
                       updated_at    = ?
                 WHERE id = ?
                """,
                (
                    1 if payload.completed else 0,
                    payload.score,
                    payload.response_data,
                    1 if payload.completed else 0,
                    now,
                    now,
                    existing["id"],
                ),
            )
        else:
            conn.execute(
                """
                INSERT INTO user_progress
                    (student_id, challenge_id, lesson_id, completed, score,
                     attempts, response_data, first_started_at, completed_at, updated_at)
                VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?, ?)
                """,
                (
                    sid,
                    challenge_id,
                    lesson_id,
                    1 if payload.completed else 0,
                    payload.score,
                    payload.response_data,
                    now,
                    now if payload.completed else None,
                    now,
                ),
            )

        conn.commit()
        return {"ok": True}
    finally:
        conn.close()


@app.post("/api/badges/unlock")
def api_unlock_badge(request: Request, payload: BadgeRequest):
    """Award a badge by slug (idempotent — one user_badges row per badge)."""
    student = get_current_student(request)
    if student is None:
        raise HTTPException(status_code=401, detail="Not authenticated")

    sid = student["student_id"]
    db = Database()
    conn = db.get_connection()
    try:
        badge = conn.execute(
            "SELECT id, name, description FROM badges WHERE slug = ?",
            (payload.slug,),
        ).fetchone()

        print("--S--L--U--G-------")
        print("select id, name, description from badges where slug = ?(payload.slug,)")
        print(payload.slug)
        if not badge:
            raise HTTPException(status_code=404, detail="Badge not found")

        already = conn.execute(
            "SELECT id FROM user_badges WHERE student_id = ? AND badge_id = ?",
            (sid, badge["id"]),
        ).fetchone()

        if already:
            return {"unlocked": False, "name": badge["name"]}

        conn.execute(
            """
            INSERT INTO user_badges (student_id, badge_id, earned_at)
            VALUES (?, ?, ?)
            """,
            (sid, badge["id"], datetime.now(timezone.utc).isoformat()),
        )
        conn.commit()
        return {
            "unlocked": True,
            "name": badge["name"],
            "description": badge["description"],
        }
    finally:
        conn.close()


@app.post("/api/reset")
def api_reset(request: Request):
    """Wipe the logged-in student's game state (dev / start-over)."""
    student = get_current_student(request)
    if student is None:
        raise HTTPException(status_code=401, detail="Not authenticated")

    sid = student["student_id"]
    db = Database()
    conn = db.get_connection()
    try:
        conn.execute("DELETE FROM user_progress WHERE student_id = ?", (sid,))
        conn.execute("DELETE FROM user_badges   WHERE student_id = ?", (sid,))
        conn.execute("DELETE FROM xp_events     WHERE student_id = ?", (sid,))
        conn.execute(
            """
            UPDATE user_xp
               SET total_xp = 0, level = 1, current_streak = 0,
                   longest_streak = 0, updated_at = ?
             WHERE student_id = ?
            """,
            (datetime.now(timezone.utc).isoformat(), sid),
        )
        conn.commit()
        return {"ok": True}
    finally:
        conn.close()

# =====================================================================
# CODEVERSE LEARNING PATH: server-graded quiz, progress and lesson AI
# =====================================================================
# These additive tables are separate from existing game user_progress.
# Uses your existing sessions table and authenticated student resolver.
from pathlib import Path as _Path
from fastapi.concurrency import run_in_threadpool as _run_in_threadpool
from backend.learning_routes import (
    initialize_learning_db, learning_router, is_quiz_active,
)


def _codeverse_existing_db_path() -> _Path:
    """Resolve the SAME SQLite file used by connection.Database."""
    db = Database()
    conn = db.get_connection()
    try:
        for row in conn.execute("PRAGMA database_list").fetchall():
            if row[1] == "main" and row[2]:
                return _Path(row[2]).resolve()
    finally:
        conn.close()
    raise RuntimeError("connection.Database must use a file-backed SQLite database")


CODEVERSE_DB_PATH = _codeverse_existing_db_path()
initialize_learning_db(CODEVERSE_DB_PATH)


def _codeverse_student_id(request: Request) -> int:
    student = get_current_student(request)
    if student is None:
        raise HTTPException(status_code=401, detail="Please log in to continue")
    return int(student["student_id"])


async def _codeverse_lesson_reply(lesson_id: str, lesson_title: str, question: str) -> str:
    """Provide a Gemini study response to the lesson router."""
    prompt = _build_tutor_prompt(
        None, question,
        f"Current lesson {lesson_id}: {lesson_title}. "
        "Focus on explaining the lesson concept, not on grading an assessment."
    )
    def _request():
        response = gemini.models.generate_content(model=GEMINI_MODEL, contents=prompt)
        return (response.text or "").strip()
    try:
        answer = await _run_in_threadpool(_request)
    except Exception:
        logger.exception("CodeVerse lesson tutor request failed")
        raise HTTPException(status_code=502, detail="AI tutor temporarily unavailable")
    if not answer:
        raise HTTPException(status_code=502, detail="AI tutor returned an empty response")
    return answer


app.include_router(learning_router(
    CODEVERSE_DB_PATH,
    _codeverse_student_id,
    chat_reply=_codeverse_lesson_reply,
))

# =====================================================================
# CodeVerse Assessment Revision (append to your EXISTING API.py)
# Uses your existing app, Database, get_current_student, and session cookie.
# No benchmark_routes.py required.
# =====================================================================
import json
from typing import Literal
from pydantic import BaseModel, Field

_PRE_ANSWERS = {
    "2": "B", "3": "B", "4": "A", "5": "C", "6": "B",
    "7": "A", "8": "C", "9": "B", "10": "A", "11": "A",
}
_PRE_BACKGROUNDS = {
    'Yes, I have built my own web pages before.',
    'Yes, but I have only seen it or tried it a tiny bit.',
    'No, I have never done HTML before.',
}

# Only the backend has this key. Matches the original 50-question final exam.
_FINAL_MCQ_ANSWERS = {
    1:'B', 2:'A', 3:'C', 4:'B', 5:'A',
    6:'B', 7:'C', 8:'A', 9:'B', 10:'C',
    11:'A', 12:'B', 13:'C', 14:'B', 15:'A',
    16:'C', 17:'B', 18:'A', 19:'C', 20:'B',
    21:'A', 22:'C', 23:'B', 24:'A', 25:'C',
    26:'B', 27:'A', 28:'C', 29:'A', 30:'B',
    31:'A', 32:'C', 33:'B', 34:'A', 35:'C',
    36:'A', 37:'B', 38:'A', 39:'C', 40:'B'
}


class PreAssessmentSubmission(BaseModel):
    background: str = Field(min_length=1, max_length=150)
    answers: dict[str, Literal['A', 'B', 'C']]


class FinalAssessmentSubmission(BaseModel):
    attempt_id: int = Field(gt=0)
    answers: dict[str, Literal['A', 'B', 'C']]
    text_answers: dict[str, str]


def _assessment_student(request: Request) -> int:
    student = get_current_student(request)
    if student is None:
        raise HTTPException(401, 'Please log in to use assessments.')
    return int(student['student_id'])


@app.on_event('startup')
def ensure_pre_assessment_schema():
    db = Database()
    conn = db.get_connection()
    try:
        conn.execute('''CREATE TABLE IF NOT EXISTS pre_assessment_attempts (
            attempt_id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL UNIQUE,
            background TEXT NOT NULL,
            answers_json TEXT NOT NULL,
            score INTEGER NOT NULL CHECK (score BETWEEN 0 AND 10),
            status TEXT NOT NULL DEFAULT 'submitted' CHECK(status = 'submitted'),
            submitted_at TEXT NOT NULL,
            FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE
        )''')
        conn.commit()
    finally:
        conn.close()


@app.get('/api/pre-assessment/status')
def pre_assessment_status(request: Request):
    sid = _assessment_student(request)
    db = Database()
    conn = db.get_connection()
    try:
        row = conn.execute('''SELECT attempt_id, score, submitted_at FROM pre_assessment_attempts
                              WHERE student_id=? AND status='submitted' ''', (sid,)).fetchone()
        completed = row is not None
        return {
            'student_id': sid,
            'pre_test_completed': completed,
            'lessons_unlocked': completed,
            'pre_test': dict(row) if row else None,
        }
    finally:
        conn.close()


@app.post('/api/pre-assessment/submit')
def pre_assessment_submit(request: Request, payload: PreAssessmentSubmission):
    sid = _assessment_student(request)
    if payload.background not in _PRE_BACKGROUNDS:
        raise HTTPException(422, 'Select one valid background response.')
    if set(payload.answers) != set(_PRE_ANSWERS):
        raise HTTPException(422, 'Answer all ten HTML diagnostic questions (2 through 11).')
    score = sum(payload.answers[n] == correct for n, correct in _PRE_ANSWERS.items())
    db = Database()
    conn = db.get_connection()
    try:
        conn.execute('BEGIN IMMEDIATE')
        if conn.execute('SELECT 1 FROM pre_assessment_attempts WHERE student_id=?', (sid,)).fetchone():
            raise HTTPException(409, 'Your official diagnostic has already been submitted.')
        now = datetime.now(timezone.utc).isoformat()
        cur = conn.execute('''INSERT INTO pre_assessment_attempts
            (student_id, background, answers_json, score, status, submitted_at)
            VALUES (?,?,?,?, 'submitted', ?)''',
            (sid, payload.background, json.dumps(payload.answers), score, now))
        conn.commit()
        return {'attempt_id': cur.lastrowid, 'status': 'submitted', 'score': score,
                'total': 10, 'pre_test_completed': True, 'lessons_unlocked': True}
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _require_course_complete(conn, student_id: int):
    passed = conn.execute('''SELECT COUNT(*) FROM cv_lesson_progress
        WHERE student_id=? AND lesson_id IN
        ('T001','T002','T003','T004','T005','T006','T007','T008','T009','T010')
        AND passed_at IS NOT NULL''', (student_id,)).fetchone()[0]
    if passed != 10:
        raise HTTPException(403, 'Complete all ten lesson quizzes before taking the final assessment.')


@app.get('/api/final-assessment/status')
def final_assessment_status(request: Request):
    sid = _assessment_student(request)
    db = Database()
    conn = db.get_connection()
    try:
        row = conn.execute('''SELECT attempt_id, status, mcq_score, practical_score,
            total_score, submitted_at FROM benchmark_attempts
            WHERE student_id=? AND assessment_type='post' ''', (sid,)).fetchone()
        return {'final_test_completed': bool(row and row['status'] == 'submitted'),
                'final_test': dict(row) if row else None}
    finally:
        conn.close()


@app.post('/api/final-assessment/start')
def final_assessment_start(request: Request):
    sid = _assessment_student(request)
    db = Database()
    conn = db.get_connection()
    try:
        conn.execute('BEGIN IMMEDIATE')
        _require_course_complete(conn, sid)
        now = datetime.now(timezone.utc)
        conn.execute('''INSERT OR IGNORE INTO benchmark_attempts
            (student_id, assessment_type, status, started_at)
            VALUES (?, 'post', 'in_progress', ?)''', (sid, now.isoformat()))
        attempt = conn.execute('''SELECT attempt_id, status, started_at
            FROM benchmark_attempts WHERE student_id=? AND assessment_type='post' ''', (sid,)).fetchone()
        started = datetime.fromisoformat(attempt['started_at'])
        if started.tzinfo is None: started = started.replace(tzinfo=timezone.utc)
        deadline = started + timedelta(minutes=30)
        if attempt['status'] == 'submitted':
            raise HTTPException(409, 'Your official final assessment has already been submitted.')
        if attempt['status'] == 'expired' or now >= deadline:
            conn.execute("UPDATE benchmark_attempts SET status='expired' WHERE attempt_id=?", (attempt['attempt_id'],))
            conn.commit()
            raise HTTPException(410, 'Your final assessment session has expired.')
        conn.commit()
        return {'attempt_id': attempt['attempt_id'], 'status': 'in_progress',
                'assessment_type': 'post', 'started_at': started.isoformat(),
                'expires_at': deadline.isoformat(),
                'time_remaining_seconds': max(0, int((deadline-now).total_seconds()))}
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@app.post('/api/final-assessment/submit')
def final_assessment_submit(request: Request, payload: FinalAssessmentSubmission):
    sid = _assessment_student(request)
    if not set(payload.answers).issubset({str(i) for i in range(1,41)}):
        raise HTTPException(422, 'Invalid multiple-choice question ID.')
    if not set(payload.text_answers).issubset({str(i) for i in range(41,51)}):
        raise HTTPException(422, 'Invalid written question ID.')
    if any(len(s)>10000 for s in payload.text_answers.values()):
        raise HTTPException(422, 'A written answer exceeds the length limit.')
    db = Database()
    conn = db.get_connection()
    try:
        conn.execute('BEGIN IMMEDIATE')
        _require_course_complete(conn, sid)
        attempt = conn.execute('''SELECT attempt_id,status,started_at FROM benchmark_attempts
            WHERE attempt_id=? AND student_id=? AND assessment_type='post' ''',
            (payload.attempt_id,sid)).fetchone()
        if not attempt: raise HTTPException(404, 'Final assessment attempt not found.')
        if attempt['status'] != 'in_progress': raise HTTPException(409, 'Final assessment is no longer active.')
        started = datetime.fromisoformat(attempt['started_at'])
        if started.tzinfo is None: started = started.replace(tzinfo=timezone.utc)
        now = datetime.now(timezone.utc)
        if now >= started + timedelta(minutes=30):
            conn.execute("UPDATE benchmark_attempts SET status='expired' WHERE attempt_id=?", (payload.attempt_id,))
            conn.commit()
            raise HTTPException(410, 'Final assessment time has expired.')
        score = sum(payload.answers.get(str(n)) == answer for n,answer in _FINAL_MCQ_ANSWERS.items())
        conn.execute('''UPDATE benchmark_attempts SET answers_json=?, mcq_score=?,
            practical_score=NULL, total_score=NULL, status='submitted',
            submitted_at=?, time_spent_seconds=? WHERE attempt_id=?''',
            (json.dumps({'mcq':payload.answers,'practical':payload.text_answers}),
             score, now.isoformat(), int((now-started).total_seconds()), payload.attempt_id))
        conn.commit()
        return {'attempt_id': payload.attempt_id, 'status': 'submitted',
                'mcq_score': score, 'mcq_total': 40, 'practical_score': None,
                'total_score': None, 'grading_status':'pending_review',
                'final_test_completed': True}
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
