import { useCallback, useEffect, useState } from 'react';
import { LessonT001, LessonT002, LessonT003 } from './lessons';
import { LessonT005, LessonT006 } from './lessons2';
import { contentFor } from './lessonData';
import { learningApi } from './learningApi';
import LessonTutor from './LessonTutor';
import PreAssessment from './PreAssessment';
import FinalAssessment from './benchmark'; // existing 50-mark test; no duplicate component
import './learningPath.css';

export const COURSE = [
  {id:'T001',title:'Introduction to HTML and Web Basics',group:'HTML Foundations'},
  {id:'T002',title:'HTML Tags and Document Structure',group:'HTML Foundations'},
  {id:'T003',title:'Headings and Paragraphs',group:'HTML Foundations'},
  {id:'T004',title:'Hyperlinks',group:'HTML Elements'},
  {id:'T005',title:'Images and Multimedia',group:'HTML Elements'},
  {id:'T006',title:'Hyperlinks (Intermediate)',group:'HTML Elements'},
  {id:'T007',title:'Images and Tags',group:'HTML Elements'},
  {id:'T008',title:'Lists and Tables',group:'HTML Elements'},
  {id:'T009',title:'Forms and User Input',group:'Advanced HTML'},
  {id:'T010',title:'Semantic HTML and Accessibility',group:'Advanced HTML'},
];
const ORIGINAL = {T001:LessonT001,T002:LessonT002,T003:LessonT003,T010:LessonT005};

export default function LearningPath({mode='lessons',onAssessmentChange=()=>{}}) {
  const [state,setState]=useState(null);
  const [active,setActive]=useState(null);
  const [quiz,setQuiz]=useState(null);
  const [answers,setAnswers]=useState({});
  const [result,setResult]=useState(null);
  const [project,setProject]=useState(false);
  const [showBenchmark,setShowBenchmark]=useState(false);
  const [showFinal,setShowFinal]=useState(false);
  const [finalStatus,setFinalStatus]=useState(null);
  const [benchmarkStatus,setBenchmarkStatus]=useState(null);
  const [benchmarkError,setBenchmarkError]=useState('');
  const [error,setError]=useState('');
  const [loading,setLoading]=useState(false);
  const [busy,setBusy]=useState(false);
  const apiBase = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';
  async function statusJson(url) {
    const response = await fetch(`${apiBase}${url}`, { credentials: 'include' });
    if (!response.ok) throw new Error(`Assessment status failed (${response.status})`);
    return response.json();
  }
  const refresh=useCallback(async()=>{
    const [lessons, diagnostic, finalTest] = await Promise.all([
      learningApi('/state'),
      statusJson('/api/pre-assessment/status'),
      statusJson('/api/final-assessment/status'),
    ]);
    setState(lessons);
    setBenchmarkStatus(diagnostic);
    setFinalStatus(finalTest);
  }, []);
  useEffect(()=>{
    let cancelled=false;
    setLoading(true);
    Promise.all([
      learningApi('/state'),
      statusJson('/api/pre-assessment/status'),
      statusJson('/api/final-assessment/status'),
    ]).then(([lessons,diagnostic,finalTest])=>{
      if (!cancelled) {
        setState(lessons);
        setBenchmarkStatus(diagnostic);
        setFinalStatus(finalTest);
      }
    }).catch(err=>{if (!cancelled) setError(err.message);})
      .finally(()=>{if (!cancelled) setLoading(false);});
    return ()=>{cancelled=true;};
  },[]);
  useEffect(()=>{onAssessmentChange(Boolean(quiz||state?.active_quiz||showBenchmark||showFinal));return ()=>onAssessmentChange(false);},[quiz,state?.active_quiz,showBenchmark,showFinal,onAssessmentChange]);
  const lessonInfo=(id)=>state?.lessons.find(l=>l.id===id);
  const passedCount=state?.lessons.filter(l=>l.passed).length || 0;
  const percent=Math.round(100*passedCount/COURSE.length);
  const next=COURSE.find(l=>lessonInfo(l.id)?.unlocked&&!lessonInfo(l.id)?.passed);
  const index=active?COURSE.findIndex(l=>l.id===active.id):-1;
  const OldContent=active?ORIGINAL[active.id]:null;
  const contents=active?contentFor(index+1):null;
  function openLesson(lesson){
    if(!lessonInfo(lesson.id)?.unlocked || state?.active_quiz)return;
    setActive(lesson);setQuiz(null);setAnswers({});setResult(null);setProject(false);setError('');
  }
  async function perform(fn){setBusy(true);setError('');try{await fn();}catch(e){setError(e.message);}finally{setBusy(false);}}
  function viewed(){perform(async()=>{await learningApi('/viewed','POST',{lesson_id:active.id});await refresh();});}
  function beginQuiz(){perform(async()=>{
    const q=await learningApi('/quiz/start','POST',{lesson_id:active.id});
    setQuiz(q);setAnswers({});setResult(null);await refresh();
  });}
  function submit(){perform(async()=>{
    const r=await learningApi('/quiz/submit','POST',{attempt_id:quiz.attempt_id,answers:quiz.questions.map((_,i)=>answers[i])});
    setResult(r);await refresh();
  });}
  function abandon(){perform(async()=>{
    if(quiz)await learningApi('/quiz/abandon','POST',{attempt_id:quiz.attempt_id});
    else if(state?.active_quiz)await learningApi('/quiz/abandon','POST',{attempt_id:state.active_quiz.attempt_id});
    setQuiz(null);setResult(null);setActive(null);await refresh();
  });}
  async function resume(){
    const id=state?.active_quiz?.lesson_id;
    if(!id)return;
    const lesson=COURSE.find(l=>l.id===id);
    setActive(lesson);
    await perform(async()=>{
      const q=await learningApi('/quiz/start','POST',{lesson_id:id});
      setQuiz(q);setAnswers({});await refresh();
    });
  }
  // Official benchmark submission refreshes both the assessment status and lesson tiles.
  async function finishBenchmark() {
    setShowBenchmark(false);
    try { await refresh(); setBenchmarkError(''); }
    catch (err) { setBenchmarkError(err.message); }
  }
  if (showBenchmark) {
    return <section className="page-section learning-workspace">
      <PreAssessment onFinish={finishBenchmark} />
    </section>;
  }

  if (showFinal) {
    return <section className="page-section learning-workspace">
      <FinalAssessment onFinish={async () => {
        setShowFinal(false);
        try { await refresh(); } catch (e) { setError(e.message); }
      }} />
    </section>;
  }

  return <section className="page-section learning-workspace">
    <div className="lp-header">
      <div>
        <p className="label">CODEVERSE / HTML LEARNING PATH</p>
        <h2>{mode==='progress'?'Learner progression':'Your HTML Learning Journey'}</h2>
        <p>Study, take a quiz independently, and unlock the next lesson.</p>
      </div>
      <div className="lp-stat"><strong>{percent}%</strong><span>{passedCount} of {COURSE.length} quizzes passed</span></div>
    </div>

    <div className="lp-meter"><div style={{width:`${percent}%`}}/></div>
    {error&&<p className="lp-exam-notice" role="alert">{error}</p>}
    {benchmarkError&&<p className="lp-exam-notice" role="alert">{benchmarkError}</p>}
    {loading&&<p>Loading your saved progress…</p>}
    {state?.active_quiz&&!quiz&&<div className="lp-exam-notice">An unfinished quiz is active. AI tutoring is disabled until you finish or exit it. <button className="primary" disabled={busy} onClick={resume}>Resume quiz</button> <button className="secondary" disabled={busy} onClick={abandon}>Exit quiz</button></div>}
    {!active&&!project&&<>
      <div className="lp-benchmark-tile">
        <div>
          <p className="label">STEP 1 · DIAGNOSTIC</p>
          <h3>HTML Pre-Assessment</h3>
          <p>{benchmarkStatus?.pre_test_completed ? 'Diagnostic submitted. You can start learning HTML.' : 'Begin with a short assessment to understand what you already know.'}</p>
          <small>11 questions · 1 background + 10 scored · No pass mark</small>
        </div>
        <button type="button" className="primary"
          disabled={!!state?.active_quiz || loading || !benchmarkStatus || !!benchmarkStatus?.pre_test_completed}
          onClick={() => setShowBenchmark(true)}>
          {benchmarkStatus?.pre_test_completed ? '✓ Diagnostic completed' : 'Start Diagnostic →'}
        </button>
      </div>
      {next&&!state?.active_quiz&&<button className="primary" onClick={()=>openLesson(next)}>Continue: {next.title}</button>}
      {Array.from(new Set(COURSE.map(l=>l.group))).map(group=><div key={group} className="lp-group"><h3>{group}</h3><div className="lp-grid">{COURSE.filter(l=>l.group===group).map(l=><button key={l.id} className="lp-card" disabled={!lessonInfo(l.id)?.unlocked||!!state?.active_quiz} onClick={()=>openLesson(l)}><span>{l.id}</span><strong>{l.title}</strong><small>{lessonInfo(l.id)?.passed?'✓ Quiz passed':lessonInfo(l.id)?.unlocked?lessonInfo(l.id)?.viewed?'Ready for quiz / Continue':'Available to learn':'🔒 ' + (benchmarkStatus && !benchmarkStatus.pre_test_completed ? 'Complete diagnostic first' : 'Pass the previous quiz to unlock')}</small><small>Attempts: {lessonInfo(l.id)?.attempt_count||0}</small></button>)}</div></div>)}
      <div className="lp-benchmark-tile">
        <div>
          <p className="label">FINAL STAGE · AFTER T010</p>
          <h3>HTML Final Assessment</h3>
          <p>Complete all ten lessons and their unlock quizzes, then take the official final assessment.</p>
          <small>50 questions · 50 marks · 30 minutes</small>
        </div>
        <button type="button" className="primary"
          disabled={loading || !state || !finalStatus || passedCount !== COURSE.length || !!state?.active_quiz || !benchmarkStatus?.pre_test_completed || !!finalStatus?.final_test_completed}
          onClick={() => setShowFinal(true)}>
          {finalStatus?.final_test_completed ? '✓ Final Assessment submitted' : !finalStatus ? 'Checking eligibility…' : passedCount === COURSE.length ? 'Start Final Assessment →' : '🔒 Complete all ten lessons'}
        </button>
      </div>
      <div className="lp-final"><h3>Final Website Project</h3><p>Build an accessible personal website when all ten unlock quizzes are passed.</p><button className="secondary" disabled={passedCount!==COURSE.length||!!state?.active_quiz} onClick={()=>setProject(true)}> {passedCount===COURSE.length?'Open final project':'🔒 Complete all lessons first'}</button></div>
    </>}

    {project&&<><button className="secondary" onClick={()=>setProject(false)}>← Learning path</button><LessonT006/></>}
    {active&&<>
      {!quiz&&<button className="secondary" disabled={!!state?.active_quiz} onClick={()=>setActive(null)}>← Back to learning path</button>}
      <div className="lp-lesson"><p className="label">{active.id} · {active.group}</p><h2>{active.title}</h2>
      {!quiz&& !state?.active_quiz&&<>
        {OldContent?<OldContent/>:<><h3>Learning objective</h3><p>{contents.objective}</p>{contents.sections.map((s,i)=><article key={i} className="lp-section"><h3>{s.heading}</h3><p>{s.content}</p>{s.example&&<pre>{s.example}</pre>}{s.code&&<pre><code>{s.code}</code></pre>}</article>)}<div className="lp-challenge"><strong>Practice challenge</strong><p>{contents.challenge}</p></div></>}
        <LessonTutor key={active.id} lesson={active}/>
        {!lessonInfo(active.id)?.viewed?<button className="primary" disabled={busy} onClick={viewed}>I have finished studying this lesson</button>:<button className="primary" disabled={busy} onClick={beginQuiz}>Take unlock quiz →</button>}
        {lessonInfo(active.id)?.passed&&<p className="lp-success">Already passed; you may revise or retake.</p>}
      </>}
      
      {quiz&&<><div className="lp-exam-notice">Assessment mode: AI tutoring is disabled until you submit or exit this quiz.</div><h3>Unlock quiz · Pass mark {quiz.pass_percent}%</h3>
        {quiz.questions.map((q,i)=><fieldset className="lp-question" key={i} disabled={!!result||busy}><legend>{i+1}. {q.question}</legend>{q.options.map((option,j)=><label key={j}><input type="radio" name={`q-${i}`} checked={answers[i]===j} onChange={()=>setAnswers(a=>({...a,[i]:j}))}/>{option}</label>)}</fieldset>)}
        {!result?<><button className="primary" disabled={busy||Object.keys(answers).length!==quiz.questions.length} onClick={submit}>Submit answers</button> <button className="secondary" disabled={busy} onClick={abandon}>Exit quiz</button></>:<div className="lp-result"><h3>{result.passed?'✓ Quiz passed!':'Quiz not passed yet'}</h3><p>Score: {result.correct_count}/{result.total_count} ({result.score_percent}%). {result.passed?'The next lesson is now unlocked.':'Review and try again.'}</p><button className="primary" onClick={()=>{setActive(null);setQuiz(null);setResult(null);}}>Back to learning path</button><button className="secondary" onClick={()=>{setQuiz(null);setResult(null);}}>Review lesson</button></div>}
      </>}
      </div>
    </>}
  </section>;
}
