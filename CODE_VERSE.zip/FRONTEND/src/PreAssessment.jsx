import { useEffect, useState } from 'react';

const BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';
const QUESTIONS = [
  { id: 2, question: 'What does HTML stand for?', options: ['HighText Markdown Language', 'HyperText Markup Language', 'Hyperlink and Text Markup Language'] },
  { id: 3, question: 'What is the main purpose of HTML?', options: ['To make web pages look pretty with colours', 'To define the structure and content of a webpage', 'To make the internet run faster'] },
  { id: 4, question: 'Which tag is used to create a normal paragraph of text?', options: ['<p>', '<h1>', '<br>'] },
  { id: 5, question: 'Which heading tag makes the biggest text on the page?', options: ['<h6>', '<h3>', '<h1>'] },
  { id: 6, question: 'Which tag is used to add an image to a webpage?', options: ['<image>', '<img>', '<picture>'] },
  { id: 7, question: 'How do you create a clickable link to another website?', options: ['Using the <a> tag and the href attribute', 'Using the <link> tag and the src attribute', 'Using the <p> tag and the url attribute'] },
  { id: 8, question: 'Which tag creates a bulleted (unordered) list?', options: ['<ol>', '<li>', '<ul>'] },
  { id: 9, question: 'What is a "web browser"? (Example: Google Chrome, Firefox, Safari)', options: ['A program that helps you write HTML code', 'A program that reads HTML code and displays it as a webpage', 'A program that stores all the images on the internet'] },
  { id: 10, question: 'Which tag do you use to start a completely new line without making a new paragraph?', options: ['<br>', '<p>', '<hr>'] },
  { id: 11, question: 'If you want to make a word bold, which tag do you use?', options: ['<strong> or <b>', '<bold>', '<big>'] },
];
const BACKGROUND_OPTIONS = [
  'Yes, I have built my own web pages before.',
  'Yes, but I have only seen it or tried it a tiny bit.',
  'No, I have never done HTML before.',
];
const panel = { background: '#fffdf4', border: '1px solid #e0e4d7', borderRadius: 16, padding: '20px 22px', marginBottom: 18 };
const label = { display: 'flex', gap: 10, padding: '10px', cursor: 'pointer', alignItems: 'start' };

export default function PreAssessment({ onFinish }) {
  const [background, setBackground] = useState('');
  const [answers, setAnswers] = useState({});
  const [alreadyDone, setAlreadyDone] = useState(false);
  const [submitted, setSubmitted] = useState(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    fetch(`${BASE}/api/pre-assessment/status`, { credentials: 'include' })
      .then(async r => {
        const data = await r.json();
        if (!r.ok) throw new Error(data.detail || `Status request failed (${r.status})`);
        return data;
      }).then(data => { if (!cancelled) { setAlreadyDone(data.pre_test_completed); if (data.pre_test_completed) setSubmitted(data); } })
      .catch(e => { if (!cancelled) setError(e.message); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, []);

  async function submit(event) {
    event.preventDefault();
    if (busy || alreadyDone || submitted) return;
    if (!background || QUESTIONS.some(q => !answers[q.id])) {
      setError('Please complete the background question and all 10 HTML questions.');
      return;
    }
    setBusy(true);
    setError('');
    try {
      const response = await fetch(`${BASE}/api/pre-assessment/submit`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'include',
        body: JSON.stringify({ background, answers: Object.fromEntries(Object.entries(answers).map(([k,v]) => [String(k),v])) }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail || `Submission failed (${response.status})`);
      setSubmitted(data);
      setAlreadyDone(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (e) { setError(e.message); }
    finally { setBusy(false); }
  }

  return <div className="diagnostic-assessment">
    <div className="section-heading">
      <p className="label">CODEVERSE · START HERE</p>
      <h2>HTML Pre-Assessment (Diagnostic Quiz)</h2>
      <p>This short quiz helps us understand what you already know about HTML before we start the lessons. Don't worry if you don't know the answers yet. This is just to help your tutor teach you better!</p>
      <p><strong>11 questions total:</strong> 1 background question and 10 basic HTML questions. <strong>Scored out of 10.</strong></p>
    </div>
    {loading && <p role="status">Checking your assessment status…</p>}
    {error && <p role="alert" style={{ color: '#b42318' }}>{error}</p>}
    {submitted && <div style={{ ...panel, background: '#e9f8f0' }} role="status">
      <h3>✓ Pre-assessment completed</h3>
      <p>Your diagnostic score: <strong>{submitted.score ?? submitted.pre_test?.score ?? 'Saved'}{Number.isInteger(submitted.score ?? submitted.pre_test?.score) ? ' / 10' : ''}</strong></p>
      <p>There is no pass mark. Your HTML learning path is now available.</p>
      <button type="button" className="primary" onClick={() => onFinish?.(true)}>Back to Lessons →</button>
    </div>}
    {!loading && !submitted && <form onSubmit={submit}>
      <div style={panel}>
        <h3>Part 1: Your Background</h3>
        <fieldset style={{ border: 0, padding: 0 }}><legend><strong>1. Have you ever done HTML before?</strong></legend>
          {BACKGROUND_OPTIONS.map((option, i) => <label key={i} style={label}><input type="radio" name="background" value={option} checked={background === option} onChange={() => setBackground(option)} />{option}</label>)}
        </fieldset>
        <p style={{ color: '#66766e' }}>This question has no right or wrong answer.</p>
      </div>
      <div style={panel}><h3>Part 2: Basic Knowledge</h3>
        {QUESTIONS.map(q => <fieldset key={q.id} style={{ border: 0, borderTop: '1px solid #e5e9e1', marginTop: 14, padding: '16px 0 0' }}>
          <legend style={{ paddingTop: 12, fontWeight: 700 }}>{q.id}. {q.question}</legend>
          {q.options.map((option, i) => { const letter = 'ABC'[i]; return <label key={letter} style={label}>
            <input type="radio" name={`pre-q-${q.id}`} value={letter} checked={answers[q.id] === letter} onChange={() => setAnswers(prev => ({ ...prev, [q.id]: letter }))} />
            <span>{letter}) {option}</span>
          </label>; })}
        </fieldset>)}
      </div>
      <button type="submit" className="primary" disabled={busy}>{busy ? 'Saving your answers…' : 'Submit diagnostic quiz'}</button>
      <button type="button" className="secondary" style={{ marginLeft: 12 }} onClick={() => onFinish?.(false)}>← Back to Lessons</button>
    </form>}
    {alreadyDone && !submitted && <button type="button" className="primary" onClick={() => onFinish?.(true)}>Back to Lessons</button>}
  </div>;
}
