// src/BenchmarkTest.jsx
import { useState } from "react";

// ---------- Answer key for Q1–40 ----------
const KEY = {
  1:'B', 2:'A', 3:'C', 4:'B', 5:'A',
  6:'B', 7:'C', 8:'A', 9:'B', 10:'C',
  11:'A', 12:'B', 13:'C', 14:'B', 15:'A',
  16:'C', 17:'B', 18:'A', 19:'C', 20:'B',
  21:'A', 22:'C', 23:'B', 24:'A', 25:'C',
  26:'B', 27:'A', 28:'C', 29:'A', 30:'B',
  31:'A', 32:'C', 33:'B', 34:'A', 35:'C',
  36:'A', 37:'B', 38:'A', 39:'C', 40:'B'
};

// ---------- Multiple-choice data, grouped by section ----------
const MC_SECTIONS = [
  {
    code: "T001",
    title: "Section 1: HTML Basics and Web Fundamentals",
    questions: [
      { id: 1, text: "What does HTML stand for?", options: [
        { letter: 'A', text: 'HighText Machine Language' },
        { letter: 'B', text: 'HyperText Markup Language' },
        { letter: 'C', text: 'Hyperlink Text Management Language' }
      ]},
      { id: 2, text: "What is the primary purpose of HTML?", options: [
        { letter: 'A', text: 'To structure and describe webpage content' },
        { letter: 'B', text: 'To manage a database directly' },
        { letter: 'C', text: "To control every aspect of a website's visual styling" }
      ]},
      { id: 3, text: "Which technology is primarily responsible for styling webpages?", options: [
        { letter: 'A', text: 'SQLite' },
        { letter: 'B', text: 'HTML' },
        { letter: 'C', text: 'CSS' }
      ]},
      { id: 4, text: "What is a web browser used for?", options: [
        { letter: 'A', text: 'To create database tables automatically' },
        { letter: 'B', text: 'To request and display web content' },
        { letter: 'C', text: 'To replace HTML tags with database queries' }
      ]},
      { id: 5, text: "What is an HTML element?", options: [
        { letter: 'A', text: 'A building block of a webpage, usually made from a start tag, content and an end tag' },
        { letter: 'B', text: 'A type of computer monitor' },
        { letter: 'C', text: 'A password used to access a website' }
      ]}
    ]
  },
  {
    code: "T002",
    title: "Section 2: HTML Document Structure",
    questions: [
      { id: 6, text: "Which declaration should appear at the beginning of a modern HTML document?", options: [
        { letter: 'A', text: '<html5>' },
        { letter: 'B', text: '<!DOCTYPE html>' },
        { letter: 'C', text: '<start>' }
      ]},
      { id: 7, text: "Which element contains the main visible page content?", options: [
        { letter: 'A', text: '<head>' },
        { letter: 'B', text: '<meta>' },
        { letter: 'C', text: '<body>' }
      ]},
      { id: 8, text: "Where should the webpage's title, which normally appears on the browser tab, be placed?", options: [
        { letter: 'A', text: 'Inside <title> within <head>' },
        { letter: 'B', text: 'Inside <footer>' },
        { letter: 'C', text: 'Inside <h1> only' }
      ]},
      { id: 9, text: "Which example shows the correct order of the main HTML document elements?", options: [
        { letter: 'A', text: '<body>, <head>, <html>' },
        { letter: 'B', text: '<html>, <head>, <body>' },
        { letter: 'C', text: '<head>, <body>, <html>' }
      ]},
      { id: 10, text: "What is the purpose of the <meta charset=\"UTF-8\"> element?", options: [
        { letter: 'A', text: 'To create a navigation menu' },
        { letter: 'B', text: 'To insert an image' },
        { letter: 'C', text: "To specify the document's character encoding" }
      ]}
    ]
  },
  {
    code: "T003",
    title: "Section 3: Headings, Paragraphs and Text",
    questions: [
      { id: 11, text: "Which element represents the highest-level heading?", options: [
        { letter: 'A', text: '<h1>' },
        { letter: 'B', text: '<h6>' },
        { letter: 'C', text: '<p>' }
      ]},
      { id: 12, text: "Which element is normally used for a paragraph of text?", options: [
        { letter: 'A', text: '<text>' },
        { letter: 'B', text: '<p>' },
        { letter: 'C', text: '<paragraph>' }
      ]},
      { id: 13, text: "Which element inserts a line break without starting a new paragraph?", options: [
        { letter: 'A', text: '<break>' },
        { letter: 'B', text: '<lb>' },
        { letter: 'C', text: '<br>' }
      ]},
      { id: 14, text: "Which statement about heading elements is correct?", options: [
        { letter: 'A', text: 'HTML only allows one heading element on every webpage.' },
        { letter: 'B', text: 'Headings from <h1> to <h6> represent different heading levels.' },
        { letter: 'C', text: 'Headings must always be placed inside a table.' }
      ]},
      { id: 15, text: "Which HTML element represents a thematic break between sections of content?", options: [
        { letter: 'A', text: '<hr>' },
        { letter: 'B', text: '<sectionbreak>' },
        { letter: 'C', text: '<line>' }
      ]}
    ]
  },
  {
    code: "T004",
    title: "Section 4: Hyperlinks and Navigation",
    questions: [
      { id: 16, text: "Which element creates a hyperlink?", options: [
        { letter: 'A', text: '<linkto>' },
        { letter: 'B', text: '<href>' },
        { letter: 'C', text: '<a>' }
      ]},
      { id: 17, text: "Which attribute specifies the destination of a hyperlink?", options: [
        { letter: 'A', text: 'src' },
        { letter: 'B', text: 'href' },
        { letter: 'C', text: 'alt' }
      ]},
      { id: 18, text: "Which example correctly links to an external website?", options: [
        { letter: 'A', text: '<a href="https://example.com">Visit website</a>' },
        { letter: 'B', text: '<a src="https://example.com">Visit website</a>' },
        { letter: 'C', text: '<href="https://example.com">Visit website</href>' }
      ]},
      { id: 19, text: 'Which link points to a section on the same webpage with id="contact"?', options: [
        { letter: 'A', text: '<a href="contact">Contact</a>' },
        { letter: 'B', text: '<a href=".contact">Contact</a>' },
        { letter: 'C', text: '<a href="#contact">Contact</a>' }
      ]},
      { id: 20, text: 'What is the purpose of target="_blank" on a hyperlink?', options: [
        { letter: 'A', text: 'To remove the hyperlink' },
        { letter: 'B', text: 'To request that the destination opens in a new browsing context, usually a new tab' },
        { letter: 'C', text: 'To download every linked file automatically' }
      ]}
    ]
  },
  {
    code: "T005",
    title: "Section 5: Images and Multimedia",
    questions: [
      { id: 21, text: "Which HTML element embeds an image?", options: [
        { letter: 'A', text: '<img>' },
        { letter: 'B', text: '<imagefile>' },
        { letter: 'C', text: '<photo>' }
      ]},
      { id: 22, text: "Which attribute specifies the image file's location?", options: [
        { letter: 'A', text: 'href' },
        { letter: 'B', text: 'alt' },
        { letter: 'C', text: 'src' }
      ]},
      { id: 23, text: "Why is meaningful alternative text important for an informative image?", options: [
        { letter: 'A', text: 'It automatically compresses the image file.' },
        { letter: 'B', text: "It helps communicate the image's information to people who cannot see it." },
        { letter: 'C', text: 'It changes the image into a hyperlink.' }
      ]},
      { id: 24, text: "Which element can embed video content in a webpage?", options: [
        { letter: 'A', text: '<video>' },
        { letter: 'B', text: '<movie>' },
        { letter: 'C', text: '<mediafile>' }
      ]},
      { id: 25, text: "Which example correctly embeds an audio file with browser playback controls?", options: [
        { letter: 'A', text: '<audio src="song.mp3"></audio controls>' },
        { letter: 'B', text: '<sound controls src="song.mp3"></sound>' },
        { letter: 'C', text: '<audio src="song.mp3" controls></audio>' }
      ]}
    ]
  },
  {
    code: "T006",
    title: "Section 6: Lists and Tables",
    questions: [
      { id: 26, text: "Which element creates an unordered list?", options: [
        { letter: 'A', text: '<ol>' },
        { letter: 'B', text: '<ul>' },
        { letter: 'C', text: '<li>' }
      ]},
      { id: 27, text: "Which element creates an individual list item?", options: [
        { letter: 'A', text: '<li>' },
        { letter: 'B', text: '<item>' },
        { letter: 'C', text: '<listitem>' }
      ]},
      { id: 28, text: "Which element creates a row in an HTML table?", options: [
        { letter: 'A', text: '<td>' },
        { letter: 'B', text: '<table-row>' },
        { letter: 'C', text: '<tr>' }
      ]},
      { id: 29, text: "Which element represents a header cell in an HTML table?", options: [
        { letter: 'A', text: '<th>' },
        { letter: 'B', text: '<thead>' },
        { letter: 'C', text: '<header>' }
      ]},
      { id: 30, text: "Which option correctly creates an ordered list with two items?", options: [
        { letter: 'A', text: '<ul>\n  <li>HTML</li>\n  <li>CSS</li>\n</ul>', isCode: true },
        { letter: 'B', text: '<ol>\n  <li>HTML</li>\n  <li>CSS</li>\n</ol>', isCode: true },
        { letter: 'C', text: '<ol>\n  <item>HTML</item>\n  <item>CSS</item>\n</ol>', isCode: true }
      ]}
    ]
  },
  {
    code: "T007",
    title: "Section 7: Forms and User Input",
    questions: [
      { id: 31, text: "Which element creates a single-line text input?", options: [
        { letter: 'A', text: '<input type="text">' },
        { letter: 'B', text: '<textinput>' },
        { letter: 'C', text: '<form type="text">' }
      ]},
      { id: 32, text: "What is the main purpose of an HTML form?", options: [
        { letter: 'A', text: 'To create headings automatically' },
        { letter: 'B', text: 'To change the background colour of the webpage' },
        { letter: 'C', text: 'To collect user input for processing or submission' }
      ]},
      { id: 33, text: "Which attribute gives a form control its submitted field name?", options: [
        { letter: 'A', text: 'placeholder' },
        { letter: 'B', text: 'name' },
        { letter: 'C', text: 'style' }
      ]},
      { id: 34, text: "Which element creates a multi-line text input?", options: [
        { letter: 'A', text: '<textarea>' },
        { letter: 'B', text: '<input type="multiline">' },
        { letter: 'C', text: '<paragraph-input>' }
      ]},
      { id: 35, text: "Which attribute makes a form field mandatory before a valid submission?", options: [
        { letter: 'A', text: 'optional' },
        { letter: 'B', text: 'placeholder' },
        { letter: 'C', text: 'required' }
      ]}
    ]
  },
  {
    code: "T008",
    title: "Section 8: Semantic HTML and Accessibility",
    questions: [
      { id: 36, text: "Which element represents a group of major navigation links?", options: [
        { letter: 'A', text: '<nav>' },
        { letter: 'B', text: '<navigate>' },
        { letter: 'C', text: '<links>' }
      ]},
      { id: 37, text: "Which element is commonly used for introductory content or a page header?", options: [
        { letter: 'A', text: '<top>' },
        { letter: 'B', text: '<header>' },
        { letter: 'C', text: '<heading>' }
      ]},
      { id: 38, text: "Which semantic element represents the main content of a webpage?", options: [
        { letter: 'A', text: '<main>' },
        { letter: 'B', text: '<content>' },
        { letter: 'C', text: '<bodytext>' }
      ]},
      { id: 39, text: "Which element is commonly used for copyright information or other footer content?", options: [
        { letter: 'A', text: '<bottom>' },
        { letter: 'B', text: '<end>' },
        { letter: 'C', text: '<footer>' }
      ]},
      { id: 40, text: "Why is semantic HTML useful?", options: [
        { letter: 'A', text: 'It automatically makes every webpage colourful.' },
        { letter: 'B', text: 'It gives content meaningful structure that helps browsers, developers and assistive technologies interpret the page.' },
        { letter: 'C', text: 'It eliminates the need for all CSS.' }
      ]}
    ]
  }
];

// ---------- Debugging questions (Q41–45) ----------
const DEBUG_QUESTIONS = [
  { id: 41, title: "Broken hyperlink",
    prompt: "The following code should link to the school website, but the link destination is not specified using the correct attribute.",
    broken: '<a src="https://school.example">Visit our school</a>',
    model: '<a href="https://school.example">Visit our school</a>' },
  { id: 42, title: "Broken image",
    prompt: "The following code should display school.jpg, but the image source attribute is incorrect.",
    broken: '<img href="school.jpg" alt="Our school">',
    model: '<img src="school.jpg" alt="Our school">' },
  { id: 43, title: "Incorrect list structure",
    prompt: "The following code is intended to create a list of two subjects.",
    broken: '<ul>\n  <item>Mathematics</item>\n  <item>Science</item>\n</ul>',
    model: '<ul>\n  <li>Mathematics</li>\n  <li>Science</li>\n</ul>' },
  { id: 44, title: "Incorrect table structure",
    prompt: "The following code is intended to create a table row containing a cell.",
    broken: '<table>\n  <row>\n    <td>Grade 7</td>\n  </row>\n</table>',
    model: '<table>\n  <tr>\n    <td>Grade 7</td>\n  </tr>\n</table>' },
  { id: 45, title: "Incorrect paragraph structure",
    prompt: "The following code incorrectly places a heading inside a paragraph.",
    broken: '<p>\n  Welcome to my website\n  <h2>About Us</h2>\n</p>',
    model: '<h2>About Us</h2>\n<p>Welcome to my website</p>' }
];

// ---------- Practical coding questions (Q46–50) ----------
const CODE_QUESTIONS = [
  { id: 46, title: "Create a heading",
    prompt: "Write HTML to display the heading: My Learning Journey",
    model: '<h1>My Learning Journey</h1>' },
  { id: 47, title: "Create a hyperlink",
    prompt: "Write HTML to display the clickable text Visit Example linking to https://example.com.",
    model: '<a href="https://example.com">Visit Example</a>' },
  { id: 48, title: "Embed an accessible image",
    prompt: "Write HTML to display computer.jpg with the alternative text A student learning to code.",
    model: '<img src="computer.jpg" alt="A student learning to code">' },
  { id: 49, title: "Create a list",
    prompt: "Write HTML to create an unordered list containing: HTML, CSS, JavaScript.",
    model: '<ul>\n  <li>HTML</li>\n  <li>CSS</li>\n  <li>JavaScript</li>\n</ul>' },
  { id: 50, title: "Create a simple contact form",
    prompt: "Write HTML for a form containing a label Your name, a single-line text input with name=\"name\", and a submit button.",
    model: '<form>\n  <label for="name">Your name</label>\n  <input type="text" id="name" name="name">\n  <button type="submit">Submit</button>\n</form>' }
];

// ---------- Small helpers ----------
const numBadge = {
  display: "inline-flex", alignItems: "center", justifyContent: "center",
  minWidth: 27, height: 27, padding: "0 6px",
  borderRadius: 8, background: "#e8f5e9", color: "#0A3323",
  fontSize: "0.78rem", fontWeight: 700, marginRight: 9
};

const cardStyle = {
  background: "#fff",
  border: "1px solid #e2eef7",
  borderRadius: 14,
  padding: "20px 22px",
  marginBottom: 20
};

function CodeBlock({ children }) {
  return (
    <pre style={{
      background: "#f3f8fc", border: "1px solid #e2eef7",
      borderRadius: 8, padding: "10px 12px",
      fontSize: "0.85rem", overflowX: "auto", margin: "8px 0"
    }}>
      <code>{children}</code>
    </pre>
  );
}

// ---------- Main component ----------
export default function BenchmarkTest({ onFinish }) {
  const [answers, setAnswers] = useState({});          // { qId: 'A' | 'B' | 'C' }
  const [textAnswers, setTextAnswers] = useState({});  // { qId: 'typed code' }
  const [checked, setChecked] = useState(false);
  const [score, setScore] = useState(0);
  const [revealedModels, setRevealedModels] = useState({});

  const handleSelect = (qId, letter) => {
    if (checked) return;
    setAnswers((prev) => ({ ...prev, [qId]: letter }));
  };

  const handleText = (qId, value) => {
    setTextAnswers((prev) => ({ ...prev, [qId]: value }));
  };

  const toggleModel = (qId) => {
    setRevealedModels((prev) => ({ ...prev, [qId]: !prev[qId] }));
  };

  const handleCheck = () => {
    let s = 0;
    for (let i = 1; i <= 40; i++) {
      if (answers[i] === KEY[i]) s++;
    }
    setScore(s);
    setChecked(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleReset = () => {
    setAnswers({});
    setTextAnswers({});
    setChecked(false);
    setScore(0);
    setRevealedModels({});
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="benchmark-test">
      {/* ---------- Header ---------- */}
      <div className="section-heading">
        <p className="label">BENCHMARK TEST · HTB-001</p>
        <h2>HTML Tutor Benchmark Test</h2>
        <p>
          Grades 7–9 · 50 questions · 50 marks · 30 minutes.
          Questions 1–40 are marked automatically. Questions 41–50 are graded by your teacher.
        </p>
        {onFinish && (
          <button className="secondary" style={{ marginTop: 10 }} onClick={onFinish}>
            ← Back
          </button>
        )}
      </div>

      {/* ---------- Instructions ---------- */}
      <div style={cardStyle}>
        <h3 style={{ marginTop: 0, color: "#0A3323" }}>Learner Instructions</h3>
        <ol style={{ lineHeight: 1.7, paddingLeft: 22 }}>
          <li>Answer all 50 questions.</li>
          <li>Questions 1–40 are multiple-choice — select one answer: A, B or C.</li>
          <li>Questions 41–45 require you to identify and correct HTML errors.</li>
          <li>Questions 46–50 require you to write short pieces of HTML code.</li>
          <li>Each question is worth 1 mark.</li>
          <li>Work independently. Do not use an AI assistant or search engine during the assessment.</li>
        </ol>
      </div>

      {/* ---------- Multiple choice sections ---------- */}
      {MC_SECTIONS.map((section) => (
        <div key={section.code} style={cardStyle}>
          <p className="label">{section.code}</p>
          <h3 style={{ marginTop: 4, color: "#0A3323" }}>{section.title}</h3>
          <p style={{ fontSize: "0.8rem", color: "#666", marginBottom: 15 }}>
            Questions {section.questions[0].id}–{section.questions[section.questions.length - 1].id}
          </p>

          {section.questions.map((q) => {
            const selected = answers[q.id];
            const isCorrect = checked && selected === KEY[q.id];
            const isWrong = checked && selected && selected !== KEY[q.id];

            return (
              <div
                key={q.id}
                style={{ paddingTop: 14, marginTop: 14, borderTop: "1px dashed #e2eef7" }}
              >
                <p style={{ fontWeight: 600, margin: "0 0 10px" }}>
                  <span style={numBadge}>{q.id}</span>
                  {q.text}
                </p>

                <div style={{ display: "grid", gap: 8 }}>
                  {q.options.map((opt) => {
                    const isSelected = selected === opt.letter;
                    const showCorrect = checked && opt.letter === KEY[q.id];

                    let bg = "#fbfdff";
                    let border = "#e2eef7";
                    if (isSelected && !checked) { bg = "#eaf7ff"; border = "#8fd2f5"; }
                    if (showCorrect)            { bg = "#e8f5e9"; border = "#43a047"; }
                    if (isSelected && isWrong)  { bg = "#ffebee"; border = "#e53935"; }

                    return (
                      <label
                        key={opt.letter}
                        style={{
                          display: "flex", gap: 10, alignItems: "flex-start",
                          padding: "10px 14px",
                          border: `1px solid ${border}`,
                          background: bg,
                          borderRadius: 10,
                          cursor: checked ? "default" : "pointer",
                          fontSize: "0.95rem"
                        }}
                      >
                        <input
                          type="radio"
                          name={`q${q.id}`}
                          checked={isSelected || false}
                          onChange={() => handleSelect(q.id, opt.letter)}
                          disabled={checked}
                          style={{ marginTop: 4 }}
                        />
                        <span>
                          <strong>{opt.letter})</strong>{" "}
                          {opt.isCode ? <CodeBlock>{opt.text}</CodeBlock> : opt.text}
                        </span>
                      </label>
                    );
                  })}
                </div>

                {checked && (
                  <p style={{
                    margin: "8px 0 0", fontSize: "0.85rem", fontWeight: 600,
                    color: isCorrect ? "#2f8a52" : "#b34a4a"
                  }}>
                    {isCorrect ? "✔ Correct" : selected ? "✘ Not quite. " : "— Not answered. "}
                    {!isCorrect && `Correct answer: ${KEY[q.id]}`}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      ))}

      {/* ---------- Debugging section ---------- */}
      <div style={cardStyle}>
        <p className="label">T009</p>
        <h3 style={{ marginTop: 4, color: "#0A3323" }}>Section 9: Debugging HTML</h3>
        <p style={{ fontSize: "0.85rem", color: "#666" }}>
          Identify the main problem and write the corrected line(s) of HTML.
        </p>

        {DEBUG_QUESTIONS.map((q) => (
          <div key={q.id} style={{ paddingTop: 16, marginTop: 16, borderTop: "1px dashed #e2eef7" }}>
            <p style={{ fontWeight: 600, margin: "0 0 6px" }}>
              <span style={numBadge}>{q.id}</span>{q.title}
            </p>
            <p style={{ margin: "0 0 8px" }}>{q.prompt}</p>
            <CodeBlock>{q.broken}</CodeBlock>

            <p style={{ margin: "8px 0 4px", fontWeight: 600 }}>Your correction:</p>
            <textarea
              value={textAnswers[q.id] || ""}
              onChange={(e) => handleText(q.id, e.target.value)}
              placeholder="Write your corrected HTML here..."
              style={{
                width: "100%", minHeight: 70, padding: 10,
                fontFamily: "monospace", fontSize: "0.85rem",
                border: "1px solid #e2eef7", borderRadius: 8,
                background: "#fbfdff", resize: "vertical"
              }}
            />

            <button
              className="secondary"
              style={{ marginTop: 8, fontSize: "0.8rem", padding: "6px 12px" }}
              onClick={() => toggleModel(q.id)}
            >
              {revealedModels[q.id] ? "Hide model answer" : "Show model answer"}
            </button>

            {revealedModels[q.id] && (
              <div style={{
                marginTop: 8, padding: "10px 12px",
                background: "#f0fdf6", border: "1px solid #c8ecd8", borderRadius: 8
              }}>
                <strong style={{ color: "#2f8a52", fontSize: "0.8rem" }}>MODEL ANSWER</strong>
                <CodeBlock>{q.model}</CodeBlock>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* ---------- Coding section ---------- */}
      <div style={cardStyle}>
        <p className="label">T010</p>
        <h3 style={{ marginTop: 4, color: "#0A3323" }}>Section 10: Practical HTML Coding</h3>
        <p style={{ fontSize: "0.85rem", color: "#666" }}>
          Write the HTML required for each task.
        </p>

        {CODE_QUESTIONS.map((q) => (
          <div key={q.id} style={{ paddingTop: 16, marginTop: 16, borderTop: "1px dashed #e2eef7" }}>
            <p style={{ fontWeight: 600, margin: "0 0 6px" }}>
              <span style={numBadge}>{q.id}</span>{q.title}
            </p>
            <p style={{ margin: "0 0 8px" }}>{q.prompt}</p>

            <textarea
              value={textAnswers[q.id] || ""}
              onChange={(e) => handleText(q.id, e.target.value)}
              placeholder="Your code..."
              style={{
                width: "100%", minHeight: 70, padding: 10,
                fontFamily: "monospace", fontSize: "0.85rem",
                border: "1px solid #e2eef7", borderRadius: 8,
                background: "#fbfdff", resize: "vertical"
              }}
            />

            <button
              className="secondary"
              style={{ marginTop: 8, fontSize: "0.8rem", padding: "6px 12px" }}
              onClick={() => toggleModel(q.id)}
            >
              {revealedModels[q.id] ? "Hide model answer" : "Show model answer"}
            </button>

            {revealedModels[q.id] && (
              <div style={{
                marginTop: 8, padding: "10px 12px",
                background: "#f0fdf6", border: "1px solid #c8ecd8", borderRadius: 8
              }}>
                <strong style={{ color: "#2f8a52", fontSize: "0.8rem" }}>MODEL ANSWER</strong>
                <CodeBlock>{q.model}</CodeBlock>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* ---------- Check / Reset ---------- */}
      <div style={cardStyle}>
        <h3 style={{ marginTop: 0, color: "#0A3323" }}>Finished? Check your answers</h3>
        <p style={{ fontSize: "0.85rem", color: "#666" }}>
          Questions 1–40 are marked automatically. Questions 41–50 are graded by your teacher.
        </p>

        <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
          <button className="primary" onClick={handleCheck}>Check my answers</button>
          <button className="secondary" onClick={handleReset}>Reset test</button>
        </div>

        {checked && (
          <div style={{
            marginTop: 16, padding: "16px 20px",
            background: "linear-gradient(135deg,#eaf7ff,#effcf5)",
            border: "1px solid #cfeaf7", borderRadius: 12,
            color: "#0d5d86", fontWeight: 600
          }}>
            <div style={{ fontSize: "1.6rem", color: "#0f8f6f", marginBottom: 4 }}>
              {score} / 40
            </div>
            Multiple-choice score · Questions 41–50 will be marked by your teacher.
          </div>
        )}
      </div>

      {onFinish && (
        <div style={{ textAlign: "center", padding: "10px 0 30px" }}>
          <button className="secondary" onClick={onFinish}>← Back to Lessons</button>
        </div>
      )}
    </div>
  );
}