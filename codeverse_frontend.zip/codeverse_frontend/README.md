# CodeVerse Frontend

A React + Vite frontend based on the supplied learning flowchart.

## Included
- New learner sign-up / returning learner login screens
- HTML lesson screen
- Browser Text-to-Speech tutor
- Clarification question flow and counter
- Games / multiple-choice exercise choice
- 5-question HTML quiz
- 80% badge rule
- Points
- Leaderboard
- Progress dashboard
- Responsive mobile layout
- LocalStorage for learner name, points and lessons
- Colour palette:
  - #0A3323
  - #839958
  - #F7F4D5
  - #D3968C
  - #105666

## Run
1. Install Node.js.
2. Open this folder in VS Code.
3. Run `npm install`
4. Run `npm run dev`
5. Open the local Vite address shown in the terminal.

This is a frontend prototype. Real authentication, a database, cloud leaderboard data, AI tutoring and production lesson content can be connected later.
