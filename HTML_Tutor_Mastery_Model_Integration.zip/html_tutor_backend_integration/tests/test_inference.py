from inference import FEATURES, predict_checkpoint_pass


def sample_features():
    values = {name: 0.5 for name in FEATURES if name != "topic_id"}
    values.update({
        "practice_interaction_count": 8,
        "unique_question_count": 5,
        "mean_attempt_count": 1.5,
        "mean_review_visits": 0.5,
        "mean_response_time_seconds": 24,
        "median_response_time_seconds": 20,
        "correct_streak_end": 2,
        "mean_question_difficulty": 2,
        "prior_topics_completed": 1,
        "previous_topic_mastery_label": 1,
        "last_interaction_first_correct": 1,
        "topic_id": "T002",
    })
    return values


def test_prediction_returns_probability_and_safeguard():
    result = predict_checkpoint_pass(sample_features())
    assert 0.0 <= result["probability_checkpoint_pass"] <= 1.0
    assert result["progression_authorized"] is False


def test_missing_numeric_value_is_imputed():
    features = sample_features()
    features["recent5_first_attempt_accuracy"] = None
    result = predict_checkpoint_pass(features)
    assert "recent5_first_attempt_accuracy" in result["imputed_features"]


def test_missing_feature_is_rejected():
    features = sample_features()
    del features["topic_id"]
    try:
        predict_checkpoint_pass(features)
    except ValueError as exc:
        assert "topic_id" in str(exc)
    else:
        raise AssertionError("Expected missing feature to be rejected")
