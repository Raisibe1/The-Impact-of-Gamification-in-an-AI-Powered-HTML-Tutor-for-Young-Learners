# CodeVerse Step 1C: WebDev Arcade link integration

This extends Step 1B with the original uploaded `game.html` arcade landing page. The arcade hub runs as static HTML under Vite `public/arcade/`, keeping the React course and cookie-authentication app intact.

## Installation
1. Merge `src/*` into your existing Vite React `src/` folder.
2. Copy `public/arcade/` into your Vite project's `public/` directory.
3. Keep your existing project `package.json` / `vite.config` and backend.
4. Add your **actual** game HTML files under `public/arcade/GAMES/`: `snake-ladder.html`, `crossword.html`, `matchMasters.html`, `pixel-detective.html`.
5. Copy original `CSS/`, `JS/`, and `ASSETS/` game dependencies under `public/arcade/`, preserving each relative path. An **approximate fallback** `CSS/arcade.css` is provided because the original arcade.css was not uploaded. Replace it with your real `arcade.css` to retain the exact original design.
6. Run `npm run dev` and verify the Play Game button opens `/arcade/game.html`.

## Critical notes
- Game HTML and their dependencies have **not** been provided. The arcade menu renders, but game pages will 404 until the actual game files are copied. No functionality or scores inside those games has been modified.
- Normalized arcade menu links to uppercase `GAMES/` matching the supplied screenshot. Linux hosts are case-sensitive. If your actual game file names differ, rename them or update hrefs.
- The Arcade is hidden from navigation while an unlock quiz is active; this is a frontend-only rule. Server-side assessment controls are still needed.
- Existing `window.location.assign` navigates to a **static route**, no need to create a FastAPI `/game` route. It also avoids redirecting the Play Game button to the FastAPI root.
- The static arcade page does not itself enforce auth or collect scores. For production, enforce per-user access, assessment restrictions and game-session/result validation on the backend. Do not rely on an HTML link to secure it.
- For the research study, collect game start/end, game ID, topic/lesson ID, attempts, outcome, score, duration and learner ID (server inferred from session). Keep quizzes independent; never let game scores directly unlock lessons.
