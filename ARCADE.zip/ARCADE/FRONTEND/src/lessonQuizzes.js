// Three-item formative quizzes. Each requires all answers; 3/3 passes the 70% threshold.
// Server-side assessment grading and question-bank protection are phase 2.
export const QUIZZES = {
 T001:[
  {question:"What does HTML stand for?",options:["HyperText Markup Language","HighText Machine Language","Home Tools Markup Language"],correct:0},
  {question:"What does a web browser do?",options:["Stores every website","Requests and displays webpages","Compiles SQL databases"],correct:1},
  {question:"Which technology controls most website styling?",options:["CSS","HTML","SQLite"],correct:0}],
 T002:[
  {question:"Which HTML element contains visible page content?",options:["head","body","title"],correct:1},
  {question:"What is a correct paragraph?",options:["<p>Hello</p>","<paragraph>Hello</paragraph>","<p>Hello<p>"],correct:0},
  {question:"Where does page metadata usually belong?",options:["footer","body","head"],correct:2}],
 T003:[
  {question:"What tag marks a top-level heading?",options:["<h6>","<h1>","<p>"],correct:1},
  {question:"What element creates a paragraph?",options:["<p>","<text>","<br>"],correct:0},
  {question:"Which element makes a line break?",options:["<hr>","<line>","<br>"],correct:2}],
 T004:[
  {question:"Which element creates a hyperlink?",options:["<a>","<linkto>","<href>"],correct:0},
  {question:"Which attribute gives a link destination?",options:["src","href","alt"],correct:1},
  {question:"Which points to a section with id='contact'?",options:["href='contact'","href='.contact'","href='#contact'"],correct:2}],
 T005:[
  {question:"Which element displays an image?",options:["<img>","<image>","<photo>"],correct:0},
  {question:"What does alt text provide?",options:["File size","Text alternative to an image","Image animation"],correct:1},
  {question:"Which element embeds video?",options:["<movie>","<video>","<clip>"],correct:1}],
 T006:[
  {question:"Which URL scheme starts an email link?",options:["email:","mailto:","message:"],correct:1},
  {question:"What does #about refer to?",options:["CSS class","Element with id='about'","Image file"],correct:1},
  {question:"Which link text is clearest?",options:["Click here","Here","View HTML resources"],correct:2}],
 T007:[
  {question:"How can an image become a clickable link?",options:["Put img inside a","Put a inside alt","Use src inside href without a"],correct:0},
  {question:"What element provides a figure caption?",options:["<caption>","<figcaption>","<description>"],correct:1},
  {question:"What is appropriate for a purely decorative image?",options:["Omit alt entirely","alt='decorative image'","alt=''"],correct:2}],
 T008:[
  {question:"Which creates an unordered list?",options:["<ul>","<ol>","<dl>"],correct:0},
  {question:"Which element creates a table row?",options:["<td>","<tr>","<th>"],correct:1},
  {question:"Which element marks a table header cell?",options:["<thead>","<th>","<header>"],correct:1}],
 T009:[
  {question:"What element contains form controls?",options:["<form>","<inputgroup>","<fieldsetonly>"],correct:0},
  {question:"Which input type is best for email?",options:["textonly","email","url"],correct:1},
  {question:"What links a label to an input?",options:["label for matching input id","label src matching input name","label class matching input type"],correct:0}],
 T010:[
  {question:"Which element usually contains a page's primary content?",options:["<main>","<div>","<aside>"],correct:0},
  {question:"Why use semantic HTML?",options:["To store passwords","To communicate structure and meaning","To run database commands"],correct:1},
  {question:"Which practice supports accessibility?",options:["Remove headings","Use meaningful image alt text","Use only mouse controls"],correct:1}]
};
