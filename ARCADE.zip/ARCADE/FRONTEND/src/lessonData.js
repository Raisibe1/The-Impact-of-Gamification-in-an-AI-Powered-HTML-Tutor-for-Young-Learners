export const structuredContent = {
  1: {
    objective: "Understand how the internet, websites and HTML work.",
    sections: [
      { heading: "1.1 What is the internet?", content: "The internet is a global network connecting computers, phones, servers and other devices.", example: "Think of a massive digital city. The internet provides the roads connecting buildings, while the World Wide Web contains many of the destinations we visit." },
      { heading: "1.2 What is a website?", content: "A website is a collection of related webpages that people can access through a web browser. A webpage is one document within a website.", example: "Examples include Google, YouTube, Wikipedia and an online school portal." },
      { heading: "1.3 How does a website work?", content: "A browser requests a page, a server sends the required files, and the browser displays the page.", example: "Browser requests page → Server sends files → Browser displays page" },
      { heading: "1.4 What is HTML?", content: "HTML means HyperText Markup Language. It is the standard markup language used to describe the structure and content of webpages. HTML helps browsers understand which content is a heading, paragraph, picture, link or form." },
      { heading: "1.5 The three web technologies", content: "Most websites use three important technologies.", example: "HTML = Structure\nCSS = Design\nJavaScript = Behaviour" },
      { heading: "1.6 Your first HTML code", content: "The h1 element creates a main heading. The p element creates a paragraph.", code: `<h1>Hello, World!</h1>
<p>My name is Alex.</p>
<p>I am learning HTML!</p>` },
    ],
    challenge: "Create a webpage introduction containing your name, your school and why you want to learn programming.",
    checkpoint: "Why do we use HTML, CSS and JavaScript for different purposes?",
  },
  2: {
    objective: "Learn how HTML tags, attributes and document structure work.",
    sections: [
      { heading: "2.1 What is an HTML tag?", content: "HTML tags are instructions written inside angle brackets. Many HTML elements have an opening tag and a closing tag. Some elements, such as img, are void elements and do not have closing tags.", code: `<p>This is a paragraph.</p>
<img src="school.jpg" alt="School building">` },
      { heading: "2.2 Structure of an HTML document", content: "A complete HTML page has a document declaration, an html root element, a head section containing page information, and a body section containing visible content.", code: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My First Website</title>
</head>
<body>
  <h1>Welcome to My Website</h1>
  <p>I am learning web development.</p>
</body>
</html>` },
      { heading: "2.3 Understanding document tags", content: "DOCTYPE declares the HTML document type. html is the root of the document. head contains metadata. title defines the browser-tab title. meta provides metadata. body contains the visible webpage content." },
      { heading: "2.4 What are attributes?", content: "Attributes provide additional information about HTML elements. They are written inside the opening tag.", code: `<html lang="en">
<p title="Welcome message">Hello, student!</p>` },
      { heading: "2.5 Nesting HTML elements", content: "Nesting means placing one HTML element inside another. Elements should be closed in the correct order.", code: `<!-- Incorrect -->
<p>I love <strong>HTML</p></strong>

<!-- Correct -->
<p>I love <strong>HTML</strong></p>` },
    ],
    challenge: "Create a complete HTML document with a title, main heading, two paragraphs and one strongly emphasised word.",
  },
  3: {
    objective: "Use headings and paragraphs to organise webpage content.",
    sections: [
      { heading: "3.1 What are headings?", content: "Headings organise webpage content into meaningful sections. HTML provides six heading levels, from h1 to h6. Heading levels express document hierarchy, not just font size." },
      { heading: "3.2 Writing headings in HTML", content: "The h1 element is the top-level heading. Lower levels create subsections. Do not choose heading levels purely because of how large they look. Use CSS to change their appearance.", code: `<h1>My Learning Journey</h1>
<h2>About Me</h2>
<h3>My Favourite Subjects</h3>
<h4>Mathematics</h4>` },
      { heading: "3.3 What are paragraphs?", content: "Paragraphs contain written information and are created with the p element.", code: `<p>My favourite subject is Mathematics because I enjoy solving problems.</p>` },
      { heading: "3.4 Text formatting elements", content: "strong gives text strong importance. em adds emphasis. br creates a line break. hr creates a thematic break. mark highlights content. small is used for side comments or fine print.", code: `<h1>My Coding Journey</h1>
<p>I am <strong>determined</strong> to become a developer.</p>
<p>Learning HTML is <em>exciting!</em></p>
<hr>
<p>Practice every day.<br>Never stop learning.</p>` },
    ],
    challenge: "Build a personal profile page with one main heading, two sections, three paragraphs and at least two text-formatting elements.",
    checkpoint: "Why should a developer use proper heading levels instead of making every heading an h1?",
  },
  8: {
    objective: "Use lists and tables to organise information.",
    sections: [
      { heading: "8.1 Why do we use lists?", content: "Lists organise related information in a clear, readable format. HTML supports unordered, ordered and description lists." },
      { heading: "8.2 Unordered lists", content: "Unordered lists use ul for the list and li for each list item.", code: `<h2>My Favourite Subjects</h2>
<ul>
  <li>Mathematics</li>
  <li>Physical Sciences</li>
  <li>Computer Science</li>
</ul>` },
      { heading: "8.3 Ordered lists", content: "Ordered lists use ol for the list and li for each list item.", code: `<h2>How to Create a Webpage</h2>
<ol>
  <li>Open your code editor.</li>
  <li>Create an HTML file.</li>
  <li>Write your HTML code.</li>
  <li>Open it in a browser.</li>
</ol>` },
      { heading: "8.4 Description lists", content: "Description lists use dl, dt and dd. The dt element identifies a term and dd provides its description.", code: `<dl>
  <dt>HTML</dt>
  <dd>Structures webpage content.</dd>
  <dt>CSS</dt>
  <dd>Styles webpage content.</dd>
</dl>` },
      { heading: "8.5 What is an HTML table?", content: "Tables organise data into rows and columns. Important table elements include table, tr, th, td and caption." },
      { heading: "8.6 Creating a table", content: "Use caption to describe the table. Use thead for the heading rows and tbody for the main data. th identifies a header cell and td identifies a data cell.", code: `<table>
  <caption>Student Study Schedule</caption>
  <thead>
    <tr><th scope="col">Day</th><th scope="col">Subject</th><th scope="col">Duration</th></tr>
  </thead>
  <tbody>
    <tr><td>Monday</td><td>HTML</td><td>45 minutes</td></tr>
    <tr><td>Tuesday</td><td>CSS</td><td>60 minutes</td></tr>
  </tbody>
</table>` },
    ],
    challenge: "Create a weekly timetable, a list of five subjects and an ordered list of study goals.",
  },
  9: {
    objective: "Learn how forms collect information from users.",
    sections: [
      { heading: "9.1 What is an HTML form?", content: "Forms allow users to enter information into a webpage. Examples include registration forms, login pages, contact forms, surveys and quiz-answer submissions." },
      { heading: "9.2 Important form elements", content: "form groups form controls. label names an input. input accepts input. textarea accepts multi-line text. select creates a dropdown. option defines a dropdown choice. button performs an action. fieldset groups related controls and legend labels a control group." },
      { heading: "9.3 Common input types", content: "Each input type is designed for a particular kind of user entry.", code: `<input type="text">
<input type="email">
<input type="password">
<input type="number">
<input type="date">
<input type="checkbox">
<input type="radio">` },
      { heading: "9.4 Build a student registration form", content: "A registration form can use labels and input elements to collect a learner's name, email address and school grade. The required attribute marks information that must be entered.", code: `<form action="/register" method="post">
  <h2>Student Registration</h2>
  <label for="name">Full Name</label>
  <input type="text" id="name" name="name" required>

  <label for="email">Email Address</label>
  <input type="email" id="email" name="email" required>

  <label for="grade">School Grade</label>
  <input type="number" id="grade" name="grade">

  <button type="submit">Register</button>
</form>` },
    ],
    challenge: "Create a student registration form using labels and suitable input types.",
  },
  10: {
    objective: "Explore semantic HTML and accessibility as the final topic in the learning pathway.",
    sections: [
      { heading: "10.1 Semantic HTML and accessibility", content: "This module introduces semantic HTML and accessibility. The curriculum identifies these as the focus of the final lesson in the learning pathway." },
      { heading: "10.2 Your final learning outcome", content: "The overall curriculum outcome is to build a functional, accessible, multi-section personal website using HTML." },
    ],
    challenge: "Plan a multi-section personal website that brings together the HTML skills covered in the course.",
  },
};


export const additionalContent = {
  4: { objective: "Create hyperlinks that connect webpages and sections.", sections: [
    {heading:"4.1 Anchor elements", content:"The a element creates links. The href attribute gives the destination.", code:'<a href="https://example.com">Visit a website</a>'},
    {heading:"4.2 Linking within a page", content:"Use an element id as a target and a link beginning with #.", code:'<a href="#contact">Contact</a>\n<section id="contact">Email us</section>'},
    {heading:"4.3 Safe new tabs", content:"Use target blank to open a new tab; include rel noopener.", code:'<a href="https://example.com" target="_blank" rel="noopener">Example</a>'}], challenge:"Build three external links and one internal link."},
  5: { objective:"Add meaningful images and multimedia to webpages.", sections:[
    {heading:"5.1 Images", content:"Use img with src for the file and alt for a meaningful text alternative.",code:'<img src="school.jpg" alt="Students reading in the library">'},
    {heading:"5.2 Audio",content:"The audio element can show built-in playback controls.",code:'<audio controls src="intro.mp3"></audio>'},
    {heading:"5.3 Video",content:"The video element can display a video with controls.",code:'<video controls src="demo.mp4"></video>'}], challenge:"Create a media gallery with descriptive alt text."},
  6: { objective:"Use intermediate hyperlinks for accessible navigation.", sections:[
    {heading:"6.1 Email links", content:"A mailto link opens the learner's email app.",code:'<a href="mailto:teacher@example.com">Email teacher</a>'},
    {heading:"6.2 Section navigation", content:"Links that begin with # navigate to matching section IDs.",code:'<nav><a href="#about">About</a></nav>\n<section id="about"><h2>About</h2></section>'},
    {heading:"6.3 Descriptive links", content:"Write meaningful link text instead of repeating 'click here'."}],challenge:"Build a link hub with internal, external and email links."},
  7: {objective:"Combine image tags with links and accessibility best practices.",sections:[
    {heading:"7.1 Images as links",content:"Place an img element inside an a element to create a clickable image.",code:'<a href="gallery.html"><img src="photo.jpg" alt="View student gallery"></a>'},
    {heading:"7.2 Figure and caption",content:"Use figure and figcaption for media with a caption.",code:'<figure><img src="tree.jpg" alt="A large oak tree"><figcaption>Our school garden</figcaption></figure>'},
    {heading:"7.3 Image alternatives",content:"Informative images need meaningful alt text; decorative images can use empty alt text."}],challenge:"Create a linked gallery with image captions."}
};
export const contentFor = (lessonNumber) => structuredContent[lessonNumber] || additionalContent[lessonNumber];
