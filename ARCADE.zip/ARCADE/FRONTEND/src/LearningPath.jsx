import { useEffect, useState } from "react";
import { LessonT001, LessonT002, LessonT003 } from "./lessons";
import { LessonT005, LessonT006 } from "./lessons2";
import { contentFor } from "./lessonData";
import { QUIZZES } from "./lessonQuizzes";
import "./learningPath.css";
import LessonTutor from "./LessonTutor";

export const COURSE = [
  {id:"T001", title:"Introduction to HTML and Web Basics", group:"HTML Foundations"},
  {id:"T002", title:"HTML Tags and Document Structure", group:"HTML Foundations"},
  {id:"T003", title:"Headings and Paragraphs", group:"HTML Foundations"},
  {id:"T004", title:"Hyperlinks", group:"HTML Elements"},
  {id:"T005", title:"Images and Multimedia", group:"HTML Elements"},
  {id:"T006", title:"Hyperlinks (Intermediate)", group:"HTML Elements"},
  {id:"T007", title:"Images and Tags", group:"HTML Elements"},
  {id:"T008", title:"Lists and Tables", group:"HTML Elements"},
  {id:"T009", title:"Forms and User Input", group:"Advanced HTML"},
  {id:"T010", title:"Semantic HTML and Accessibility", group:"Advanced HTML"}
];
const PASS_PERCENT = 70;
const OLD_COMPONENTS = {T001:LessonT001, T002:LessonT002, T003:LessonT003, T010:LessonT005};
// This is a browser-only prototype. Backend persistence and secure gating are phase 2.
const STORAGE_KEY = "codeverse-learning-path-demo-v1";
const defaultProgress = () => ({ passed: {}, viewed: {}, attempts: {} });
function readProgress() {
  try {
    const data=JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
    return data && typeof data === "object" ? {...defaultProgress(),...data} : defaultProgress();
  } catch { return defaultProgress(); }
}

export default function LearningPath({mode="lessons", onAssessmentChange=()=>{}}) {
  const [progress,setProgress]=useState(readProgress);
  const [active,setActive]=useState(null);
  const [quiz,setQuiz]=useState(false);
  const [answers,setAnswers]=useState({});
  const [result,setResult]=useState(null);
  const [project,setProject]=useState(false);
  useEffect(()=>{localStorage.setItem(STORAGE_KEY,JSON.stringify(progress));},[progress]);
  useEffect(()=>{onAssessmentChange(!!quiz); return ()=>onAssessmentChange(false);},[quiz,onAssessmentChange]);
  const passedCount=COURSE.filter(l=>progress.passed[l.id]).length;
  const percent=Math.round(100*passedCount/COURSE.length);
  const unlocked=(idx)=>idx===0 || !!progress.passed[COURSE[idx-1].id];
  const next=COURSE.find((l,i)=>unlocked(i) && !progress.passed[l.id]);
  function openLesson(lesson,idx){
    if(!unlocked(idx))return;
    setActive(lesson);setQuiz(false);setAnswers({});setResult(null);setProject(false);
  }
  function beginQuiz(){setQuiz(true);setAnswers({});setResult(null);}
  function submitQuiz(){
    const questions=QUIZZES[active.id];
    if(questions.some((_,i)=>answers[i]===undefined))return;
    const count=questions.reduce((n,q,i)=>n+(answers[i]===q.correct?1:0),0);
    const score=Math.round(100*count/questions.length);
    const passed=score>=PASS_PERCENT;
    setProgress(prev=>({
      ...prev,
      attempts:{...prev.attempts,[active.id]:[...(prev.attempts[active.id]||[]),{score,passed,date:new Date().toISOString()}]},
      passed:passed?{...prev.passed,[active.id]:true}:prev.passed
    }));
    setResult({score,passed,count,total:questions.length});
  }
  const lessonIndex=active?COURSE.findIndex(l=>l.id===active.id):-1;
  const OldContent=active?OLD_COMPONENTS[active.id]:null;
  const contents=active?contentFor(lessonIndex+1):null;
  return (
   <section className="page-section learning-workspace">
    <div className="lp-header"><div><p className="label">CODEVERSE / HTML LEARNING PATH</p><h2>{mode==="progress"?"Learner progression":"Your HTML Learning Journey"}</h2><p>Read each lesson, pass its quiz, and unlock the next topic in order.</p></div><div className="lp-stat"><strong>{percent}%</strong><span>{passedCount} of {COURSE.length} quizzes passed</span></div></div>
    <div className="lp-meter"><div style={{width:`${percent}%`}}/></div>
    <p className="lp-notice">Prototype: quiz results are saved in this browser only, not in SQLite. Secure per-user saving and unlock checks will be connected to FastAPI in the next step.</p>
    {!active && !project && <>
      {next && <button className="primary" onClick={()=>openLesson(next,COURSE.indexOf(next))}>Continue: {next.title}</button>}
      {Array.from(new Set(COURSE.map(l=>l.group))).map(group=><div key={group} className="lp-group"><h3>{group}</h3><div className="lp-grid">{COURSE.map((lesson,idx)=>lesson.group===group&&<button key={lesson.id} className="lp-card" disabled={!unlocked(idx)} onClick={()=>openLesson(lesson,idx)}><span>{lesson.id}</span><strong>{lesson.title}</strong><small>{progress.passed[lesson.id]?"✓ Quiz passed":unlocked(idx)?progress.viewed[lesson.id]?"Ready for quiz / Continue":"Available to learn":"🔒 Pass the previous quiz to unlock"}</small>{progress.attempts[lesson.id]?.length>0&&<small>Attempts: {progress.attempts[lesson.id].length}</small>}</button>)}</div></div>)}
      <div className="lp-final"><h3>Final Website Project</h3><p>Build an accessible, multi-section personal website after all ten lesson quizzes.</p><button className="secondary" disabled={passedCount!==COURSE.length} onClick={()=>setProject(true)}> {passedCount===COURSE.length?"Open final project":"🔒 Complete all lessons first"}</button></div>
    </>}
    {project&&<><button className="secondary" onClick={()=>setProject(false)}>← Learning path</button><LessonT006 /></>}
    {active&&<>
      <button className="secondary" onClick={()=>{setActive(null);setQuiz(false);setResult(null);}}>← Back to learning path</button>
      <div className="lp-lesson"><p className="label">{active.id} · {active.group}</p><h2>{active.title}</h2>
        {!quiz && <>
          {OldContent?<OldContent/>:<><h3>Learning objective</h3><p>{contents.objective}</p>{contents.sections.map((s,i)=><article key={i} className="lp-section"><h3>{s.heading}</h3><p>{s.content}</p>{s.example&&<pre>{s.example}</pre>}{s.code&&<pre><code>{s.code}</code></pre>}</article>)}<div className="lp-challenge"><strong>Practice challenge</strong><p>{contents.challenge}</p></div></>}
          <LessonTutor key={active.id} lesson={active} />
          {!progress.viewed[active.id]?<button className="primary" onClick={()=>setProgress(p=>({...p,viewed:{...p.viewed,[active.id]:true}}))}>I have finished studying this lesson</button>:<button className="primary" onClick={beginQuiz}>Take unlock quiz →</button>}
          {progress.passed[active.id]&&<p className="lp-success">This lesson has already been passed. You can revise or retake the quiz.</p>}
        </>}
        {quiz && <><div className="lp-exam-notice" role="status">Assessment mode: AI tutoring is unavailable until you exit the quiz.</div><h3>Unlock quiz · Pass mark {PASS_PERCENT}%</h3>{QUIZZES[active.id].map((q,i)=><fieldset className="lp-question" key={i} disabled={!!result}><legend>{i+1}. {q.question}</legend>{q.options.map((option,j)=><label key={j}><input type="radio" name={`q-${i}`} checked={answers[i]===j} onChange={()=>setAnswers(a=>({...a,[i]:j}))}/>{option}</label>)}</fieldset>)}
          {!result?<button className="primary" disabled={Object.keys(answers).length!==QUIZZES[active.id].length} onClick={submitQuiz}>Submit answers</button>:<div className="lp-result"><h3>{result.passed?"✓ Quiz passed!":"Quiz not passed yet"}</h3><p>Score: {result.count}/{result.total} ({result.score}%). {result.passed?"The next lesson is now unlocked.":"Review this lesson and try again."}</p><button className="primary" onClick={()=>{setActive(null);setQuiz(false);setResult(null);}}>Back to learning path</button><button className="secondary" onClick={()=>{setQuiz(false);setResult(null);}}>Review lesson</button></div>}
        </>}
      </div>
    </>}
   </section>
  );
}
