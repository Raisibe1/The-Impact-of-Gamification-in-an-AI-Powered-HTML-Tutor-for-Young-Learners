// Arcade landing page navigation is handled by anchor links.
