Copy your playable HTML game files here:
snake-ladder.html
crossword.html
matchMasters.html
pixel-detective.html
Copy the game-specific CSS/JS/ASSETS dependencies, preserving their relative paths.
