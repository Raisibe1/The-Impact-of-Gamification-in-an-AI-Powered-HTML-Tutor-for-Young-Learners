
document.addEventListener("DOMContentLoaded", () => {

    console.log("WEBDEV ARCADE INITIALIZED");

    // Welcome message
    console.log("Play. Think. Create.");

    // Identify game links
    const gameButtons = document.querySelectorAll(".game-button");

    gameButtons.forEach(button => {

        button.addEventListener("click", (event) => {

            const destination = button.getAttribute("href");

            console.log("Launching game:", destination);

            // Game pages will be implemented in the next stages.

        });

    });

});
