function escapeHTML(text) {
    return text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

document.addEventListener("DOMContentLoaded", () => {

    const grid = document.getElementById("crosswordGrid");
    const acrossContainer = document.getElementById("acrossClues");
    const downContainer = document.getElementById("downClues");

    const checkButton = document.getElementById("checkButton");
    const resetButton = document.getElementById("resetButton");

    const feedback = document.getElementById("gameFeedback");

    const MIN_ROW = -4;
    const MIN_COL = -8;
    const ROWS = 13;
    const COLS = 21;

    // WORDS, DEFINITIONS AND APPLICATIONS
    // Coordinates define the intersecting crossword layout.

    const words = [

        {
            word: "ACCESSIBILITY",
            row: 0, col: 0, direction: "across",
            lesson: "T008",
            definition: "The practice of making websites usable by people with different abilities and needs.",
            application: "Use descriptive links, keyboard-friendly controls and alternative text so more people can use your website."
        },

        {
            word: "ATTRIBUTE",
            row: 0, col: 0, direction: "down",
            lesson: "T002",
            definition: "Extra information added inside an HTML opening tag to configure an element.",
            application: 'Use attributes such as href, src, id and class to give HTML elements additional information.'
        },

        {
            word: "PARAGRAPH",
            row: 3, col: -2, direction: "across",
            lesson: "T003",
            definition: "A block of text used to present related sentences or information.",
            application: "Use the <p> element to display descriptions, articles and ordinary text on a webpage."
        },

        {
            word: "SEMANTIC",
            row: 0, col: 4, direction: "down",
            lesson: "T008",
            definition: "HTML that communicates the meaning and purpose of content through its element names.",
            application: "Use elements such as <main>, <header>, <nav> and <footer> to describe webpage sections."
        },

        {
            word: "ELEMENT",
            row: 1, col: -6, direction: "across",
            lesson: "T002",
            definition: "A complete HTML building block, commonly made up of an opening tag, content and a closing tag.",
            application: 'For example, <p>Hello</p> is an HTML element containing paragraph text.'
        },

        {
            word: "BROWSER",
            row: -4, col: -4, direction: "down",
            lesson: "T001",
            definition: "Software that retrieves and displays websites for users.",
            application: "Chrome, Firefox and Edge interpret HTML and display the resulting webpage."
        },

        {
            word: "HEADING",
            row: 0, col: -6, direction: "down",
            lesson: "T003",
            definition: "A title or subtitle used to organise and describe sections of webpage content.",
            application: "Use HTML heading elements from <h1> to <h6> to create a meaningful content hierarchy."
        },

        {
            word: "DOCTYPE",
            row: -2, col: -5, direction: "across",
            lesson: "T002",
            definition: "A declaration at the beginning of an HTML document that tells the browser which document standard to use.",
            application: "Write <!DOCTYPE html> at the top of a modern HTML document."
        },

        {
            word: "HTML",
            row: -1, col: 11, direction: "down",
            lesson: "T001",
            definition: "The standard markup language used to structure content on webpages.",
            application: "Use it to create page content such as headings, links, images, forms and lists."
        },

        {
            word: "BODY",
            row: 3, col: -8, direction: "across",
            lesson: "T002",
            definition: "The HTML section containing the content displayed in the webpage.",
            application: "Place visible headings, paragraphs, images and other page content inside the <body> element."
        },

        {
            word: "TAG",
            row: 5, col: 4, direction: "across",
            lesson: "T002",
            definition: "A piece of HTML markup written inside angle brackets that identifies an element.",
            application: 'For example, <h1> is an opening heading tag and </h1> is its closing tag.'
        },

        {
            word: "ALT",
            row: -1, col: 9, direction: "down",
            lesson: "T008",
            definition: "An HTML attribute that provides alternative text describing an image.",
            application: 'Use alt="School building" on an image to provide a text alternative when appropriate.'
        }

    ];

    let selectedWord = null;
    let solvedWords = new Set();

    // CONVERT WORD COORDINATES INTO GRID COORDINATES

    function getCoordinates(word) {

        const cells = [];

        for (let i = 0; i < word.word.length; i++) {

            const row = word.row + MIN_ROW * -1 +
                (word.direction === "down" ? i : 0);

            const col = word.col + MIN_COL * -1 +
                (word.direction === "across" ? i : 0);

            cells.push({ row, col });
        }

        return cells;
    }

    // BUILD A MAP OF ALL OCCUPIED CELLS

    const cellMap = new Map();

    words.forEach(word => {

        word.cells = getCoordinates(word);

        word.cells.forEach((cell, index) => {

            const key = `${cell.row}-${cell.col}`;

            if (!cellMap.has(key)) {
                cellMap.set(key, {
                    letter: word.word[index],
                    words: []
                });
            }

            const existing = cellMap.get(key);

            if (existing.letter !== word.word[index]) {
                console.error("Crossword intersection error:", key);
            }

            existing.words.push(word);
        });
    });

    // AUTOMATICALLY NUMBER CLUE STARTING POSITIONS

    const starts = new Map();

    words.forEach(word => {

        const firstCell = word.cells[0];
        const key = `${firstCell.row}-${firstCell.col}`;

        if (!starts.has(key)) {
            starts.set(key, {
                row: firstCell.row,
                col: firstCell.col,
                words: []
            });
        }

        starts.get(key).words.push(word);
    });

    const orderedStarts = [...starts.values()].sort((a, b) => {
        return a.row - b.row || a.col - b.col;
    });

    orderedStarts.forEach((start, index) => {
        start.number = index + 1;

        start.words.forEach(word => {
            word.number = start.number;
        });
    });

    // BUILD THE CROSSWORD GRID

    function buildGrid() {

        grid.innerHTML = "";

        for (let row = 0; row < ROWS; row++) {

            for (let col = 0; col < COLS; col++) {

                const key = `${row}-${col}`;
                const cellData = cellMap.get(key);

                const cell = document.createElement("div");

                if (!cellData) {
                    cell.className = "crossword-cell empty";
                    grid.appendChild(cell);
                    continue;
                }

                cell.className = "crossword-cell";
                cell.id = `cell-${row}-${col}`;

                const start = starts.get(key);

                if (start) {
                    const number = document.createElement("span");
                    number.className = "cell-number";
                    number.textContent = start.number;
                    cell.appendChild(number);
                }

                const input = document.createElement("input");

                input.type = "text";
                input.maxLength = 1;
                input.autocomplete = "off";
                input.spellcheck = false;
                input.setAttribute("aria-label", `Row ${row + 1}, column ${col + 1}`);
                input.dataset.row = row;
                input.dataset.col = col;

                input.addEventListener("input", handleInput);
                input.addEventListener("keydown", handleKeyboard);

                cell.appendChild(input);
                grid.appendChild(cell);
            }
        }
    }

    function getInput(row, col) {
        return document.querySelector(
            `input[data-row="${row}"][data-col="${col}"]`
        );
    }

    // SELECT A WORD AND HIGHLIGHT ITS CELLS

    function selectWord(word) {

        selectedWord = word;

        document.querySelectorAll(".crossword-cell").forEach(cell => {
            cell.classList.remove("active-cell");
        });

        document.querySelectorAll(".clue-card").forEach(card => {
            card.classList.remove("selected");
        });

        word.cells.forEach(position => {

            const cell = document.getElementById(
                `cell-${position.row}-${position.col}`
            );

            if (cell) {
                cell.classList.add("active-cell");
            }
        });

        const selectedCard = document.getElementById(
            `clue-${word.direction}-${word.number}`
        );

        if (selectedCard) {
            selectedCard.classList.add("selected");
        }

        const firstCell = word.cells[0];
        const input = getInput(firstCell.row, firstCell.col);

        if (input) {
            input.focus();
        }
    }

    // DISPLAY THE CLUES WITH DEFINITIONS AND APPLICATIONS

    function renderClues() {

        words.forEach(word => {

            const card = document.createElement("article");

            card.className = "clue-card";
            card.id = `clue-${word.direction}-${word.number}`;

            card.innerHTML = `
                <div class="clue-top">
                    <span class="clue-number">
                        ${word.number}. ${word.direction.toUpperCase()}
                        · ${word.word.length} LETTERS
                    </span>

                    <span class="lesson-tag">${word.lesson}</span>
                </div>

                <p class="clue-definition">
                    <strong>Definition:</strong> ${escapeHTML(word.definition)}
                </p>

                <p class="clue-application">
                    <strong>Application:</strong> ${escapeHTML(word.application)}
                </p>
            `;

            card.addEventListener("click", () => {
                selectWord(word);
            });

            if (word.direction === "across") {
                acrossContainer.appendChild(card);
            } else {
                downContainer.appendChild(card);
            }
        });
    }

    // INPUT HANDLING

    function handleInput(event) {

        const input = event.target;

        input.value = input.value
            .replace(/[^a-z]/gi, "")
            .slice(-1)
            .toUpperCase();

        input.parentElement.classList.remove(
            "correct-cell",
            "wrong-cell"
        );

        if (!input.value || !selectedWord) return;

        const index = selectedWord.cells.findIndex(cell =>
            cell.row === Number(input.dataset.row) &&
            cell.col === Number(input.dataset.col)
        );

        if (index >= 0 && index < selectedWord.cells.length - 1) {

            const next = selectedWord.cells[index + 1];

            getInput(next.row, next.col)?.focus();
        }

        updateStats();
    }

    // KEYBOARD NAVIGATION

    function handleKeyboard(event) {

        const input = event.target;

        const row = Number(input.dataset.row);
        const col = Number(input.dataset.col);

        const movement = {
            ArrowUp: [-1, 0],
            ArrowDown: [1, 0],
            ArrowLeft: [0, -1],
            ArrowRight: [0, 1]
        };

        if (movement[event.key]) {

            event.preventDefault();

            const [rowChange, colChange] = movement[event.key];

            getInput(row + rowChange, col + colChange)?.focus();
        }

        if (event.key === "Backspace" && !input.value && selectedWord) {

            const index = selectedWord.cells.findIndex(cell =>
                cell.row === row && cell.col === col
            );

            if (index > 0) {

                event.preventDefault();

                const previous = selectedWord.cells[index - 1];

                getInput(previous.row, previous.col)?.focus();
            }
        }
    }

    // CHECK ANSWERS

function checkAnswers() {

    let correct = 0;
    let attempted = 0;

    words.forEach(word => {

        // Collect all letters belonging to this word
        const letters = word.cells.map(cell => {

            const input = getInput(cell.row, cell.col);

            return input ? input.value.toUpperCase() : "";

        });

        // Combine letters into one answer
        const answer = letters.join("");

        // Check whether every letter is correct
        const isCorrect = answer === word.word;

        // Count only fully completed words as attempted
        if (letters.every(letter => letter !== "")) {
            attempted++;
        }

        // Clear previous answer styling
        word.cells.forEach(cell => {

            const input = getInput(cell.row, cell.col);

            if (!input) return;

            input.parentElement.classList.remove(
                "correct-cell",
                "wrong-cell"
            );

        });

        // Apply correct or incorrect styling
        if (isCorrect) {

            correct++;

            solvedWords.add(word.word);

            word.cells.forEach(cell => {

                const input = getInput(cell.row, cell.col);

                if (input) {
                    input.parentElement.classList.add("correct-cell");
                }

            });

        } else {

            solvedWords.delete(word.word);

            word.cells.forEach(cell => {

                const input = getInput(cell.row, cell.col);

                if (input && input.value !== "") {
                    input.parentElement.classList.add("wrong-cell");
                }

            });

        }

    });

    // Update the game statistics
    updateStats();

    // Display feedback to the learner
    if (correct === words.length) {

        feedback.textContent =
            "🏆 Outstanding! You completed the entire HTML crossword. You are building your developer vocabulary!";

        feedback.style.color = "#22c55e";

    } else {

        feedback.textContent =
            `${correct} of ${words.length} words correct. ` +
            `${attempted} words attempted. Keep decoding the clues!`;

        feedback.style.color = "#00f5ff";

    }

}


    // UPDATE GAME PROGRESS

    function updateStats() {

        const correct = solvedWords.size;
        const percentage = Math.round((correct / words.length) * 100);

        document.getElementById("wordCount").textContent =
            `${correct} / ${words.length}`;

        document.getElementById("correctCount").textContent = correct;

        document.getElementById("progress").textContent =
            `${percentage}%`;

        words.forEach(word => {

            const card = document.getElementById(
                `clue-${word.direction}-${word.number}`
            );

            if (card) {
                card.classList.toggle(
                    "solved",
                    solvedWords.has(word.word)
                );
            }
        });
    }

    // SWITCH BETWEEN ACROSS AND DOWN

    document.querySelectorAll(".tab-button").forEach(button => {

        button.addEventListener("click", () => {

            document.querySelectorAll(".tab-button").forEach(tab => {
                tab.classList.remove("active");
            });

            button.classList.add("active");

            const showAcross = button.dataset.tab === "across";

            acrossContainer.hidden = !showAcross;
            downContainer.hidden = showAcross;
        });
    });

    // RESET THE PUZZLE

    function resetPuzzle() {

        grid.querySelectorAll("input").forEach(input => {
            input.value = "";
            input.parentElement.classList.remove(
                "correct-cell",
                "wrong-cell",
                "active-cell"
            );
        });

        solvedWords.clear();
        selectedWord = null;

        document.querySelectorAll(".clue-card").forEach(card => {
            card.classList.remove("selected", "solved");
        });

        feedback.textContent = "Puzzle reset. Ready for another attempt?";
        feedback.style.color = "#94a3b8";

        updateStats();
    }

    // EVENT LISTENERS

    checkButton.addEventListener("click", checkAnswers);
    resetButton.addEventListener("click", resetPuzzle);

    // INITIALISE GAME

    buildGrid();
    renderClues();
    updateStats();

    console.log("WEBDEV ARCADE: Code Crossword initialized!");

});
