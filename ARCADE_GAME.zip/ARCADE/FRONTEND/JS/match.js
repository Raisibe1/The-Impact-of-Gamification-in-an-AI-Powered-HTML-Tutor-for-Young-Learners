
document.addEventListener("DOMContentLoaded", () => {
  "use strict";

  // ==========================================
  // MATCH MASTERS - TWO GAME MODES
  // WEBDEV ARCADE
  // ==========================================

  const rounds = [
    {
      title: "The Digital Skeleton",
      description: "Discover how an HTML document is structured.",
      lesson: "T002",
      pairs: [
        {
          id: "doctype",
          code: "<!DOCTYPE html>",
          meaning: "Declares a modern HTML5 document.",
          explanation: "DOCTYPE tells the browser to use modern HTML standards."
        },
        {
          id: "html",
          code: "<html>",
          meaning: "The root element of an HTML document.",
          explanation: "The html element contains the head and body."
        },
        {
          id: "head",
          code: "<head>",
          meaning: "Contains page metadata and resource links.",
          explanation: "The head can contain a title, metadata and stylesheet links."
        },
        {
          id: "body",
          code: "<body>",
          meaning: "Contains the visible webpage content.",
          explanation: "Headings, paragraphs, images and other page content go in the body."
        },
        {
          id: "title",
          code: "<title>",
          meaning: "Sets the webpage title shown in the browser tab.",
          explanation: "The title element belongs inside the head."
        }
      ]
    },
    {
      title: "Text Architects",
      description: "Build clear and meaningful webpage text.",
      lesson: "T003",
      pairs: [
        {
          id: "h1",
          code: "<h1>",
          meaning: "Represents a top-level heading.",
          explanation: "Use h1 for the main heading of a page or content area."
        },
        {
          id: "h2",
          code: "<h2>",
          meaning: "Represents a second-level heading.",
          explanation: "An h2 introduces a subsection beneath a top-level heading."
        },
        {
          id: "h6",
          code: "<h6>",
          meaning: "Represents a sixth-level heading.",
          explanation: "HTML provides six heading levels for organizing content."
        },
        {
          id: "p",
          code: "<p>",
          meaning: "Represents a paragraph of text.",
          explanation: "Paragraphs group related sentences and information."
        },
        {
          id: "br",
          code: "<br>",
          meaning: "Creates a line break within text.",
          explanation: "The br element inserts a line break without starting a new paragraph."
        }
      ]
    },
    {
      title: "Semantic City",
      description: "Give every section of a webpage a purpose.",
      lesson: "T008",
      pairs: [
        {
          id: "header",
          code: "<header>",
          meaning: "Introduces a page or a section.",
          explanation: "A header may contain headings, logos or introductory content."
        },
        {
          id: "nav",
          code: "<nav>",
          meaning: "Contains major navigation links.",
          explanation: "Use nav for important navigation menus."
        },
        {
          id: "main",
          code: "<main>",
          meaning: "Contains the primary content of the page.",
          explanation: "Main identifies the dominant content of a document."
        },
        {
          id: "article",
          code: "<article>",
          meaning: "Represents self-contained content.",
          explanation: "Articles work well for blog posts and news stories."
        },
        {
          id: "section",
          code: "<section>",
          meaning: "Groups content around a common theme.",
          explanation: "Sections organize related content, often under headings."
        },
        {
          id: "aside",
          code: "<aside>",
          meaning: "Contains related or supplementary content.",
          explanation: "An aside can contain tips, sidebars or related information."
        },
        {
          id: "footer",
          code: "<footer>",
          meaning: "Contains footer information for a page or section.",
          explanation: "Footers often include copyright, author or related links."
        }
      ]
    },
    {
      title: "Accessibility Heroes",
      description: "Make the web more usable for everyone.",
      lesson: "T008",
      pairs: [
        {
          id: "alt",
          code: "alt",
          meaning: "Provides a text alternative for an image.",
          explanation: "Meaningful images need appropriate alternative text. Decorative images can use an empty alt value."
        },
        {
          id: "screenreader",
          code: "Screen reader",
          meaning: "Software that presents digital content through speech or braille.",
          explanation: "Screen readers help people access text, controls and page structure."
        },
        {
          id: "semantic",
          code: "Semantic HTML",
          meaning: "Uses elements that describe content meaning.",
          explanation: "Semantic elements communicate the purpose of webpage content."
        },
        {
          id: "keyboard",
          code: "Keyboard access",
          meaning: "Allows users to operate controls without a mouse.",
          explanation: "Interactive controls should support keyboard interaction."
        },
        {
          id: "labels",
          code: "<label>",
          meaning: "Provides an accessible name for a form control.",
          explanation: "Labels help users understand the purpose of form inputs."
        }
      ]
    }
  ];

  // ==========================================
  // DOM ELEMENTS
  // ==========================================

  const $ = id => document.getElementById(id);

  const modeScreen = $("modeScreen");
  const gamePanel = $("gamePanel");
  const resultsPanel = $("resultsPanel");

  const classicBoard = $("classicBoard");
  const memoryBoard = $("memoryBoard");

  const codeCards = $("codeCards");
  const meaningCards = $("meaningCards");
  const memoryCards = $("memoryCards");

  const feedback = $("feedback");
  const nextButton = $("nextButton");

  // ==========================================
  // GAME STATE
  // ==========================================

  let gameMode = null;
  let currentRound = 0;

  let firstSelection = null;
  let secondSelection = null;

  let matchedIds = new Set();

  let score = 0;
  let combo = 0;
  let attempts = 0;
  let correctAttempts = 0;
  let seconds = 0;

  let timerInterval = null;
  let timerRunning = false;
  let pendingTimeout = null;

  let checking = false;
  let roundFinished = false;
  let gameFinished = false;

  // ==========================================
  // UTILITIES
  // ==========================================

  function shuffle(items) {
    const result = [...items];

    for (let i = result.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [result[i], result[j]] = [result[j], result[i]];
    }

    return result;
  }

  function formatTime(totalSeconds) {
    const minutes = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;

    return (
      String(minutes).padStart(2, "0") +
      ":" +
      String(secs).padStart(2, "0")
    );
  }

  function showFeedback(message, type = "") {
    feedback.textContent = message;
    feedback.className = `feedback ${type}`;
  }

  function clearPendingTimeout() {
    if (pendingTimeout !== null) {
      clearTimeout(pendingTimeout);
      pendingTimeout = null;
    }
  }

  function startTimer() {
    if (timerRunning || gameFinished) return;

    timerRunning = true;

    timerInterval = setInterval(() => {
      seconds++;
      $("timer").textContent = formatTime(seconds);
    }, 1000);
  }

  function stopTimer() {
    clearInterval(timerInterval);
    timerInterval = null;
    timerRunning = false;
  }

  // ==========================================
  // SELECT GAME MODE
  // ==========================================

  function startGame(mode) {
    if (mode !== "classic" && mode !== "memory") return;

    stopTimer();
    clearPendingTimeout();

    gameMode = mode;
    currentRound = 0;

    score = 0;
    combo = 0;
    attempts = 0;
    correctAttempts = 0;
    seconds = 0;

    checking = false;
    roundFinished = false;
    gameFinished = false;

    $("timer").textContent = "00:00";

    modeScreen.hidden = true;
    resultsPanel.hidden = true;
    gamePanel.hidden = false;

    classicBoard.hidden = mode !== "classic";
    memoryBoard.hidden = mode !== "memory";

    $("modeBadge").textContent =
      mode === "classic" ? "CLASSIC MATCH" : "MEMORY FLIP";

    loadRound();
  }

  function changeMode() {
    stopTimer();
    clearPendingTimeout();

    gameMode = null;
    checking = false;
    roundFinished = false;
    gameFinished = false;

    firstSelection = null;
    secondSelection = null;

    gamePanel.hidden = true;
    resultsPanel.hidden = true;
    modeScreen.hidden = false;
  }

  // ==========================================
  // LOAD ROUND
  // ==========================================

  function loadRound() {
    clearPendingTimeout();

    const round = rounds[currentRound];

    firstSelection = null;
    secondSelection = null;

    matchedIds = new Set();
    combo = 0;
    checking = false;
    roundFinished = false;

    $("roundLabel").textContent =
      `ROUND ${currentRound + 1} OF ${rounds.length}`;

    $("roundTitle").textContent = round.title;
    $("roundDescription").textContent = round.description;
    $("lessonBadge").textContent = round.lesson;

    nextButton.hidden = true;

    if (gameMode === "classic") {
      buildClassicBoard(round);
    } else {
      buildMemoryBoard(round);
    }

    updateStats();

    showFeedback(
      gameMode === "classic"
        ? "Select an HTML code card, then find its meaning."
        : "Flip two hidden cards and find a matching code and meaning."
    );

    startTimer();
  }

  // ==========================================
  // CLASSIC MODE
  // ==========================================

  function createClassicCard(pair, type) {
    const button = document.createElement("button");

    button.type = "button";
    button.className = `match-card ${type}-card`;

    button.dataset.id = pair.id;
    button.dataset.type = type;

    button.textContent =
      type === "code" ? pair.code : pair.meaning;

    button.addEventListener("click", () => {
      selectClassicCard(button, pair.id, type);
    });

    return button;
  }

  function buildClassicBoard(round) {
    codeCards.replaceChildren();
    meaningCards.replaceChildren();

    shuffle(round.pairs).forEach(pair => {
      codeCards.appendChild(createClassicCard(pair, "code"));
    });

    shuffle(round.pairs).forEach(pair => {
      meaningCards.appendChild(createClassicCard(pair, "meaning"));
    });
  }

  function selectClassicCard(button, id, type) {
    if (checking || roundFinished || gameFinished) return;
    if (matchedIds.has(id)) return;

    const container =
      type === "code" ? codeCards : meaningCards;

    container.querySelectorAll(".selected").forEach(card => {
      card.classList.remove("selected");
    });

    button.classList.add("selected");

    const selection = { button, id, type };

    if (type === "code") {
      firstSelection = selection;
    } else {
      secondSelection = selection;
    }

    if (firstSelection && secondSelection) {
      checkPair();
    }
  }

  // ==========================================
  // MEMORY MODE
  // ==========================================

  function buildMemoryBoard(round) {
    memoryCards.replaceChildren();

    const cards = [];

    round.pairs.forEach(pair => {
      cards.push({
        id: pair.id,
        type: "code",
        content: pair.code
      });

      cards.push({
        id: pair.id,
        type: "meaning",
        content: pair.meaning
      });
    });

    shuffle(cards).forEach(card => {
      memoryCards.appendChild(createMemoryCard(card));
    });
  }

  function createMemoryCard(card) {
    const button = document.createElement("button");

    button.type = "button";
    button.className = "flip-card";

    button.dataset.id = card.id;
    button.dataset.type = card.type;

    button.setAttribute("aria-label", "Hidden memory card");
    button.setAttribute("aria-pressed", "false");

    const inner = document.createElement("span");
    inner.className = "flip-inner";

    const front = document.createElement("span");
    front.className = "flip-front";
    front.textContent = "?";

    const back = document.createElement("span");
    back.className = "flip-back";

    // textContent keeps HTML examples as literal text
    back.textContent = card.content;
    back.setAttribute("aria-hidden", "true");

    inner.append(front, back);
    button.appendChild(inner);

    button.addEventListener("click", () => {
      selectMemoryCard(button, card);
    });

    return button;
  }

  function revealMemoryCard(button, card) {
    button.classList.add("flipped");
    button.setAttribute("aria-pressed", "true");

    button.setAttribute(
      "aria-label",
      `${card.type === "code" ? "Code" : "Meaning"}: ${card.content}`
    );

    button.querySelector(".flip-back")
      .setAttribute("aria-hidden", "false");
  }

  function hideMemoryCard(button) {
    button.classList.remove("flipped", "wrong");
    button.setAttribute("aria-pressed", "false");
    button.setAttribute("aria-label", "Hidden memory card");

    button.querySelector(".flip-back")
      .setAttribute("aria-hidden", "true");
  }

  function selectMemoryCard(button, card) {
    if (checking || roundFinished || gameFinished) return;
    if (button.disabled || button.classList.contains("flipped")) return;

    revealMemoryCard(button, card);

    const selection = {
      button,
      id: card.id,
      type: card.type
    };

    if (!firstSelection) {
      firstSelection = selection;
      return;
    }

    secondSelection = selection;

    checkPair();
  }

  // ==========================================
  // SHARED MATCHING LOGIC
  // ==========================================

  function checkPair() {
    if (!firstSelection || !secondSelection) return;

    checking = true;
    attempts++;

    const first = firstSelection;
    const second = secondSelection;

    const isCorrect =
      first.id === second.id &&
      first.type !== second.type;

    if (isCorrect) {
      correctAttempts++;
      combo++;

      const points =
        100 + Math.min((combo - 1) * 25, 100);

      score += points;
      matchedIds.add(first.id);

      first.button.classList.remove("selected", "wrong");
      second.button.classList.remove("selected", "wrong");

      first.button.classList.add("matched");
      second.button.classList.add("matched");

      first.button.disabled = true;
      second.button.disabled = true;

      const pair = rounds[currentRound].pairs.find(
        item => item.id === first.id
      );

      showFeedback(
        `✓ Perfect match! +${points} points. ${pair.explanation}`,
        "success"
      );

      firstSelection = null;
      secondSelection = null;
      checking = false;

      updateStats();

      if (matchedIds.size === rounds[currentRound].pairs.length) {
        completeRound();
      }

    } else {
      combo = 0;

      first.button.classList.add("wrong");
      second.button.classList.add("wrong");

      showFeedback(
        "Not quite! Remember these cards and try another combination.",
        "error"
      );

      updateStats();

      pendingTimeout = setTimeout(() => {
        if (gameMode === "memory") {
          hideMemoryCard(first.button);
          hideMemoryCard(second.button);
        } else {
          first.button.classList.remove("wrong", "selected");
          second.button.classList.remove("wrong", "selected");
        }

        firstSelection = null;
        secondSelection = null;
        checking = false;
        pendingTimeout = null;
      }, gameMode === "memory" ? 1100 : 650);
    }
  }

  // ==========================================
  // UPDATE STATISTICS
  // ==========================================

  function updateStats() {
    const total = rounds[currentRound].pairs.length;
    const matched = matchedIds.size;

    $("score").textContent = score.toLocaleString();
    $("matched").textContent = `${matched} / ${total}`;
    $("combo").textContent = `x${combo}`;

    const percentage = Math.round((matched / total) * 100);

    $("progressText").textContent = `${percentage}%`;
    $("progressBar").style.width = `${percentage}%`;

    $("progressTrack").setAttribute(
      "aria-valuenow",
      String(percentage)
    );
  }

  // ==========================================
  // ROUND PROGRESSION
  // ==========================================

  function completeRound() {
    roundFinished = true;
    stopTimer();

    const lastRound =
      currentRound === rounds.length - 1;

    showFeedback(
      lastRound
        ? "🏆 All four rounds complete! Your results are ready."
        : "🎉 Round complete! You've unlocked the next challenge.",
      "success"
    );

    nextButton.textContent =
      lastRound ? "View Results →" : "Next Round →";

    nextButton.hidden = false;
  }

  function nextRound() {
    if (!roundFinished || gameFinished) return;

    if (currentRound === rounds.length - 1) {
      finishGame();
      return;
    }

    currentRound++;
    loadRound();
  }

  // ==========================================
  // FINAL RESULTS
  // ==========================================

  function finishGame() {
    stopTimer();
    clearPendingTimeout();

    gameFinished = true;

    const accuracy = attempts === 0
      ? 0
      : Math.round((correctAttempts / attempts) * 100);

    $("finalScore").textContent = score.toLocaleString();
    $("finalAccuracy").textContent = `${accuracy}%`;
    $("finalTime").textContent = formatTime(seconds);

    $("resultMode").textContent =
      gameMode === "classic"
        ? "CLASSIC MATCH"
        : "MEMORY FLIP";

    let message;

    if (accuracy === 100) {
      message =
        "Flawless victory! Every match was correct. You've mastered these HTML foundations.";
    } else if (accuracy >= 80) {
      message =
        "Excellent coding knowledge! Your HTML understanding is growing stronger.";
    } else if (accuracy >= 60) {
      message =
        "Mission accomplished! Review the explanations and aim for higher accuracy.";
    } else {
      message =
        "Every developer starts somewhere. Play again and sharpen your HTML skills!";
    }

    $("resultsMessage").textContent = message;

    gamePanel.hidden = true;
    resultsPanel.hidden = false;

    resultsPanel.scrollIntoView({
      behavior: "smooth",
      block: "start"
    });
  }

  // ==========================================
  // RESTART CURRENT MODE
  // ==========================================

  function restartGame() {
    if (!gameMode) return;
    startGame(gameMode);
  }

  // ==========================================
  // EVENT LISTENERS
  // ==========================================

  $("classicMode").addEventListener("click", () => {
    startGame("classic");
  });

  $("memoryMode").addEventListener("click", () => {
    startGame("memory");
  });

  $("restartButton").addEventListener("click", restartGame);

  $("changeModeButton").addEventListener("click", changeMode);

  $("resultsChangeMode").addEventListener("click", changeMode);

  $("playAgainButton").addEventListener("click", restartGame);

  nextButton.addEventListener("click", nextRound);

  // ==========================================
  // INITIAL STATE
  // ==========================================

  modeScreen.hidden = false;
  gamePanel.hidden = true;
  resultsPanel.hidden = true;

  console.log("WEBDEV ARCADE: Match Masters Dual Mode ready!");

});
