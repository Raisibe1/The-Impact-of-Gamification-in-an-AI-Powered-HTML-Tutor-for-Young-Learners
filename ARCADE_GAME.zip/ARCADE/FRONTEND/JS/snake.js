
document.addEventListener("DOMContentLoaded", () => {

    // GAME ELEMENTS
    const board = document.getElementById("gameBoard");
    const rollButton = document.getElementById("rollButton");
    const restartButton = document.getElementById("restartButton");
    const dice = document.getElementById("dice");

    const currentPlayerDisplay = document.getElementById("currentPlayer");
    const gameStatus = document.getElementById("gameStatus");
    const diceResult = document.getElementById("diceResult");

    const modal = document.getElementById("challengeModal");
    const challengeQuestion = document.getElementById("challengeQuestion");
    const challengeOptions = document.getElementById("challengeOptions");
    const challengeFeedback = document.getElementById("challengeFeedback");

    // GAME CONFIGURATION
    const players = [
        { name: "Player 1", position: 0, tokenClass: "player-one" },
        { name: "Player 2", position: 0, tokenClass: "player-two" }
    ];

    let currentTurn = 0;
    let gameOver = false;
    let busy = false;

    // SNAKES: landing position -> destination
    const snakes = {
        17: 7,
        54: 34,
        62: 19,
        64: 60,
        87: 24,
        93: 73,
        95: 75,
        99: 78
    };

    // LADDERS: landing position -> destination
    const ladders = {
        4: 14,
        9: 31,
        20: 38,
        28: 84,
        40: 59,
        63: 81,
        71: 91
    };

    // HTML CHALLENGE TILES
    const challengeTiles = [5, 12, 26, 42, 57, 68, 80, 89];

    const challenges = [
        {
            question: "Which HTML tag creates the largest heading?",
            options: ["<h6>", "<h1>", "<head>"],
            answer: 1
        },
        {
            question: "Which attribute specifies a hyperlink destination?",
            options: ["src", "alt", "href"],
            answer: 2
        },
        {
            question: "Which tag displays an image?",
            options: ["<img>", "<image>", "<picture-text>"],
            answer: 0
        },
        {
            question: "Which tag creates an unordered list?",
            options: ["<ol>", "<ul>", "<li>"],
            answer: 1
        },
        {
            question: "Which attribute provides alternative text for an image?",
            options: ["title", "href", "alt"],
            answer: 2
        },
        {
            question: "Which tag creates a table row?",
            options: ["<td>", "<tr>", "<th>"],
            answer: 1
        },
        {
            question: "Which tag connects a label to a form input?",
            options: ["<label>", "<form>", "<section>"],
            answer: 0
        },
        {
            question: "Which element represents the main content of a page?",
            options: ["<footer>", "<main>", "<aside>"],
            answer: 1
        }
    ];

    // BUILD THE 100-TILE BOARD
    function createBoard() {
        board.innerHTML = "";

        for (let number = 1; number <= 100; number++) {

            const tile = document.createElement("div");
            tile.className = "tile";
            tile.id = `tile-${number}`;

            // Arrange the board in a snake pattern.
            const rowFromBottom = Math.floor((number - 1) / 10);
            const positionInRow = (number - 1) % 10;

            const column = rowFromBottom % 2 === 0
                ? positionInRow
                : 9 - positionInRow;

            const row = 9 - rowFromBottom;

            tile.style.gridRow = row + 1;
            tile.style.gridColumn = column + 1;

            const numberLabel = document.createElement("span");
            numberLabel.className = "tile-number";
            numberLabel.textContent = number;

            const marker = document.createElement("span");
            marker.className = "tile-marker";

            if (ladders[number]) {
                tile.classList.add("ladder-tile");
                marker.textContent = "🪜";
                marker.title = `Ladder to ${ladders[number]}`;
            } else if (snakes[number]) {
                tile.classList.add("snake-tile");
                marker.textContent = "🐍";
                marker.title = `Snake to ${snakes[number]}`;
            } else if (challengeTiles.includes(number)) {
                tile.classList.add("challenge-tile");
                marker.textContent = "❓";
                marker.title = "HTML challenge";
            }

            const tokens = document.createElement("div");
            tokens.className = "tokens";
            tokens.id = `tokens-${number}`;

            tile.append(numberLabel, marker, tokens);
            board.appendChild(tile);
        }

        updateTokens();
    }

    // DISPLAY PLAYER TOKENS
    function updateTokens() {

        document.querySelectorAll(".tokens").forEach(container => {
            container.innerHTML = "";
        });

        players.forEach(player => {

            if (player.position === 0) return;

            const tokenContainer = document.getElementById(
                `tokens-${player.position}`
            );

            const token = document.createElement("div");
            token.className = `token ${player.tokenClass}`;
            token.title = player.name;

            tokenContainer.appendChild(token);
        });

        document.getElementById("position1").textContent =
            players[0].position;

        document.getElementById("position2").textContent =
            players[1].position;
    }

    // UPDATE THE CURRENT PLAYER DISPLAY
    function updateTurnDisplay() {
        currentPlayerDisplay.textContent = players[currentTurn].name;
    }

    // WAIT HELPER FOR ANIMATION
    function wait(milliseconds) {
        return new Promise(resolve => setTimeout(resolve, milliseconds));
    }

    // MOVE A PLAYER ONE TILE AT A TIME
    async function movePlayer(player, steps) {

        for (let step = 0; step < steps; step++) {

            if (player.position >= 100) break;

            player.position++;

            updateTokens();

            await wait(250);
        }
    }

    // ASK AN HTML QUESTION
    function askChallenge(question) {

        return new Promise(resolve => {

            challengeQuestion.textContent = question.question;
            challengeOptions.innerHTML = "";
            challengeFeedback.textContent = "";

            modal.hidden = false;

            question.options.forEach((option, index) => {

                const button = document.createElement("button");

                button.className = "challenge-option";
                button.textContent = option;

                button.addEventListener("click", () => {

                    const correct = index === question.answer;

                    challengeOptions.querySelectorAll("button").forEach(
                        optionButton => optionButton.disabled = true
                    );

                    challengeFeedback.textContent = correct
                        ? "Correct! You earned 3 bonus spaces."
                        : "Not quite! Keep practising your HTML.";

                    challengeFeedback.style.color = correct
                        ? "#22c55e"
                        : "#ff4ecd";

                    setTimeout(() => {
                        modal.hidden = true;
                        resolve(correct);
                    }, 1200);

                });

                challengeOptions.appendChild(button);
            });
        });
    }

    // CHECK SNAKES, LADDERS AND CHALLENGES
    async function resolveTile(player) {

        const position = player.position;

        // Challenge tile
        if (challengeTiles.includes(position)) {

            const questionIndex = challengeTiles.indexOf(position);
            const correct = await askChallenge(challenges[questionIndex]);

            if (correct) {
                gameStatus.textContent = "Challenge completed! +3 spaces.";

                const bonusSpaces = Math.min(3, 100 - player.position);

                await movePlayer(player, bonusSpaces);
            } else {
                gameStatus.textContent = "Challenge missed. Your turn ends here.";
            }

            // Check whether the bonus movement reached the finish.
            if (player.position === 100) return;

            // Don't resolve another snake or ladder after a challenge.
            return;
        }

        // Ladder
        if (ladders[position]) {

            gameStatus.textContent =
                `Amazing! You climbed a ladder to ${ladders[position]}!`;

            await wait(500);

            player.position = ladders[position];
            updateTokens();

            return;
        }

        // Snake
        if (snakes[position]) {

            gameStatus.textContent =
                `Oh no! A snake sent you back to ${snakes[position]}!`;

            await wait(500);

            player.position = snakes[position];
            updateTokens();
        }
    }

    // ROLL DICE
    async function rollDice() {

        if (busy || gameOver) return;

        busy = true;
        rollButton.disabled = true;

        const player = players[currentTurn];

        dice.classList.add("rolling");

        // Animate random dice values
        for (let i = 0; i < 8; i++) {
            dice.textContent = Math.floor(Math.random() * 6) + 1;
            await wait(70);
        }

        const result = Math.floor(Math.random() * 6) + 1;

        dice.textContent = result;
        dice.classList.remove("rolling");

        diceResult.textContent = `${player.name} rolled a ${result}!`;

        // Require an exact landing on tile 100
        if (player.position + result > 100) {

            gameStatus.textContent =
                "You need the exact number to reach tile 100.";

        } else {

            await movePlayer(player, result);

            await resolveTile(player);

            // WIN CONDITION
            if (player.position === 100) {

                gameOver = true;

                currentPlayerDisplay.textContent = "🏆 WINNER!";
                gameStatus.textContent =
                    `${player.name} conquered the Code Arena!`;

                diceResult.textContent = "Congratulations!";

                rollButton.textContent = "GAME COMPLETE";

                return;
            }
        }

        // Switch turns
        currentTurn = (currentTurn + 1) % players.length;

        updateTurnDisplay();

        gameStatus.textContent =
            `${players[currentTurn].name}, it is your turn!`;

        busy = false;
        rollButton.disabled = false;
    }

    // RESTART THE GAME
    function restartGame() {

        players.forEach(player => {
            player.position = 0;
        });

        currentTurn = 0;
        gameOver = false;
        busy = false;

        modal.hidden = true;

        dice.textContent = "🎲";
        diceResult.textContent = "Waiting for your roll...";

        rollButton.textContent = "ROLL DICE";
        rollButton.disabled = false;

        gameStatus.textContent = "Roll the dice to begin!";

        updateTokens();
        updateTurnDisplay();
    }

    // EVENT LISTENERS
    rollButton.addEventListener("click", rollDice);
    restartButton.addEventListener("click", restartGame);

    // START THE GAME
    createBoard();
    updateTurnDisplay();

    console.log("WEBDEV ARCADE: Snake & Ladder initialized!");

});
