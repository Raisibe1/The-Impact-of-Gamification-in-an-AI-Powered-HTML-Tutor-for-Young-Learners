import { useState, useEffect } from "react";
import "./App.css";

// IMPORT THE LESSONS FROM THE NEW FILE
import { LessonT001, LessonT002, LessonT003, LessonT004 } from "./lessons";

// Helper function to ask the backend ML model for a prediction
const getPrediction = async (features) => {
  try {
    const response = await fetch("http://localhost:8000/api/predict-next-correct", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include", // send session cookie
      body: JSON.stringify({ features }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || "Prediction failed");
    }

    return await response.json();
  } catch (error) {
    console.error("ML Prediction error:", error);
    return null;
  }
};

function App() {
  const [page, setPage] = useState("home");
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);

  // Check auth status when the app first loads
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const response = await fetch("http://localhost:8000/api/me", {
          credentials: "include", // CRITICAL: Sends the HttpOnly cookie
        });
        if (response.ok) {
          setIsAuthenticated(true);
        }
      } catch (error) {
        console.log("Not logged in");
      } finally {
        setIsCheckingAuth(false);
      }
    };
    checkAuth();
  }, []);

  const navigation = [
    ["Login", "login"],
    ["Register", "register"],
    ["Dashboard", "dashboard"],
    ["AI Chatbot", "chatbot"],
    ["Progress", "progress"],
    ["Analytics", "analytics"],
    ["Play Game", "external-game"],
    ["Lessons", "lessons"],
    ["Quizzes", "quizzes"]
  ].filter(([label, target]) => {
    if (isAuthenticated) {
      return target !== "login" && target !== "register";
    } else {
      return target !== "dashboard" && target !== "progress" && target !== "analytics" && target !== "external-game" && target !== "lessons" && target !=="quizzes";
    }
  });

  if (isCheckingAuth) {
    return <div className="app" style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh" }}>Loading CodeVerse...</div>;
  }

  return (
    <div className="app">
      <header className="navbar">
        <button className="logo" onClick={() => setPage("home")}>
          <span className="logo-shape">&lt;/&gt;</span>
          <span>
            <strong>CodeVerse</strong>
            <small>HTML LEARNING</small>
          </span>
        </button>

        <nav>
          {navigation.map(([label, target]) => (
            <button
              key={target}
              className={page === target ? "nav-active" : ""}
              onClick={() => {
                if (target === "external-game") {
                  window.location.href = "http://localhost:8000/";
                } else {
                  setPage(target);
                }
              }}
            >
              {label}
            </button>
          ))}

          {isAuthenticated && (
            <button onClick={() => {
              fetch("http://localhost:8000/logout", { credentials: "include" })
                .then(() => {
                  setIsAuthenticated(false);
                  setPage("home");
                });
            }}>
              Logout
            </button>
          )}
        </nav>
      </header>

      <main>
        {page === "home" && <Home setPage={setPage} />}
        {page === "login" && <Login setIsAuthenticated={setIsAuthenticated} setPage={setPage} />}
        {page === "register" && <Register setIsAuthenticated={setIsAuthenticated} setPage={setPage} />}
        {page === "dashboard" && <Dashboard />}
        {page === "chatbot" && <Chatbot />}
        {page === "progress" && <Progress />}
        {page === "analytics" && <Analytics />}
        {page === "lessons" && <Lessons />}
        {page === "quizzes" && <Quizzes/>}
      </main>

      <footer>
        <span>CodeVerse</span>
        <span>HTML Learning Platform</span>
      </footer>
    </div>
  );
}

function Home({ setPage }) {
  return (
    <section className="home">
      <div className="home-content">
        <p className="label">WELCOME TO CODEVERSE</p>

        <h1>
          Learn HTML.
          <br />
          <span>Build your first website.</span>
        </h1>

        <p className="intro">
          A simple and interactive way to learn HTML through guided lessons,
          an AI tutor, practice activities and personalised progress.
        </p>

        <div className="buttons">
          <button className="primary" onClick={() => setPage("login")}>
            Start Learning
          </button>
          <button className="secondary" onClick={() => setPage("dashboard")}>
            Explore Platform
          </button>
        </div>

        <div className="html-tags">
          <span>&lt;html&gt;</span>
          <span>&lt;body&gt;</span>
          <span>&lt;h1&gt;</span>
          <span>&lt;p&gt;</span>
        </div>
      </div>

      <div className="illustration-area">
        <div className="illustration-card">
          <div className="window">
            <div className="window-top">
              <span></span>
              <span></span>
              <span></span>
            </div>
            <div className="code">
              <p><b>&lt;html&gt;</b></p>
              <p className="indent"><b>&lt;body&gt;</b></p>
              <p className="indent-two">
                <b>&lt;h1&gt;</b><em>Hello World</em><b>&lt;/h1&gt;</b>
              </p>
              <p className="indent-two">
                <b>&lt;p&gt;</b><em>Welcome to HTML</em><b>&lt;/p&gt;</b>
              </p>
              <p className="indent"><b>&lt;/body&gt;</b></p>
              <p><b>&lt;/html&gt;</b></p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Login({ setIsAuthenticated, setPage }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  const handleLogin = async () => {
    try {
      const response = await fetch("http://localhost:8000/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();
      if (response.ok) {
        setMessage("Login successful!");
        setIsAuthenticated(true);
        setPage("dashboard");
      } else {
        setMessage(data.detail || "Login failed");
      }
    } catch (error) {
      setMessage("Network error. Is the backend running?");
    }
  };

  return (
    <section className="center-page">
      <div className="form-card">
        <label>Email address</label>
        <input
          type="email"
          placeholder="Enter your email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <label>Password</label>
        <input
          type="password"
          placeholder="Enter your password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button className="primary full" onClick={handleLogin}>Login</button>
        {message && <p className="small-text">{message}</p>}
      </div>
    </section>
  );
}

function Dashboard() {
  const [prediction, setPrediction] = useState(null);

  useEffect(() => {
    const mockFeatures = {
      prior_interactions: 15,
      prior_accuracy: 0.65,
      recent_accuracy_5: 0.8,
      prior_mean_attempt_count: 1.5,
      prior_skill_attempts: 4,
      prior_skill_accuracy: 0.75
    };

    getPrediction(mockFeatures).then((data) => {
      if (data) setPrediction(data);
    });
  }, []);

  return (
    <section className="dashboard page-section">
      <div className="section-heading">
        <p className="label">DASHBOARD</p>
        <h2>Welcome to your learning space.</h2>
        <p>Your HTML lessons, activities and learning journey will appear here.</p>
      </div>

      <div className="dashboard-grid">
        <div className="dashboard-card large-card">
          <div className="card-illustration html-illustration">
            <span>&lt;/&gt;</span>
          </div>
          <div>
            <p className="label">CURRENT COURSE</p>
            <h3>HTML Fundamentals</h3>
            <p>Learn the structure of webpages and start creating your own HTML documents.</p>
            <button className="primary">Continue Learning</button>
          </div>
        </div>

        <div className="dashboard-card">
          <p className="label">NEXT LESSON</p>
          <h3>HTML Elements</h3>
          <p>Learn how tags create the structure of a webpage.</p>
          <div className="fake-progress"><span></span></div>
          <small>Lesson 1 of 5</small>
        </div>

        <div className="dashboard-card" style={{ border: "2px solid #0A3323" }}>
          <p className="label" style={{ color: "#0A3323" }}>AI PREDICTION</p>
          <h3>Next Question Readiness</h3>
          {prediction ? (
            <div>
              <p style={{ fontSize: "2rem", fontWeight: "bold", margin: "10px 0" }}>
                {Math.round(prediction.p_next_interaction_correct * 100)}%
              </p>
              <p style={{ fontSize: "0.85rem" }}>
                Chance you'll get the next question right based on your history.
              </p>
            </div>
          ) : (
            <p>Loading prediction...</p>
          )}
        </div>

        <div className="dashboard-card">
          <p className="label">AI TUTOR</p>
          <h3>Ask your tutor</h3>
          <p>Your HTML tutor will help explain concepts whenever you need clarification.</p>
          <button className="secondary">Open AI Chatbot</button>
        </div>
      </div>
    </section>
  );
}

function Chatbot() {
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState([
    { sender: "ai", text: "Hello. I'm your HTML tutor. Ask me anything about your lesson." }
  ]);
  const [isLoading, setIsLoading] = useState(false);

  const handleSend = async () => {
    if (!input.trim()) return;
    const userMessage = input;
    
    setMessages((prev) => [...prev, { sender: "user", text: userMessage }]);
    setInput("");
    setIsLoading(true);

    try {
      const response = await fetch("http://localhost:8000/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ message: userMessage }), 
      });

      if (!response.ok) throw new Error("Network response was not ok");
      
      const data = await response.json();
      setMessages((prev) => [
        ...prev, 
        { sender: "ai", text: data.reply || data.response || "Sorry, I didn't catch that." }
      ]);
    } catch (error) {
      console.error("Error connecting to backend:", error);
      setMessages((prev) => [
        ...prev, 
        { sender: "ai", text: "Error: Could not connect to the tutor server." }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter") handleSend();
  };

  return (
    <section className="chatbot-page page-section">
      <div className="section-heading">
        <p className="label">AI CHATBOT</p>
        <h2>Your HTML tutor.</h2>
        <p>Ask me anything about your HTML lesson.</p>
      </div>

      <div className="chat-container">
        <div className="chat-content">
          <div className="chat-history" style={{ display: "flex", flexDirection: "column", gap: "10px", marginBottom: "20px" }}>
            {messages.map((msg, index) => (
              <div 
                key={index} 
                className={`chat-message ${msg.sender === "user" ? "message-user" : "message-ai"}`}
                style={{
                  alignSelf: msg.sender === "user" ? "flex-end" : "flex-start",
                  backgroundColor: msg.sender === "user" ? "#0A3323" : "#f0f0f0",
                  color: msg.sender === "user" ? "#ffffff" : "#000000",
                  padding: "10px 15px",
                  borderRadius: "10px",
                  maxWidth: "80%"
                }}
              >
                {msg.text}
              </div>
            ))}
            {isLoading && <div className="chat-message message-ai" style={{ alignSelf: "flex-start", fontStyle: "italic", color: "#888" }}>Tutor is typing...</div>}
          </div>

          <div className="chat-input" style={{ display: "flex", gap: "10px" }}>
            <input 
              type="text"
              placeholder="Ask a question about HTML..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={isLoading}
              style={{ flex: 1, padding: "10px" }}
            />
            <button onClick={handleSend} disabled={isLoading}>
              {isLoading ? "Sending..." : "Send"}
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

function Progress() {
  return (
    <section className="page-section">
      <div className="section-heading">
        <p className="label">YOUR PROGRESS</p>
        <h2>Track your HTML journey.</h2>
        <p>Your learning progress will appear here.</p>
      </div>

      <div className="progress-card">
        <div className="progress-number">20%</div>
        <div>
          <h3>HTML Fundamentals</h3>
          <p>Lesson 1 of 5 completed.</p>
          <div className="large-progress"><span></span></div>
        </div>
      </div>
    </section>
  );
}

function Analytics() {
  return (
    <section className="empty-page">
      <div className="empty-illustration"></div>
      <p className="label">ANALYTICS</p>
      <h2>Your learning analytics.</h2>
    </section>
  );
}

// ==========================================
// LESSONS DIRECTORY COMPONENT
// ==========================================

function Lessons() {
  const [selectedLesson, setSelectedLesson] = useState(null);

  const lessonList = [
    { id: "T001", title: "Introduction to HTML and Web Basics", desc: "Learn what HTML is and how the web works." },
    { id: "T002", title: "HTML Tags and Document Structure", desc: "Understand the skeleton of a webpage." },
    { id: "T003", title: "Headings and Paragraphs", desc: "Format text and structure your content." },
    { id: "T004", title: "Introduction to JavaScript", desc: "Bring your webpages to life with interactivity." }
  ];

  // If a lesson is selected, show the specific lesson content from lessons.js
  if (selectedLesson) {
    return (
      <section className="page-section">
        <button className="secondary" style={{ marginBottom: "20px" }} onClick={() => setSelectedLesson(null)}>
          ← Back to Lessons
        </button>
        
        {selectedLesson === "T001" && <LessonT001 />}
        {selectedLesson === "T002" && <LessonT002 />}
        {selectedLesson === "T003" && <LessonT003 />}
        {selectedLesson === "T004" && <LessonT004 />}
        
        <div style={{ marginTop: "40px", padding: "20px", borderTop: "1px solid #ccc" }}>
          <button className="primary" onClick={() => setSelectedLesson(null)}>
            Complete Lesson
          </button>
        </div>
      </section>
    );
  }

  // Otherwise, show the lesson directory
  return (
    <section className="page-section">
      <div className="section-heading">
        <p className="label">LESSONS</p>
        <h2>Your Learning Path</h2>
        <p>Select a module below to start learning.</p>
      </div>

      <div className="dashboard-grid">
        {lessonList.map((lesson) => (
          <div key={lesson.id} className="dashboard-card">
            <p className="label">{lesson.id}</p>
            <h3>{lesson.title}</h3>
            <p>{lesson.desc}</p>
            <button 
              className="primary" 
              style={{ marginTop: "15px" }}
              onClick={() => setSelectedLesson(lesson.id)}
            >
              Start Lesson
            </button>
          </div>
        ))}
      </div>
    </section>
  );
}


// ==========================================
// NEW QUIZZES COMPONENTS
// ==========================================

function Quizzes() {
  const [selectedQuiz, setSelectedQuiz] = useState(null);

  // Data for our quizzes
  const quizList = [
    { 
      id: "T001", 
      title: "Web Basics & HTML Intro", 
      desc: "Test your knowledge on browsers, servers, and what HTML stands for.",
      questions: [
        { question: "What does HTML stand for?", options: ["HyperText Markup Language", "Home Tool Markup Language", "Hyperlinks and Text Markup Language"], answer: "HyperText Markup Language" },
        { question: "What is the job of a web browser?", options: ["To store websites", "To read code and display web pages", "To write HTML code for you"], answer: "To read code and display web pages" },
        { question: "Is HTML a programming language?", options: ["Yes", "No", "Only on weekends"], answer: "No" },
        { question: "Which part of the page holds the visible content?", options: ["The <head>", "The <body>", "The <title>"], answer: "The <body>" }
      ]
    },
    { 
      id: "T002", 
      title: "Tags & Document Structure", 
      desc: "Test your knowledge on opening tags, closing tags, and nesting.",
      questions: [
        { question: "Which tag is used to create a paragraph?", options: ["<h1>", "<p>", "<br>"], answer: "<p>" },
        { question: "What does a closing tag look like?", options: ["<p>", "</p>", "<p/>"], answer: "</p>" },
        { question: "Which of these is a self-closing tag?", options: ["<div>", "<br>", "<body>"], answer: "<br>" },
        { question: "What is wrong with this code? <p>Hello <strong>world</p></strong>", options: ["Nothing is wrong", "The <strong> tag must close before </p>", "You can't put <strong> inside <p>"], answer: "The <strong> tag must close before </p>" }
      ]
    }
  ];

  // If a quiz is selected, show the player
  if (selectedQuiz) {
    const quizData = quizList.find(q => q.id === selectedQuiz);
    return (
      <section className="page-section">
        <button className="secondary" style={{ marginBottom: "20px" }} onClick={() => setSelectedQuiz(null)}>
          ← Back to Quizzes
        </button>
        
        <div className="section-heading">
          <p className="label">QUIZ: {quizData.id}</p>
          <h2>{quizData.title}</h2>
        </div>

        <QuizPlayer questions={quizData.questions} onFinish={() => setSelectedQuiz(null)} />
      </section>
    );
  }

  // Otherwise, show the quiz directory
  return (
    <section className="page-section">
      <div className="section-heading">
        <p className="label">QUIZZES</p>
        <h2>Test Your Knowledge</h2>
        <p>Select a quiz below to see how much you've learned.</p>
      </div>

      <div className="dashboard-grid">
        {quizList.map((quiz) => (
          <div key={quiz.id} className="dashboard-card">
            <p className="label">{quiz.id}</p>
            <h3>{quiz.title}</h3>
            <p>{quiz.desc}</p>
            <button 
              className="primary" 
              style={{ marginTop: "15px" }}
              onClick={() => setSelectedQuiz(quiz.id)}
            >
              Start Quiz
            </button>
          </div>
        ))}
      </div>
    </section>
  );
}

// A reusable interactive quiz player component
function QuizPlayer({ questions, onFinish }) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState(null);
  const [score, setScore] = useState(0);
  const [isFinished, setIsFinished] = useState(false);

  const currentQuestion = questions[currentQuestionIndex];

  const handleOptionClick = (option) => {
    if (selectedOption !== null) return; // Prevent changing answer
    
    setSelectedOption(option);
    
    // Check if answer is correct
    if (option === currentQuestion.answer) {
      setScore(score + 1);
    }
  };

  const handleNext = () => {
    if (currentQuestionIndex + 1 < questions.length) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedOption(null);
    } else {
      setIsFinished(true);
    }
  };

  // Results Screen
  if (isFinished) {
    const percentage = Math.round((score / questions.length) * 100);
    return (
      <div className="form-card" style={{ maxWidth: "600px", textAlign: "center" }}>
        <h2>Quiz Complete!</h2>
        <div style={{ fontSize: "3rem", fontWeight: "bold", color: "#0A3323", margin: "20px 0" }}>
          {percentage}%
        </div>
        <p>You got {score} out of {questions.length} questions correct.</p>
        
        {percentage === 100 ? (
          <p style={{ color: "green", fontWeight: "bold" }}>Perfect Score! Outstanding work.</p>
        ) : percentage >= 50 ? (
          <p style={{ color: "#fb8c00", fontWeight: "bold" }}>Good job! Keep practicing to get 100%.</p>
        ) : (
          <p style={{ color: "red", fontWeight: "bold" }}>You might want to review the lesson and try again.</p>
        )}

        <button className="primary full" onClick={onFinish} style={{ marginTop: "20px" }}>
          Back to Quizzes
        </button>
      </div>
    );
  }

  // Active Quiz Screen
  return (
    <div className="form-card" style={{ maxWidth: "600px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "20px", fontSize: "0.9rem", color: "#666" }}>
        <span>Question {currentQuestionIndex + 1} of {questions.length}</span>
        <span>Score: {score}</span>
      </div>

      <h3 style={{ marginBottom: "20px" }}>{currentQuestion.question}</h3>

      <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
        {currentQuestion.options.map((option, index) => {
          // Determine button style based on whether it's selected and if it's correct
          let btnStyle = {
            padding: "15px",
            borderRadius: "8px",
            border: "2px solid #ddd",
            backgroundColor: "#fff",
            cursor: "pointer",
            textAlign: "left",
            fontSize: "1rem",
            transition: "all 0.2s"
          };

          if (selectedOption !== null) {
            if (option === currentQuestion.answer) {
              btnStyle.backgroundColor = "#e8f5e9"; // Green for correct
              btnStyle.borderColor = "#43a047";
            } else if (option === selectedOption) {
              btnStyle.backgroundColor = "#ffebee"; // Red for wrong guess
              btnStyle.borderColor = "#e53935";
            }
          }

          return (
            <button 
              key={index} 
              style={btnStyle} 
              onClick={() => handleOptionClick(option)}
              disabled={selectedOption !== null}
            >
              {option}
            </button>
          );
        })}
      </div>

      {selectedOption !== null && (
        <button className="primary full" onClick={handleNext} style={{ marginTop: "20px" }}>
          {currentQuestionIndex + 1 === questions.length ? "Finish Quiz" : "Next Question"}
        </button>
      )}
    </div>
  );
}


// ==========================================
// REGISTRATION COMPONENT
// ==========================================

function Register({ setIsAuthenticated, setPage }) {
  const [formData, setFormData] = useState({
    name: "", surname: "", school: "", email: "",
    password: "", age_group: "", learning_style: "", goal: "",
  });
  const [message, setMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setMessage("");

    try {
      const response = await fetch("http://localhost:8000/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (response.ok) {
        setMessage("Registration successful! You can now log in.");
        setFormData({
          name: "", surname: "", school: "", email: "",
          password: "", age_group: "", learning_style: "", goal: "",
        });
        setIsAuthenticated(true); 
        setPage("dashboard");      
      } else {
        setMessage(data.detail || "Registration failed. Please check your details.");
      }
    } catch (error) {
      console.error("Registration error:", error);
      setMessage("Network error. Is the backend running?");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section className="center-page">
      <div className="form-card" style={{ maxWidth: "500px" }}>
        <p className="label">JOIN CODEVERSE</p>
        <h2>Create your learner profile</h2>
        <p className="description">Start your HTML learning journey today.</p>

        <form onSubmit={handleRegister} style={{ display: "flex", flexDirection: "column", gap: "15px", textAlign: "left" }}>
          <div style={{ display: "flex", gap: "10px" }}>
            <div style={{ flex: 1 }}>
              <label>Name</label>
              <input type="text" name="name" placeholder="First name" value={formData.name} onChange={handleChange} required />
            </div>
            <div style={{ flex: 1 }}>
              <label>Surname</label>
              <input type="text" name="surname" placeholder="Last name" value={formData.surname} onChange={handleChange} required />
            </div>
          </div>
          <label>School</label>
          <input type="text" name="school" placeholder="Your school" value={formData.school} onChange={handleChange} required />
          <label>Email address</label>
          <input type="email" name="email" placeholder="Enter your email" value={formData.email} onChange={handleChange} required />
          <label>Password</label>
          <input type="password" name="password" placeholder="Min 8 characters" value={formData.password} onChange={handleChange} required minLength={8} />
          
          <label>Age Group</label>
          <select name="age_group" value={formData.age_group} onChange={handleChange}>
            <option value="">Select age group (optional)</option>
            <option value="8-12">8-12</option>
            <option value="13-15">13-15</option>
            <option value="16-18">16-18</option>
            <option value="18+">18+</option>
          </select>

          <label>Learning Style</label>
          <select name="learning_style" value={formData.learning_style} onChange={handleChange}>
            <option value="">Select learning style (optional)</option>
            <option value="visual">Visual</option>
            <option value="auditory">Auditory</option>
            <option value="kinesthetic">Kinesthetic</option>
            <option value="reading">Reading/Writing</option>
          </select>

          <label>Goal</label>
          <input type="text" name="goal" placeholder="What do you want to achieve?" value={formData.goal} onChange={handleChange} required />

          <button type="submit" className="primary full" disabled={isLoading} style={{ marginTop: "10px" }}>
            {isLoading ? "Registering..." : "Register"}
          </button>
        </form>

        {message && (
          <p className="small-text" style={{ color: message.includes("successful") ? "green" : "red", marginTop: "15px", fontWeight: "bold" }}>
            {message}
          </p>
        )}
      </div>
    </section>
  );
}

export default App;