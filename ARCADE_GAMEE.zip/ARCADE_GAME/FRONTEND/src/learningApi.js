const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';
export async function learningApi(path, method='GET', body) {
  const res = await fetch(`${API_BASE}/api/learning${path}`, {
    method,
    headers: {'Content-Type':'application/json'},
    credentials:'include',
    ...(body === undefined ? {} : {body:JSON.stringify(body)}),
  });
  if (!res.ok) {
    let detail = `Request failed (${res.status})`;
    try { const data=await res.json(); detail=typeof data.detail==='string'?data.detail:detail; } catch { /* non-JSON failure */ }
    const err = new Error(detail); err.status=res.status; throw err;
  }
  return res.json();
}
