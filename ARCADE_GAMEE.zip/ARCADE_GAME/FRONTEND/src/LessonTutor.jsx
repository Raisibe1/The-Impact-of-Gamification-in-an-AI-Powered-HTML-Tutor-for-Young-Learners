import { useEffect, useRef, useState } from "react";
import "./lessonTutor.css";
import { learningApi } from "./learningApi";

// Study-only assistant. This component is never mounted while an assessment is active.
export default function LessonTutor({ lesson }) {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const abortRef = useRef(null);

  useEffect(() => {
    setMessages([]);
    setInput("");
    setOpen(false);
    return () => abortRef.current?.abort();
  }, [lesson.id]);

  async function send(event) {
    event.preventDefault();
    const question = input.trim();
    if (!question || sending) return;
    setMessages(old => [...old, { role: "learner", text: question }]);
    setInput("");
    setSending(true);
    const controller = new AbortController();
    abortRef.current = controller;
    try {
      const data = await learningApi('/chat', 'POST', {
        lesson_id: lesson.id,
        message: question,
      });
      if (!controller.signal.aborted) {
        setMessages(old => [...old, { role: "tutor", text: data.reply || data.response || data.answer || "No tutor response was returned." }]);
      }
    } catch (error) {
      if (error.name !== "AbortError") {
        setMessages(old => [...old, { role: "tutor", text: "The tutor could not connect. Please check your FastAPI server." }]);
      }
    } finally {
      if (!controller.signal.aborted) setSending(false);
    }
  }

  return (
    <aside className="lesson-tutor" aria-label={`Study assistant for ${lesson.title}`}>
      <div className="lesson-tutor-heading">
        <div><strong>AI study tutor</strong><p>Ask questions about {lesson.title}. Available during lessons only.</p></div>
        <button className="secondary" type="button" aria-expanded={open} onClick={() => setOpen(value => !value)}>{open ? "Hide tutor" : "Ask AI tutor"}</button>
      </div>
      {open && <div className="lesson-tutor-body">
        <div className="lesson-tutor-history" role="log" aria-live="polite">
          <p className="lesson-tutor-welcome">I'm here to help you understand <strong>{lesson.title}</strong>. Which concept would you like to explore?</p>
          {messages.map((item, index) => <p key={index} className={`lesson-tutor-message ${item.role}`}>{item.text}</p>)}
          {sending && <p>Thinking…</p>}
        </div>
        <form onSubmit={send} className="lesson-tutor-form">
          <label htmlFor={`lesson-tutor-input-${lesson.id}`}>Your lesson question</label>
          <div><input id={`lesson-tutor-input-${lesson.id}`} value={input} onChange={e => setInput(e.target.value)} placeholder="Ask about this lesson…" disabled={sending} maxLength={2000}/><button className="primary" disabled={sending || !input.trim()} type="submit">Send</button></div>
        </form>
      </div>}
    </aside>
  );
}
