"""Self-contained route checks; does NOT read or modify your tutor.db."""
from pathlib import Path
from tempfile import TemporaryDirectory
from fastapi import FastAPI
from fastapi.testclient import TestClient
from learning_routes import initialize_learning_db, learning_router, QUIZ_BANK


def run():
    with TemporaryDirectory() as td:
        path = Path(td) / 'tutor.db'
        initialize_learning_db(path)
        app = FastAPI()
        acting_as = {'id': 1}
        async def tutor(topic_id, title, question):
            return f'Explanation for {topic_id}: {question}'
        app.include_router(learning_router(path, lambda: acting_as['id'], chat_reply=tutor))
        client = TestClient(app)
        state = client.get('/api/learning/state').json()
        assert state['lessons'][0]['unlocked'] and not state['lessons'][1]['unlocked']
        assert client.post('/api/learning/quiz/start',json={'lesson_id':'T001'}).status_code == 403
        assert client.post('/api/learning/viewed',json={'lesson_id':'T002'}).status_code == 403
        assert client.post('/api/learning/viewed',json={'lesson_id':'T001'}).status_code == 200
        started = client.post('/api/learning/quiz/start',json={'lesson_id':'T001'}).json()
        assert len(started['questions']) == 3 and 'correct' not in started['questions'][0]
        assert client.post('/api/learning/chat',json={'lesson_id':'T001','message':'Explain HTML'}).status_code == 423
        assert client.post('/api/learning/quiz/start',json={'lesson_id':'T002'}).status_code == 403
        failed = client.post('/api/learning/quiz/submit',json={
            'attempt_id':started['attempt_id'],'answers':[2,2,2]}).json()
        assert not failed['passed']
        assert not client.get('/api/learning/state').json()['lessons'][1]['unlocked']
        resumed = client.post('/api/learning/quiz/start',json={'lesson_id':'T001'}).json()
        answers = [q['correct'] for q in QUIZ_BANK['T001']]
        passed = client.post('/api/learning/quiz/submit',json={
            'attempt_id':resumed['attempt_id'],'answers':answers}).json()
        assert passed['passed']
        assert client.get('/api/learning/state').json()['lessons'][1]['unlocked']
        assert client.post('/api/learning/chat',json={'lesson_id':'T001','message':'Explain HTML'}).status_code==200
        acting_as['id']=2
        state2 = client.get('/api/learning/state').json()
        assert not state2['lessons'][1]['unlocked']
        print('PASS: unlocking, quiz grading, AI blocking, and student isolation')

if __name__=='__main__':run()
