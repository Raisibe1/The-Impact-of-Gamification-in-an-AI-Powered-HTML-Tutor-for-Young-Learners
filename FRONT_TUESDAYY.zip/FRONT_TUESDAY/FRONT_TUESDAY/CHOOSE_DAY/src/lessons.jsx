// ============================================================
// Shared helper components (keep these in the same file or move
// them to /components and import them)
// ============================================================

const codeBoxStyle = {
  backgroundColor: "#2d2d2d",
  color: "#f8f8f2",
  padding: "15px",
  borderRadius: "8px",
  overflowX: "auto",
  fontSize: "14px",
  lineHeight: 1.5,
};

const calloutColors = {
  key: { bg: "#f4f4f4", border: "#999" },
  tip: { bg: "#e8f5e9", border: "#43a047" },
  warn: { bg: "#fff4e5", border: "#fb8c00" },
  try: { bg: "#e3f2fd", border: "#1e88e5" },
};

function LessonMeta({ grade, duration, difficulty }) {
  return (
    <p className="lesson-meta" style={{ color: "#666", fontSize: "14px" }}>
      Grade {grade} &nbsp;|&nbsp; {duration} minutes &nbsp;|&nbsp; Difficulty: {difficulty}
    </p>
  );
}

function Code({ children }) {
  return (
    <pre style={codeBoxStyle}>
      <code>{children}</code>
    </pre>
  );
}

function Callout({ type = "key", title, children }) {
  const c = calloutColors[type];
  return (
    <div
      style={{
        backgroundColor: c.bg,
        borderLeft: `5px solid ${c.border}`,
        padding: "15px",
        borderRadius: "8px",
        margin: "20px 0",
      }}
    >
      <h4 style={{ marginTop: 0 }}>{title}</h4>
      {children}
    </div>
  );
}

function Quiz({ questions }) {
  return (
    <div style={{ margin: "20px 0" }}>
      {questions.map((q, i) => (
        <details
          key={i}
          style={{ marginBottom: "10px", padding: "10px 15px", border: "1px solid #ddd", borderRadius: "8px" }}
        >
          <summary style={{ cursor: "pointer", fontWeight: "bold" }}>
            {i + 1}. {q.question}
          </summary>
          <p style={{ marginTop: "10px" }}>
            <strong>Answer:</strong> {q.answer}
          </p>
        </details>
      ))}
    </div>
  );
}

function Vocab({ terms }) {
  return (
    <dl style={{ lineHeight: 1.6 }}>
      {terms.map(([word, meaning]) => (
        <div key={word} style={{ marginBottom: "8px" }}>
          <dt style={{ fontWeight: "bold", display: "inline" }}>{word}: </dt>
          <dd style={{ display: "inline", margin: 0 }}>{meaning}</dd>
        </div>
      ))}
    </dl>
  );
}

// ============================================================
// T001
// ============================================================

function LessonT001() {
  return (
    <div className="lesson-content">
      <p className="label">T001</p>
      <h1>Introduction to HTML and Web Basics</h1>
      <LessonMeta grade={7} duration={20} difficulty="1 (Easy)" />
      <p className="intro">
        Think about the last time you used the internet. Maybe you watched a video on YouTube, checked your
        friends' photos on Instagram, or played a game online. All of those things happen on websites. By the
        end of this lesson you will know what a website really is, how your browser shows it to you, and how
        HTML gives every page its shape.
      </p>

      <Callout type="key" title="What you will learn">
        <ul>
          <li>What a website and a web page are</li>
          <li>What a web browser does</li>
          <li>What HTML is (and what it is not)</li>
          <li>The two main parts of every HTML page: the head and the body</li>
        </ul>
      </Callout>

      <h3>What is a Website?</h3>
      <p>
        A <strong>website</strong> is a collection of <strong>web pages</strong> that are connected together.
        When you type something into Google and click a link, you are visiting a web page.
      </p>
      <p>
        A good way to picture it: a website is like a book, and each web page is one page of that book. The
        links are like the contents page, they let you jump from one page to another.
      </p>

      <h3>How Does a Page Reach Your Screen?</h3>
      <p>
        Websites are stored on powerful computers called <strong>servers</strong>. When you visit a website,
        this happens in a few quick steps:
      </p>
      <ol style={{ lineHeight: 1.7 }}>
        <li>You type an address (like <code>www.google.com</code>) or click a link.</li>
        <li>Your device, called the <strong>client</strong>, sends a request to the server.</li>
        <li>The server sends back the files for the page, including the HTML.</li>
        <li>Your browser reads those files and shows you the finished page.</li>
      </ol>
      <p>
        It is just like ordering at a restaurant: you (the client) place an order, the kitchen (the server)
        prepares it, and it gets brought back to your table.
      </p>

      <h3>What is a Web Browser?</h3>
      <p>
        A <strong>web browser</strong> is the app you use to look at websites. Common examples are Google
        Chrome, Firefox, Safari and Microsoft Edge. The browser's job is to read the code that someone wrote
        and show it to you as a nice-looking page with text, pictures, and buttons. Without a browser, you
        would just see lines of confusing code.
      </p>
      <Callout type="tip" title="Did you know?">
        <p>
          A browser is not the same as a search engine. Chrome is a browser, Google is a search engine. The
          browser is the car; the search engine is one of the places you can drive to.
        </p>
      </Callout>

      <h3>What is HTML?</h3>
      <p>
        HTML stands for <strong>HyperText Markup Language</strong>. It is the language used to build the
        structure of every webpage. Think of HTML like the bricks and walls of a house. The bricks give the
        house its shape, and HTML gives a webpage its shape.
      </p>
      <p>Let's look at the name word by word:</p>
      <ul style={{ lineHeight: 1.7 }}>
        <li><strong>HyperText</strong>: text that contains links, so you can jump to other pages.</li>
        <li><strong>Markup</strong>: notes added to text to tell the computer what each part is.</li>
        <li><strong>Language</strong>: a set of rules that computers and people both understand.</li>
      </ul>

      <Callout type="key" title="Key Takeaway">
        <p>
          HTML is not a programming language; it is a <em>markup</em> language. It does not do maths or make
          decisions. It simply tells the browser what each piece of content is: a heading, a paragraph, a
          picture, or a link.
        </p>
      </Callout>

      <h3>Meet the Tag</h3>
      <p>
        HTML uses <strong>tags</strong> to label content. A tag is a special word inside angle brackets, like{" "}
        <code>&lt;p&gt;</code> or <code>&lt;h1&gt;</code>. Here is a very small example:
      </p>
      <Code>{`<h1>My Favourite Game</h1>
<p>I love playing it with my friends.</p>`}</Code>
      <p>
        The browser sees <code>&lt;h1&gt;</code> and thinks, "This is a big heading." It sees{" "}
        <code>&lt;p&gt;</code> and thinks, "This is a normal paragraph." You do not have to tell it how to draw
        the letters, you only tell it <em>what</em> the content is.
      </p>

      <h3>How Does HTML Work?</h3>
      <p>
        When you open an HTML file in a browser, the browser reads the tags and displays the content. Every
        HTML page has two main parts:
      </p>
      <ul style={{ lineHeight: 1.7 }}>
        <li>
          <code>&lt;head&gt;</code>: contains information about the page, like the title that appears in the
          browser tab. You do not see this on the page itself.
        </li>
        <li>
          <code>&lt;body&gt;</code>: contains everything you can see: text, images, buttons, and more.
        </li>
      </ul>
      <p>
        Think of a person: the head holds the thinking and the label ("name tag"), and the body is the part
        everyone sees and interacts with.
      </p>
      <p>
        The very first thing you type in an HTML file is <code>&lt;!DOCTYPE html&gt;</code>. This tells the
        browser, "Hey, this is an HTML5 document!" Then everything goes inside <code>&lt;html&gt;</code> tags.
      </p>
      <Code>{`<!DOCTYPE html>
<html>
  <head>
    <title>My Page</title>
  </head>
  <body>
    <p>Hello, world!</p>
  </body>
</html>`}</Code>

      <h3>Key Words to Remember</h3>
      <Vocab
        terms={[
          ["Website", "a group of connected web pages"],
          ["Browser", "the app that reads code and shows web pages"],
          ["Server", "a computer that stores websites and sends them when asked"],
          ["HTML", "the language that gives a web page its structure"],
          ["Tag", "a word in angle brackets that labels a piece of content"],
        ]}
      />

      <Callout type="warn" title="Common Mix-ups">
        <ul>
          <li>HTML is <strong>not</strong> a programming language. It describes content, it does not run logic.</li>
          <li>The browser does not "make" the website. It only <em>shows</em> the code someone else wrote.</li>
          <li>The head is <strong>not</strong> the top of the page you see. It is hidden information.</li>
        </ul>
      </Callout>

      <Callout type="try" title="Try It Yourself (no coding needed)">
        <ol>
          <li>Open any website on a computer.</li>
          <li>Right-click on the page and choose <strong>View Page Source</strong>.</li>
          <li>Look for tags such as <code>&lt;head&gt;</code>, <code>&lt;body&gt;</code> and <code>&lt;p&gt;</code>.</li>
        </ol>
        <p>That wall of text is the HTML your browser turns into the page you see.</p>
      </Callout>

      <h3>Why Does This Matter?</h3>
      <p>
        Every website you have ever visited, from YouTube to your school's website, was built with HTML.
        Learning HTML gives you the power to create your own web pages and share your ideas with the world.
      </p>

      <h3>Check Your Understanding</h3>
      <p>Tap a question to reveal the answer.</p>
      <Quiz
        questions={[
          { question: "What does HTML stand for?", answer: "HyperText Markup Language." },
          { question: "What is the job of a web browser?", answer: "It reads the code of a web page and shows it as text, pictures and buttons." },
          { question: "Is HTML a programming language? Why or why not?", answer: "No. It is a markup language. It describes the structure of content but does not do maths or make decisions." },
          { question: "Which part of an HTML page holds everything you can see?", answer: "The <body>." },
          { question: "What must be the very first line of an HTML file?", answer: "<!DOCTYPE html>" },
        ]}
      />

      <Callout type="key" title="Summary">
        <ul>
          <li>A website is a group of connected web pages, stored on servers.</li>
          <li>A browser reads the code and displays it for you.</li>
          <li>HTML uses tags to describe what each piece of content is.</li>
          <li>Every page has a head (hidden info) and a body (visible content).</li>
        </ul>
      </Callout>
    </div>
  );
}

// ============================================================
// T002
// ============================================================

function LessonT002() {
  return (
    <div className="lesson-content">
      <p className="label">T002</p>
      <h1>HTML Tags and Document Structure</h1>
      <LessonMeta grade={7} duration={18} difficulty="1 (Easy)" />
      <p className="intro">
        Understanding tags and structure is like learning the alphabet before writing sentences. In this
        lesson you will learn how tags work and how to build the skeleton that every web page needs.
      </p>

      <Callout type="key" title="What you will learn">
        <ul>
          <li>What tags are and how opening and closing tags work</li>
          <li>What self-closing tags are</li>
          <li>The structure of an HTML page, line by line</li>
          <li>How to use headings, paragraphs and line breaks</li>
        </ul>
      </Callout>

      <h3>What Are Tags?</h3>
      <p>
        Tags are the building blocks of HTML. They are special words inside angle brackets, like{" "}
        <code>&lt;p&gt;</code> or <code>&lt;h1&gt;</code>. Most tags come in pairs: an opening tag like{" "}
        <code>&lt;p&gt;</code> and a closing tag like <code>&lt;/p&gt;</code>. The closing tag has a forward
        slash <code>/</code>. Everything between the opening and closing tags is the <strong>content</strong>.
      </p>
      <Code>{`<p>I am the content</p>
 ^                  ^
 opening tag    closing tag`}</Code>
      <p>
        Think of tags like a gift box: the opening tag opens the box, the closing tag shuts it, and the
        content is the gift inside. A tag together with its content is called an <strong>element</strong>.
      </p>

      <h3>Self-Closing Tags</h3>
      <p>
        Some tags, like <code>&lt;br&gt;</code> (line break) and <code>&lt;img&gt;</code> (image), are{" "}
        <strong>self-closing</strong>. They do not need a closing tag because they do not wrap around any
        content. A line break has nothing inside it, it simply is a break.
      </p>

      <h3>The Structure of an HTML Page</h3>
      <p>Every HTML page follows the same basic structure:</p>
      <Code>{`<!DOCTYPE html>
<html>
  <head>
    <title>My First Page</title>
  </head>
  <body>
    <h1>Welcome!</h1>
    <p>This is my first webpage.</p>
  </body>
</html>`}</Code>

      <p>Let's break this down:</p>
      <ul style={{ lineHeight: 1.7 }}>
        <li><strong>&lt;!DOCTYPE html&gt;</strong>: Tells the browser this is an HTML5 document.</li>
        <li><strong>&lt;html&gt;</strong>: The root tag that wraps everything.</li>
        <li>
          <strong>&lt;head&gt;</strong>: Contains information about the page. The <code>&lt;title&gt;</code>{" "}
          tag inside the head sets the text that appears in the browser tab.
        </li>
        <li><strong>&lt;body&gt;</strong>: Contains everything you see on the page.</li>
      </ul>

      <h3>Nesting: Tags Inside Tags</h3>
      <p>
        Look at the code again. The <code>&lt;head&gt;</code> and <code>&lt;body&gt;</code> tags sit{" "}
        <em>inside</em> the <code>&lt;html&gt;</code> tag. Putting tags inside other tags is called{" "}
        <strong>nesting</strong>. It works like Russian dolls: the smaller doll must fit completely inside the
        bigger one.
      </p>
      <Code>{`Correct:   <p>Hello <strong>friend</strong></p>
Wrong:     <p>Hello <strong>friend</p></strong>`}</Code>
      <p>
        The tag you open last must be the tag you close first. Also notice the <strong>indentation</strong>{" "}
        (the spaces at the start of lines) in the example. Browsers ignore it, but it makes your code much
        easier for humans to read.
      </p>

      <h3>Headings and Paragraphs</h3>
      <p>
        HTML gives you six heading sizes: <code>&lt;h1&gt;</code> (the biggest and most important) down to{" "}
        <code>&lt;h6&gt;</code> (the smallest). You use headings for titles and subtitles, just like in a
        school project.
      </p>
      <p>
        The <code>&lt;p&gt;</code> tag creates a paragraph of text. When you write text between{" "}
        <code>&lt;p&gt;</code> and <code>&lt;/p&gt;</code>, the browser displays it as a block of text.
      </p>
      <Code>{`<h1>My Pet</h1>
<p>My dog is called Max. He loves to play fetch.</p>`}</Code>

      <h3>Line Breaks</h3>
      <p>
        If you want to start a new line without starting a new paragraph, use the <code>&lt;br&gt;</code> tag.
        It is self-closing, so you just type <code>&lt;br&gt;</code>, no closing tag needed. This is useful for
        addresses or poems.
      </p>
      <Code>{`<p>
  12 Main Street<br>
  Benoni<br>
  Gauteng
</p>`}</Code>

      <Callout type="warn" title="Common Mistakes">
        <ul>
          <li>Forgetting the closing tag, for example writing <code>&lt;p&gt;Hello</code> and never closing it.</li>
          <li>Forgetting the slash: <code>&lt;p&gt;Hello&lt;p&gt;</code> opens a second paragraph instead of closing the first.</li>
          <li>Putting visible content in the <code>&lt;head&gt;</code>. Visible content belongs in the <code>&lt;body&gt;</code>.</li>
          <li>Closing nested tags in the wrong order.</li>
        </ul>
      </Callout>

      <Callout type="try" title="Try It Yourself">
        <ol>
          <li>Open Notepad (or any plain text editor).</li>
          <li>Type the full example page from this lesson, then change the title and the text to be about you.</li>
          <li>Save the file as <code>index.html</code>.</li>
          <li>Double-click the file. It should open in your browser.</li>
          <li>Check the browser tab: does it show your new title?</li>
        </ol>
        <p><strong>Bonus:</strong> add your home address using <code>&lt;br&gt;</code> tags.</p>
      </Callout>

      <h3>Key Words to Remember</h3>
      <Vocab
        terms={[
          ["Opening tag", "starts an element, like <p>"],
          ["Closing tag", "ends an element, like </p>"],
          ["Element", "the opening tag, the content and the closing tag together"],
          ["Self-closing tag", "a tag with no content, so it needs no closing tag (<br>, <img>)"],
          ["Nesting", "placing one element inside another"],
        ]}
      />

      <h3>Why Does This Matter?</h3>
      <p>
        Once you know how tags work, you can start building real web pages with headings, paragraphs, and
        more. Every website you visit uses these same building blocks!
      </p>

      <h3>Check Your Understanding</h3>
      <Quiz
        questions={[
          { question: "What is the difference between an opening tag and a closing tag?", answer: "The closing tag has a forward slash, like </p>, and it ends the element." },
          { question: "Name two self-closing tags.", answer: "<br> and <img>." },
          { question: "Which tag sets the text shown in the browser tab?", answer: "The <title> tag, inside the <head>." },
          { question: "What is wrong with this code? <p>Hello <strong>friend</p></strong>", answer: "The tags are nested in the wrong order. The <strong> tag must be closed before the </p> tag." },
          { question: "When would you use <br> instead of a new <p>?", answer: "When you want a new line without starting a new paragraph, such as in an address or a poem." },
        ]}
      />

      <Callout type="key" title="Summary">
        <ul>
          <li>Most tags come in pairs: an opening tag and a closing tag with a slash.</li>
          <li>Self-closing tags like &lt;br&gt; and &lt;img&gt; do not need a closing tag.</li>
          <li>Every page uses &lt;!DOCTYPE html&gt;, &lt;html&gt;, &lt;head&gt; and &lt;body&gt;.</li>
          <li>Tags can be nested, but must be closed in the correct order.</li>
        </ul>
      </Callout>
    </div>
  );
}

// ============================================================
// T003
// ============================================================

function LessonT003() {
  return (
    <div className="lesson-content">
      <p className="label">T003</p>
      <h1>Headings and Paragraphs</h1>
      <LessonMeta grade={7} duration={15} difficulty="1 (Easy)" />
      <p className="intro">
        When you look at a newspaper or a school textbook, the text isn't just one giant block. It has a big
        title at the top, smaller titles for different sections, and paragraphs of text underneath. HTML uses
        special tags to create this exact same structure on a webpage.
      </p>

      <Callout type="key" title="What you will learn">
        <ul>
          <li>The six heading levels, <code>&lt;h1&gt;</code> to <code>&lt;h6&gt;</code></li>
          <li>How to use <code>&lt;p&gt;</code> for paragraphs</li>
          <li>How to use <code>&lt;br&gt;</code> and <code>&lt;hr&gt;</code></li>
          <li>What an empty tag is</li>
        </ul>
      </Callout>

      <h3>Headings: &lt;h1&gt; to &lt;h6&gt;</h3>
      <p>
        Headings are used for titles and subheadings. HTML gives us <strong>six levels of headings</strong>,
        from <code>&lt;h1&gt;</code> (most important) to <code>&lt;h6&gt;</code> (least important).
      </p>
      <ul style={{ lineHeight: 1.7 }}>
        <li><code>&lt;h1&gt;</code> is the biggest and most important heading on the page. You should only use it once, usually for the main title.</li>
        <li><code>&lt;h2&gt;</code> is for main sections.</li>
        <li><code>&lt;h3&gt;</code> is for sub-sections, and so on, down to <code>&lt;h6&gt;</code>, which is the smallest.</li>
      </ul>
      <p>
        Just like a school project, the headings help the reader know what the page is about. Every heading
        needs an opening tag and a closing tag.
      </p>

      <p><strong>Example:</strong></p>
      <Code>{`<h1>My School</h1>

<h2>Subjects I Like</h2>

<h3>Computer Applications Technology</h3>`}</Code>

      <p>Here is how the browser shows the different levels:</p>
      <div style={{ backgroundColor: "#f4f4f4", padding: "15px", borderRadius: "8px", marginBottom: "20px" }}>
        <h1>This is an H1 Heading</h1>
        <h2>This is an H2 Heading</h2>
        <h3>This is an H3 Heading</h3>
        <h4>This is an H4 Heading</h4>
        <h5>This is an H5 Heading</h5>
        <h6>This is an H6 Heading</h6>
      </div>

      <h3>Headings Are Like a Family Tree</h3>
      <p>
        Think of a page outline, like the plan you make before writing an essay. The main title is at the
        top, and each level below it is a smaller part of the one above.
      </p>
      <Code>{`<h1>Animals</h1>
  <h2>Pets</h2>
    <h3>Dogs</h3>
    <h3>Cats</h3>
  <h2>Wild Animals</h2>
    <h3>Lions</h3>
    <h3>Elephants</h3>`}</Code>
      <Callout type="warn" title="Choose headings for meaning, not size">
        <p>
          It is tempting to use <code>&lt;h4&gt;</code> just because you want smaller text. Do not! Pick the
          heading level that matches how important the title is. Do not skip levels either (for example, going
          straight from <code>&lt;h1&gt;</code> to <code>&lt;h4&gt;</code>). Search engines and screen readers
          used by blind visitors rely on headings to understand your page.
        </p>
      </Callout>

      <h3>Paragraphs: &lt;p&gt;</h3>
      <p>
        While headings are for titles, the <code>&lt;p&gt;</code> tag is used for blocks of normal text.
        Whenever you want to write a paragraph, you put the text between <code>&lt;p&gt;</code> and{" "}
        <code>&lt;/p&gt;</code>. When the browser sees a <code>&lt;p&gt;</code> tag, it automatically adds a
        little bit of space above and below the paragraph so it is easy to read.
      </p>
      <p><strong>Example:</strong></p>
      <Code>{`<p>Welcome to my school website. I am learning HTML.</p>`}</Code>
      <p>
        Here is another thing to know: the browser ignores extra spaces and Enter presses in your code. Look at
        this:
      </p>
      <Code>{`<p>Hello          there.


     How are      you?</p>`}</Code>
      <p>
        The browser displays it as <em>"Hello there. How are you?"</em> on one line. If you want a new
        paragraph, you need a new <code>&lt;p&gt;</code> tag.
      </p>

      <h3>Line Breaks and Horizontal Rules</h3>
      <p>
        Sometimes you want to start a new line without making a whole new paragraph. You can use the{" "}
        <code>&lt;br&gt;</code> tag (break) to push text to the next line. You can also use the{" "}
        <code>&lt;hr&gt;</code> tag (horizontal rule) to draw a line across the page, which is great for
        separating different topics.
      </p>
      <p><strong>Example:</strong></p>
      <Code>{`<p>This is the first line. <br> This is the second line.</p>

<hr>`}</Code>

      <Callout type="key" title="NB: Empty Tags">
        <p>
          Tags like <code>&lt;br&gt;</code> and <code>&lt;hr&gt;</code> are called <strong>empty tags</strong>{" "}
          because they don't wrap around any text, so they don't need a closing tag!
        </p>
      </Callout>

      <h3>Putting It All Together</h3>
      <p>Here is a small page that uses everything from this lesson:</p>
      <Code>{`<!DOCTYPE html>
<html>
  <head>
    <title>About Me</title>
  </head>
  <body>
    <h1>About Me</h1>

    <h2>My Hobbies</h2>
    <p>I love gaming and football.</p>

    <hr>

    <h2>My School</h2>
    <p>
      I go to Sunrise High School.<br>
      My favourite subject is CAT.
    </p>
  </body>
</html>`}</Code>

      <Callout type="warn" title="Common Mistakes">
        <ul>
          <li>Using more than one <code>&lt;h1&gt;</code> on a page.</li>
          <li>Typing <code>&lt;/br&gt;</code> or <code>&lt;/hr&gt;</code>. Empty tags do not have closing tags.</li>
          <li>Pressing Enter in the code and expecting a new line on the page.</li>
          <li>Mismatching tags, such as <code>&lt;h2&gt;Title&lt;/h3&gt;</code>.</li>
        </ul>
      </Callout>

      <Callout type="try" title="Try It Yourself">
        <p>Create a page called <code>myschool.html</code> that has:</p>
        <ol>
          <li>An <code>&lt;h1&gt;</code> with the name of your school.</li>
          <li>Two <code>&lt;h2&gt;</code> headings: "Subjects I Like" and "My Favourite Teacher".</li>
          <li>A <code>&lt;p&gt;</code> under each heading.</li>
          <li>An <code>&lt;hr&gt;</code> between the two sections.</li>
        </ol>
        <p><strong>Challenge:</strong> write a short poem using <code>&lt;br&gt;</code> for the line breaks.</p>
      </Callout>

      <h3>Why Does This Matter?</h3>
      <p>
        If you just typed text on a page without tags, it would all blend into one messy block. Headings and
        paragraphs make your webpage look neat, professional, and easy for your visitors to read.
      </p>

      <h3>Check Your Understanding</h3>
      <Quiz
        questions={[
          { question: "How many heading levels does HTML have?", answer: "Six, from <h1> to <h6>." },
          { question: "How many times should you use <h1> on a page?", answer: "Once, for the main title." },
          { question: "Which tag creates a paragraph?", answer: "<p>." },
          { question: "What is the difference between <br> and <hr>?", answer: "<br> starts a new line of text. <hr> draws a horizontal line across the page." },
          { question: "Why do <br> and <hr> not need closing tags?", answer: "They are empty tags: they do not wrap around any content." },
        ]}
      />

      <Callout type="key" title="Summary">
        <ul>
          <li>Headings, <code>&lt;h1&gt;</code> to <code>&lt;h6&gt;</code>, give your page a clear outline.</li>
          <li>Paragraphs, <code>&lt;p&gt;</code>, hold your normal text.</li>
          <li><code>&lt;br&gt;</code> makes a new line and <code>&lt;hr&gt;</code> draws a dividing line.</li>
          <li>Empty tags have no content and no closing tag.</li>
        </ul>
      </Callout>
    </div>
  );
}

// ============================================================
// T004
// (No topic notes were supplied yet, so this is built on the
// original T004 lesson. Replace the content when you send the
// official notes, grade and duration.)
// ============================================================

function LessonT004() {
  return (
    <div className="lesson-content">
      <p className="label">T004</p>
      <h1>Introduction to JavaScript</h1>
      <LessonMeta grade={7} duration={20} difficulty="2 (Easy-Medium)" />
      <p className="intro">
        While HTML provides the structure and CSS provides the styling, <strong>JavaScript (JS)</strong>{" "}
        provides the behavior. It makes your webpage interactive.
      </p>

      <Callout type="key" title="What you will learn">
        <ul>
          <li>What JavaScript is and what it is used for</li>
          <li>How to add JavaScript to a page with the <code>&lt;script&gt;</code> tag</li>
          <li>How to show messages with <code>alert()</code> and <code>console.log()</code></li>
          <li>How to write comments and store information in a variable</li>
        </ul>
      </Callout>

      <h3>The Three Layers of a Web Page</h3>
      <p>Imagine building a person:</p>
      <ul style={{ lineHeight: 1.7 }}>
        <li><strong>HTML</strong> is the skeleton: it gives the page its structure.</li>
        <li><strong>CSS</strong> is the clothes and style: it controls colours, fonts and layout.</li>
        <li><strong>JavaScript</strong> is the muscles and brain: it makes things move and react.</li>
      </ul>
      <p>
        Every time something on a page reacts to you, like a "like" button turning red, a game keeping your
        score, or a menu sliding open, JavaScript is doing the work.
      </p>
      <Callout type="warn" title="Not the same as Java!">
        <p>
          JavaScript and Java are two different languages. The names are similar for historical reasons only.
        </p>
      </Callout>

      <h3>Adding JS to Your Page</h3>
      <p>
        You can add JavaScript inside a <code>&lt;script&gt;</code> tag. Usually, it is placed at the bottom
        of the <code>&lt;body&gt;</code>, so the page content loads first.
      </p>
      <Code>{`<body>
  <h1>My Website</h1>

  <script>
    // This is a JavaScript comment
    alert("Welcome to my website!");
  </script>
</body>`}</Code>
      <p>
        In this example, when the page loads, a popup box will appear saying "Welcome to my website!". In
        future lessons, you will learn how to use JavaScript to react to button clicks, validate forms, and
        much more.
      </p>

      <h3>Reading the Code Line by Line</h3>
      <ul style={{ lineHeight: 1.7 }}>
        <li><code>// This is a JavaScript comment</code>: anything after <code>//</code> is a note for humans. The browser ignores it.</li>
        <li><code>alert(...)</code>: a built-in command that shows a popup box.</li>
        <li><code>"Welcome to my website!"</code>: the message. Text in JavaScript is wrapped in quotation marks.</li>
        <li><code>;</code>: the semicolon marks the end of an instruction.</li>
      </ul>

      <h3>Talking to the Console</h3>
      <p>
        Popups can get annoying. Programmers often use <code>console.log()</code> to print messages in a
        hidden area of the browser called the <strong>console</strong>. To open it, press <strong>F12</strong>{" "}
        and click the Console tab.
      </p>
      <Code>{`<script>
  console.log("Hello from the console!");
</script>`}</Code>

      <h3>Variables: Boxes That Remember Things</h3>
      <p>
        A <strong>variable</strong> is like a labelled box where you store information. You create one with the
        word <code>let</code>.
      </p>
      <Code>{`<script>
  let name = "Thabo";
  alert("Hello, " + name + "!");
</script>`}</Code>
      <p>
        Here the box is called <code>name</code> and it holds the text "Thabo". The <code>+</code> joins pieces
        of text together. Change the name in the box, and the message changes too.
      </p>

      <h3>A Sneak Peek: Reacting to a Click</h3>
      <p>Here is a button that responds when you press it. You do not need to understand it fully yet:</p>
      <Code>{`<button onclick="alert('You clicked me!')">Click me</button>`}</Code>

      <Callout type="warn" title="Common Mistakes">
        <ul>
          <li>Capital letters matter: <code>Alert("Hi")</code> will not work, but <code>alert("Hi")</code> will.</li>
          <li>Forgetting the quotation marks around text.</li>
          <li>Forgetting the closing bracket <code>)</code> or the closing <code>&lt;/script&gt;</code> tag.</li>
          <li>Putting JavaScript code outside a <code>&lt;script&gt;</code> tag. The browser will just show it as text.</li>
        </ul>
      </Callout>

      <Callout type="try" title="Try It Yourself">
        <ol>
          <li>Open your <code>index.html</code> file from earlier lessons.</li>
          <li>Add a <code>&lt;script&gt;</code> tag at the bottom of the body.</li>
          <li>Create a variable with your name and use <code>alert()</code> to greet yourself.</li>
          <li>Save, refresh the browser and check the popup.</li>
        </ol>
        <p><strong>Challenge:</strong> use <code>console.log()</code> to print your favourite game and open the console to find it.</p>
      </Callout>

      <h3>Key Words to Remember</h3>
      <Vocab
        terms={[
          ["JavaScript", "the language that makes web pages interactive"],
          ["Script tag", "the HTML tag that holds JavaScript code"],
          ["Comment", "a note in the code that the browser ignores"],
          ["Variable", "a named box that stores information"],
          ["Console", "a hidden browser panel where messages can be printed"],
        ]}
      />

      <h3>Check Your Understanding</h3>
      <Quiz
        questions={[
          { question: "What job does JavaScript do on a web page?", answer: "It provides behaviour: it makes the page interactive." },
          { question: "Which HTML tag do you use to add JavaScript?", answer: "The <script> tag." },
          { question: "What does alert(\"Hi!\") do?", answer: "It shows a popup box with the message Hi!" },
          { question: "How do you write a comment in JavaScript?", answer: "Start the line with //." },
          { question: "What is a variable?", answer: "A named box that stores information, created with let." },
        ]}
      />

      <Callout type="key" title="Summary">
        <ul>
          <li>HTML is structure, CSS is style, JavaScript is behaviour.</li>
          <li>JavaScript goes inside a <code>&lt;script&gt;</code> tag, usually at the bottom of the body.</li>
          <li><code>alert()</code> shows a popup, <code>console.log()</code> prints to the console.</li>
          <li>Variables store information, and comments leave notes for humans.</li>
        </ul>
      </Callout>
    </div>
  );
}

export { LessonT001, LessonT002, LessonT003, LessonT004, LessonMeta, Code, Callout, Quiz, Vocab };
