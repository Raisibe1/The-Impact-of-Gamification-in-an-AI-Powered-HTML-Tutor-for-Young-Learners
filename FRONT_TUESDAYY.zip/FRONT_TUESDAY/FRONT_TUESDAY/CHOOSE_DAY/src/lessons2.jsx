import {
  LessonT001,
  LessonT002,
  LessonT003,
  LessonT004,
  LessonMeta,
  Code,
  Callout,
  Quiz,
  Vocab,
} from "./lessons";

// ============================================================
// T005
// ============================================================

function LessonT005() {
  return (
    <div className="lesson-content">
      <p className="label">T005</p>
      <h1>Semantic HTML and Accessibility</h1>
      <LessonMeta grade={7} duration={20} difficulty="2 (Easy-Medium)" />
      <p className="intro">
        Imagine walking into a school where none of the doors have signs. No "Library", no "Office", no
        "Toilets". You would have to open every door to find out what is inside! Web pages can be like that
        too, unless we label each part properly. In this lesson you will learn to give your page meaningful
        labels, and to make your website work for <em>everyone</em>.
      </p>

      <Callout type="key" title="What you will learn">
        <ul>
          <li>What "semantic" HTML means</li>
          <li>The main semantic tags: header, nav, main, section, article, aside and footer</li>
          <li>Why accessibility matters and who it helps</li>
          <li>Simple habits that make your pages more accessible</li>
        </ul>
      </Callout>

      <h3>What Does "Semantic" Mean?</h3>
      <p>
        <strong>Semantic</strong> means "having meaning". A semantic tag tells the browser (and the people
        using it) <em>what the content is</em>, not just how it looks. You already know some:{" "}
        <code>&lt;h1&gt;</code> means "main heading" and <code>&lt;p&gt;</code> means "paragraph". Now let's
        meet tags that describe the different <strong>areas</strong> of a whole page.
      </p>

      <h3>The Non-Semantic Way: &lt;div&gt;</h3>
      <p>
        The <code>&lt;div&gt;</code> tag is a plain box used to group content. It is useful, but it says
        nothing about what is inside, like a cardboard box with no label.
      </p>
      <Code>{`<div>
  <div>My Website</div>
  <div>Home | About | Contact</div>
</div>
<div>
  <div>Welcome to my page!</div>
</div>
<div>Made by Thabo</div>`}</Code>
      <p>The browser sees only boxes. We can do much better.</p>

      <h3>The Semantic Way</h3>
      <Code>{`<header>
  <h1>My Website</h1>
  <nav>Home | About | Contact</nav>
</header>
<main>
  <p>Welcome to my page!</p>
</main>
<footer>
  <p>Made by Thabo</p>
</footer>`}</Code>
      <p>Same page, but now every part has a name. Here is what each tag means:</p>
      <ul style={{ lineHeight: 1.7 }}>
        <li><code>&lt;header&gt;</code>: the top of the page or section, usually with the title or logo.</li>
        <li><code>&lt;nav&gt;</code>: the navigation, a group of links to move around the website.</li>
        <li><code>&lt;main&gt;</code>: the main content of the page. Use it only once per page.</li>
        <li><code>&lt;section&gt;</code>: a themed group of content, usually with its own heading.</li>
        <li><code>&lt;article&gt;</code>: content that makes sense on its own, like a news story or blog post.</li>
        <li><code>&lt;aside&gt;</code>: side content that is related but not essential, like a fun fact box.</li>
        <li><code>&lt;footer&gt;</code>: the bottom of the page or section, with credits or contact info.</li>
      </ul>

      <h3>Picture the Layout</h3>
      <div
        style={{
          border: "2px solid #555",
          borderRadius: "8px",
          padding: "10px",
          fontFamily: "monospace",
          fontSize: "14px",
          textAlign: "center",
        }}
      >
        <div style={{ background: "#bbdefb", padding: "8px", marginBottom: "6px" }}>&lt;header&gt;</div>
        <div style={{ background: "#c8e6c9", padding: "6px", marginBottom: "6px" }}>&lt;nav&gt;</div>
        <div style={{ display: "flex", gap: "6px", marginBottom: "6px" }}>
          <div style={{ background: "#fff9c4", padding: "20px 8px", flex: 3 }}>&lt;main&gt;<br />(sections and articles)</div>
          <div style={{ background: "#f8bbd0", padding: "20px 8px", flex: 1 }}>&lt;aside&gt;</div>
        </div>
        <div style={{ background: "#d1c4e9", padding: "8px" }}>&lt;footer&gt;</div>
      </div>

      <h3>Why Use Semantic HTML?</h3>
      <ul style={{ lineHeight: 1.7 }}>
        <li><strong>It is easier to read.</strong> You (and your teammates) can see the plan of the page at a glance.</li>
        <li><strong>Search engines understand it.</strong> Google can tell your main content from your footer.</li>
        <li><strong>It helps people using assistive technology.</strong> More on that next.</li>
      </ul>

      <h3>What is Accessibility?</h3>
      <p>
        <strong>Accessibility</strong> means building websites that <em>everyone</em> can use, including people
        with disabilities. Some examples of who uses the web in different ways:
      </p>
      <ul style={{ lineHeight: 1.7 }}>
        <li>A blind person uses a <strong>screen reader</strong>, software that reads the page out loud.</li>
        <li>A person with a broken arm or a motor disability may use only a <strong>keyboard</strong> and no mouse.</li>
        <li>A person with colour blindness or poor eyesight may struggle with low-contrast text.</li>
        <li>A person on a very slow phone connection, or in bright sunlight, benefits from clear, simple pages too.</li>
      </ul>
      <p>
        Screen readers can jump straight to the <code>&lt;nav&gt;</code> or <code>&lt;main&gt;</code> of a
        page, but only if you used semantic tags. With a pile of <code>&lt;div&gt;</code>s, they have to read
        everything from top to bottom.
      </p>

      <h3>Five Simple Accessibility Habits</h3>

      <p><strong>1. Add alt text to images.</strong></p>
      <p>
        The <code>alt</code> attribute describes a picture for people who cannot see it. It also shows up if
        the image fails to load.
      </p>
      <Code>{`<img src="dog.jpg" alt="A brown dog catching a ball in the park">`}</Code>

      <p><strong>2. Use headings in order.</strong></p>
      <p>
        Go from <code>&lt;h1&gt;</code> to <code>&lt;h2&gt;</code> to <code>&lt;h3&gt;</code> without skipping
        levels, so the outline makes sense.
      </p>

      <p><strong>3. Write meaningful link text.</strong></p>
      <Code>{`Bad:   <a href="games.html">Click here</a>
Good:  <a href="games.html">See my favourite games</a>`}</Code>
      <p>Screen readers can list all the links on a page, so "click here" repeated ten times is useless.</p>

      <p><strong>4. Set the page language.</strong></p>
      <Code>{`<html lang="en">`}</Code>
      <p>This helps screen readers pronounce words correctly.</p>

      <p><strong>5. Keep strong colour contrast.</strong></p>
      <p>
        Dark text on a light background (or the reverse) is easy to read. Light grey text on white might look
        stylish, but many people cannot see it.
      </p>

      <Callout type="tip" title="Cool fact">
        <p>
          The <code>alt</code> text is also what Google Images reads to understand your picture. Accessibility
          and search engine ranking often go hand in hand.
        </p>
      </Callout>

      <h3>A Complete Example</h3>
      <Code>{`<!DOCTYPE html>
<html lang="en">
  <head>
    <title>My Football Blog</title>
  </head>
  <body>
    <header>
      <h1>My Football Blog</h1>
      <nav>
        <a href="index.html">Home</a> |
        <a href="matches.html">Match Reports</a>
      </nav>
    </header>

    <main>
      <article>
        <h2>Saturday's Big Match</h2>
        <p>Our school team won 3-1 after a brilliant second half.</p>
        <img src="team.jpg" alt="The school football team celebrating with a trophy">
      </article>

      <aside>
        <h3>Fun Fact</h3>
        <p>A football pitch can be up to 120 metres long.</p>
      </aside>
    </main>

    <footer>
      <p>Written by Thabo, Grade 7</p>
    </footer>
  </body>
</html>`}</Code>

      <Callout type="warn" title="Common Mistakes">
        <ul>
          <li>Using <code>&lt;div&gt;</code> for everything when a semantic tag exists.</li>
          <li>Using more than one <code>&lt;main&gt;</code> on a page.</li>
          <li>Leaving out the <code>alt</code> text, or writing "image" or "picture" as the description.</li>
          <li>Choosing a heading just because it looks the right size, instead of what it means.</li>
          <li>Thinking accessibility is only for a few people. We all have bad days: a bright screen, a noisy bus, a sore hand.</li>
        </ul>
      </Callout>

      <Callout type="try" title="Try It Yourself">
        <ol>
          <li>Open the <code>index.html</code> page you made earlier.</li>
          <li>Replace the <code>&lt;div&gt;</code> boxes (if any) with <code>&lt;header&gt;</code>, <code>&lt;main&gt;</code> and <code>&lt;footer&gt;</code>.</li>
          <li>Add <code>lang="en"</code> to your opening <code>&lt;html&gt;</code> tag.</li>
          <li>Add an image with a helpful <code>alt</code> description.</li>
        </ol>
        <p>
          <strong>Challenge:</strong> press the <strong>Tab</strong> key on a website. Can you reach every
          link without a mouse? Which ones are hard to see?
        </p>
      </Callout>

      <h3>Key Words to Remember</h3>
      <Vocab
        terms={[
          ["Semantic", "having meaning: the tag describes what the content is"],
          ["Accessibility", "making websites usable by everyone, including people with disabilities"],
          ["Screen reader", "software that reads a web page aloud"],
          ["Alt text", "a written description of an image"],
          ["Attribute", "extra information inside an opening tag, like alt or lang"],
        ]}
      />

      <h3>Why Does This Matter?</h3>
      <p>
        Around one in every six people in the world lives with some form of disability. A website that only
        some people can use is a website that is half finished. Writing semantic, accessible HTML is a
        professional habit that real web developers are expected to have.
      </p>

      <h3>Check Your Understanding</h3>
      <Quiz
        questions={[
          { question: "What does the word 'semantic' mean?", answer: "Having meaning. A semantic tag tells you what its content is." },
          { question: "Which tag holds the main navigation links?", answer: "<nav>." },
          { question: "Why should you add alt text to an image?", answer: "It describes the picture for people who cannot see it (for example screen reader users) and shows if the image does not load." },
          { question: "Which is better link text: 'Click here' or 'Read my football blog'?", answer: "'Read my football blog', because it makes sense even when read out of context." },
          { question: "How many <main> elements should a page have?", answer: "One." },
        ]}
      />

      <Callout type="key" title="Summary">
        <ul>
          <li>Semantic tags (header, nav, main, section, article, aside, footer) label the areas of a page.</li>
          <li>Accessibility means making sites usable by everyone.</li>
          <li>Use alt text, ordered headings, clear link text, a page language and good contrast.</li>
          <li>Prefer a semantic tag to a plain &lt;div&gt; whenever one fits.</li>
        </ul>
      </Callout>
    </div>
  );
}

// ============================================================
// T006
// ============================================================

function LessonT006() {
  return (
    <div className="lesson-content">
      <p className="label">T006</p>
      <h1>Mini Website Development Project</h1>
      <LessonMeta grade={7} duration={30} difficulty="2 (Easy-Medium)" />
      <p className="intro">
        It is time to put everything together! In this project you will build your very own "All About Me"
        website using the skills from the last five lessons. You will plan it, build it step by step, check
        it, and then show it off.
      </p>

      <Callout type="key" title="Project goal">
        <p>
          Build a one-page personal website about yourself that uses proper structure, headings, paragraphs,
          semantic tags and accessibility habits.
        </p>
      </Callout>

      <h3>What You Will Use</h3>
      <ul style={{ lineHeight: 1.7 }}>
        <li>T001: how a browser displays HTML</li>
        <li>T002: tags and the page skeleton</li>
        <li>T003: headings, paragraphs, <code>&lt;br&gt;</code> and <code>&lt;hr&gt;</code></li>
        <li>T004: a little JavaScript for a welcome message</li>
        <li>T005: semantic tags and accessibility</li>
      </ul>

      <h3>Three New Tools</h3>
      <p>You will need three small extras for this project. They are quick to learn.</p>

      <p><strong>1. Unordered list: <code>&lt;ul&gt;</code> and <code>&lt;li&gt;</code></strong></p>
      <p>A bulleted list. Each bullet is a list item (<code>&lt;li&gt;</code>).</p>
      <Code>{`<ul>
  <li>Football</li>
  <li>Coding</li>
  <li>Drawing</li>
</ul>`}</Code>

      <p><strong>2. Links: <code>&lt;a&gt;</code></strong></p>
      <p>The <code>href</code> attribute says where the link goes.</p>
      <Code>{`<a href="https://www.wikipedia.org">Visit Wikipedia</a>`}</Code>

      <p><strong>3. Images: <code>&lt;img&gt;</code></strong></p>
      <p>
        <code>src</code> is the file name and <code>alt</code> is the description. It is self-closing. Save the
        picture in the same folder as your HTML file.
      </p>
      <Code>{`<img src="me.jpg" alt="A photo of me smiling in my school uniform">`}</Code>
      <Callout type="warn" title="Be safe online">
        <p>
          Do not share your full name, home address, phone number or school name on a website. A drawing,
          cartoon avatar or a photo of your favourite thing is a great alternative to a real photo of you.
        </p>
      </Callout>

      <h3>Step 1: Plan Your Page</h3>
      <p>
        Real developers plan before they type. Grab a piece of paper and draw boxes for each part of your
        page. Decide what goes in each one:
      </p>
      <Code>{`header   -> My nickname + a short tagline
nav      -> Links that jump down the page
main
  section 1 -> About Me (a paragraph)
  section 2 -> My Hobbies (a list)
  section 3 -> My Favourite Things (a paragraph + picture)
footer   -> "Made by ..." + the year`}</Code>

      <h3>Step 2: Build the Skeleton</h3>
      <p>Start with the page structure and leave the content as short notes.</p>
      <Code>{`<!DOCTYPE html>
<html lang="en">
  <head>
    <title>All About Me</title>
  </head>
  <body>
    <header>
    </header>

    <main>
    </main>

    <footer>
    </footer>
  </body>
</html>`}</Code>
      <p>Save it as <code>index.html</code> and open it in your browser to be sure it works.</p>

      <h3>Step 3: Add the Header</h3>
      <Code>{`<header>
  <h1>Hi, I'm Thabo!</h1>
  <p>Welcome to my corner of the internet.</p>
</header>`}</Code>

      <h3>Step 4: Add Your Sections</h3>
      <Code>{`<main>
  <section>
    <h2>About Me</h2>
    <p>I am in Grade 7. I love games, football and learning how websites work.</p>
  </section>

  <hr>

  <section>
    <h2>My Hobbies</h2>
    <ul>
      <li>Football</li>
      <li>Coding</li>
      <li>Drawing</li>
    </ul>
  </section>

  <hr>

  <section>
    <h2>My Favourite Things</h2>
    <p>
      Favourite food: Pizza<br>
      Favourite game: Minecraft<br>
      Favourite subject: CAT
    </p>
    <img src="pizza.jpg" alt="A slice of pizza with melted cheese">
  </section>
</main>`}</Code>

      <h3>Step 5: Add Navigation Links</h3>
      <p>
        You can make a link jump to part of your own page. Give a section an <code>id</code>, then link to it
        with a <code>#</code>.
      </p>
      <Code>{`<nav>
  <a href="#about">About Me</a> |
  <a href="#hobbies">My Hobbies</a> |
  <a href="#favourites">Favourites</a>
</nav>

<section id="about">
  <h2>About Me</h2>
  ...
</section>`}</Code>
      <p>Place the <code>&lt;nav&gt;</code> inside your <code>&lt;header&gt;</code>.</p>

      <h3>Step 6: Add the Footer</h3>
      <Code>{`<footer>
  <p>Made by Thabo, 2026</p>
</footer>`}</Code>

      <h3>Step 7: Add a Little JavaScript</h3>
      <p>Right before the closing <code>&lt;/body&gt;</code> tag, add a welcome message:</p>
      <Code>{`<script>
  let visitorMessage = "Welcome to my website!";
  alert(visitorMessage);
</script>`}</Code>

      <h3>The Finished Page</h3>
      <p>Compare your work with this complete version:</p>
      <Code>{`<!DOCTYPE html>
<html lang="en">
  <head>
    <title>All About Me</title>
  </head>
  <body>
    <header>
      <h1>Hi, I'm Thabo!</h1>
      <p>Welcome to my corner of the internet.</p>
      <nav>
        <a href="#about">About Me</a> |
        <a href="#hobbies">My Hobbies</a> |
        <a href="#favourites">Favourites</a>
      </nav>
    </header>

    <main>
      <section id="about">
        <h2>About Me</h2>
        <p>I am in Grade 7. I love games, football and learning how websites work.</p>
      </section>

      <hr>

      <section id="hobbies">
        <h2>My Hobbies</h2>
        <ul>
          <li>Football</li>
          <li>Coding</li>
          <li>Drawing</li>
        </ul>
      </section>

      <hr>

      <section id="favourites">
        <h2>My Favourite Things</h2>
        <p>
          Favourite food: Pizza<br>
          Favourite game: Minecraft<br>
          Favourite subject: CAT
        </p>
        <img src="pizza.jpg" alt="A slice of pizza with melted cheese">
      </section>
    </main>

    <footer>
      <p>Made by Thabo, 2026</p>
    </footer>

    <script>
      let visitorMessage = "Welcome to my website!";
      alert(visitorMessage);
    </script>
  </body>
</html>`}</Code>

      <h3>Project Checklist</h3>
      <p>Tick off each item before you call your project finished:</p>
      <ul style={{ lineHeight: 1.8, listStyle: "none", paddingLeft: 0 }}>
        <li>☐ Starts with <code>&lt;!DOCTYPE html&gt;</code> and has <code>lang="en"</code></li>
        <li>☐ Has a <code>&lt;title&gt;</code> in the head</li>
        <li>☐ Uses <code>&lt;header&gt;</code>, <code>&lt;nav&gt;</code>, <code>&lt;main&gt;</code> and <code>&lt;footer&gt;</code></li>
        <li>☐ Only one <code>&lt;h1&gt;</code>, with <code>&lt;h2&gt;</code> for each section</li>
        <li>☐ At least three sections with paragraphs</li>
        <li>☐ At least one list</li>
        <li>☐ At least one image with helpful alt text</li>
        <li>☐ Navigation links that work</li>
        <li>☐ A JavaScript welcome message</li>
        <li>☐ All tags properly closed and nested</li>
        <li>☐ No private personal information</li>
      </ul>

      <Callout type="warn" title="Debugging Tips (when it doesn't work)">
        <ul>
          <li><strong>Image not showing?</strong> Check the file name and spelling, and that the picture is in the same folder as your HTML file.</li>
          <li><strong>Everything looks wrong after a certain line?</strong> You probably forgot a closing tag just above it.</li>
          <li><strong>No popup?</strong> Check the quotation marks and brackets in your script, and that it sits inside <code>&lt;script&gt;</code> tags.</li>
          <li><strong>Changed the file but nothing changed in the browser?</strong> Save the file, then refresh the page.</li>
        </ul>
      </Callout>

      <Callout type="try" title="Level Up (optional challenges)">
        <ul>
          <li>Add a fourth section, such as "My Goals" or "My Pets".</li>
          <li>Add an <code>&lt;aside&gt;</code> with a fun fact.</li>
          <li>Use <code>&lt;h3&gt;</code> headings inside a section to split it into sub-topics.</li>
          <li>Add a link to your favourite website that opens with clear link text.</li>
          <li>Change the welcome message to include your name using a variable.</li>
        </ul>
      </Callout>

      <h3>Reflect on Your Work</h3>
      <p>Good developers always look back at what they made. Think about these questions:</p>
      <Quiz
        questions={[
          { question: "Which part of the project was the easiest, and why?", answer: "There is no wrong answer. Notice which lesson you understood best." },
          { question: "Which part was the hardest, and what did you do to fix it?", answer: "Often it is closing tags or image file names. Reading the code line by line usually finds the problem." },
          { question: "Why did you use <section> instead of <div> for your topics?", answer: "<section> is semantic. It tells browsers and screen readers that each block is a themed part of the page." },
          { question: "How did you make your page accessible?", answer: "Alt text on images, ordered headings, clear link text, lang attribute and semantic tags." },
          { question: "What would you add if you had one more hour?", answer: "Your own idea! This is how real projects grow." },
        ]}
      />

      <Callout type="key" title="Summary">
        <ul>
          <li>You planned, built and checked a complete web page from scratch.</li>
          <li>You combined structure, content, semantic tags, accessibility and a bit of JavaScript.</li>
          <li>You learned three new tools: lists, links and images.</li>
          <li>Next steps: CSS will let you add colours, fonts and layout to your page.</li>
        </ul>
      </Callout>

      <h3>Why Does This Matter?</h3>
      <p>
        You now have the skills to build a real web page and put your ideas online. Every professional
        website started the same way: one small page, one tag at a time.
      </p>
    </div>
  );
}

// ============================================================
// Registry: one place that maps lesson IDs to their component
// and metadata. Your app can loop over this to build menus,
// progress bars and routes.
// ============================================================

export const lessons = [
  { id: "T001", title: "Introduction to HTML and Web Basics", grade: 7, duration: 20, difficulty: 1, component: LessonT001 },
  { id: "T002", title: "HTML Tags and Document Structure", grade: 7, duration: 18, difficulty: 1, component: LessonT002 },
  { id: "T003", title: "Headings and Paragraphs", grade: 7, duration: 15, difficulty: 1, component: LessonT003 },
  { id: "T004", title: "Introduction to JavaScript", grade: 7, duration: 20, difficulty: 2, component: LessonT004 },
  { id: "T005", title: "Semantic HTML and Accessibility", grade: 7, duration: 20, difficulty: 2, component: LessonT005 },
  { id: "T006", title: "Mini Website Development Project", grade: 7, duration: 30, difficulty: 2, component: LessonT006 },
];

export function getLesson(id) {
  return lessons.find((l) => l.id === id);
}

export { LessonT005, LessonT006 };
